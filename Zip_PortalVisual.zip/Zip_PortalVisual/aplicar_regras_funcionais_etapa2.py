# -*- coding: utf-8 -*-
#APLICAR_REGRAS_FUNCIONAIS_ETAPA2.PY (NAO SEI SE TA SENDO USADO)
from BACKUP.dclo import consultar_material_pra, consultar_knmt

print("=" * 100)
print("1) PRA R900561278")
print("=" * 100)
r = consultar_material_pra("R900561278")
print("status:", r.get("status"))
print("PRODH1:", r.get("prodh1"))
print("MVKE:", [
    (x.get("vtweg"), x.get("vmsta"), x.get("dwerk"))
    for x in (r.get("mvke") or [])
])

print()
print("=" * 100)
print("2) KNMT positivo")
print("=" * 100)
r = consultar_knmt("6100066", kunnr="0006146202")
print("status:", r.get("status"))
print("MATNR:", r.get("matnr"))
print("fonte:", r.get("fonte"))

print()
print("=" * 100)
print("3) KNMT caso atual")
print("=" * 100)
try:
    r = consultar_knmt("10308699", kunnr="0006758797")
    print("status:", r.get("status"))
    print("MATNR:", r.get("matnr"))
    print("fonte:", r.get("fonte"))
except Exception as exc:
    print("ERRO CONTROLADO:", f"{type(exc).__name__}: {exc}")