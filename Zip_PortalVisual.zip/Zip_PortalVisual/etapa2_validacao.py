# -*- coding: utf-8 -*-
# ETAPA2_VALIDACAO.PY
"""Motor da Etapa 2 — análise comercial pós-coleta Ariba.

Versão consolidada (02/10/2026). Substitui as camadas sobrepostas anteriores
(motor original + pós-processamento REGRAS_FUNCIONAIS_LUIGI) por um fluxo
único, na ordem definida com o Luigi:

  1) KUNNR (campo explícito → Ship-to parametrizado → KNA1 por evidências)
  2) Canal VTWEG (parâmetro do cliente no Portal → KNVV com canal único →
     histórico exato KUNNR + KDMAT quando o cliente é multicanal). Histórico
     só desempata se apontar exclusivamente para um único VTWEG. Dados
     comerciais da KNVV (KDGRP, KONDA, ZTERM, INCO1, AUFSD, LIFSD) passam a
     ser lidos SOMENTE da linha do canal definido.
  3) MATNR: pedido → KNMT (KUNNR+KDMAT) → histórico VBAK/VBAP (sugestão
     sujeita a decisão humana; com vários materiais, o pedido mais recente)
  4) PRA: MARC/MARA/MAKT/MVKE com VKORG BR10 + VTWEG do cliente
  5) VMSTA do canal: AV/AL seguem; SV em 50/52 redireciona o item para
     o canal 53 quando houver MVKE BR10/53; SV no 53 é permitido; demais
     status seguem o mapeamento do Portal ou bloqueiam
  6) Centro fornecedor: canal 53 → BR10; material em BR10 e BR20 →
     SOBSL Z4 → BR20, senão BR10; demais casos → MVKE.DWERK
  7) BESKZ (F comprado / E fabricado) — informativo
  8) Lote (MVKE AUMNG/SCMNG) — não se aplica ao canal 53
  9) ZNET exclusiva A005 → A813 → A706 + PIS/COFINS 9,25% por dentro
 10) ZIAD por KUNNR + PRODH1 (ausência não é erro)
 11) Destino: item → cabeçalho → contrato → parâmetro do cliente
 12) Pagamento, condição de transporte, bloqueios (canal), parceiros DALI

Status de critério:
  ok          validação concluída
  divergencia consulta concluída, dado não atende à regra (bloqueia)
  dados       falta informação/parametrização (bloqueia quando bloqueante)
  funcional   aguarda decisão humana (bloqueia)
  erro        falha técnica de consulta (bloqueia)
  info        informativo ou dependente de outro critério (não bloqueia)

Toda consulta externa é isolada: uma falha marca só o critério afetado como
erro e o processamento dos demais itens/pedidos continua.
"""

from __future__ import annotations

import re
import unicodedata
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher

from order_fields import classificar_tipo
from dclo import (
    consultar_knmt,
    consultar_historico_kdmat,
    consultar_material_pra,
    consultar_knvv_pra,
)
from oracle_q import (
    ORACLE_ENV,
    consultar_clientes_kna1,
    consultar_knvv_multiplos,
    consultar_ziad,
    tem_ziad_cliente,
    consultar_znet,
    consultar_znet_material,
    consultar_parceiros_dali,
)


# =============================================================================
# HELPERS REAPROVEITADOS (resolução de KUNNR, MATNR/KDMAT, pagamento, ZNET)
# =============================================================================
def _decimal(value):
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def _texto(value):
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _norm(value):
    value = str(value or "").strip().upper()
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^A-Z0-9]+", " ", value)
    return " ".join(value.split())


def _digits(value):
    return re.sub(r"\D+", "", str(value or ""))


def _kunnr_explicito(payload):
    """Aceita somente campo explicitamente identificado como KUNNR."""
    customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
    for key in ("kunnr", "customer_kunnr", "sap_kunnr"):
        value = _texto(customer.get(key))
        if value:
            return value
    return None


def _normalizar_matnr_bosch(value):
    """Aceita MATNR Bosch somente quando o identificador possui 10 caracteres.

    Regra confirmada com o Luigi em 29/09/2026. Isso evita tratar KDMAT curto
    do cliente como se fosse MATNR Bosch quando o payload traz campos ambíguos.
    """
    texto = _texto(value)
    if not texto:
        return None
    texto = texto.upper()
    if len(texto) != 10 or not texto.isalnum():
        return None
    return texto


def _matnr_item(item):
    candidatos = [
        item.get("rexroth_part_number"),
        item.get("supplier_part_number"),
    ]
    product = item.get("product") if isinstance(item.get("product"), dict) else {}
    candidatos += [
        product.get("rexroth_part_number"),
        product.get("supplier_part_number"),
        product.get("supplierPartId"),
        product.get("supplierPartNumber"),
    ]
    raw = item.get("raw_api") if isinstance(item.get("raw_api"), dict) else {}
    candidatos += [
        raw.get("supplierPartId"), raw.get("supplierPartID"),
        raw.get("supplierPartNumber"), raw.get("supplierPartNo"),
        raw.get("rexrothPartNumber"),
    ]
    for valor in candidatos:
        matnr = _normalizar_matnr_bosch(valor)
        if matnr:
            return matnr
    return None


def _kdmat_item(item):
    """Extrai somente identificadores que representam o código do material do cliente."""
    candidatos = [
        item.get("customer_part_number"),
        item.get("customerPartNumber"),
        item.get("customer_part_id"),
        item.get("customerPartId"),
    ]
    product = item.get("product") if isinstance(item.get("product"), dict) else {}
    candidatos += [
        product.get("customer_part_number"),
        product.get("customerPartNumber"),
        product.get("customer_part_id"),
        product.get("customerPartId"),
    ]
    raw = item.get("raw_api") if isinstance(item.get("raw_api"), dict) else {}
    candidatos += [
        raw.get("customerPartId"),
        raw.get("customerPartID"),
        raw.get("customerPartNumber"),
        raw.get("customerPartNo"),
    ]
    for valor in candidatos:
        texto = _texto(valor)
        if texto:
            return texto
    return None



PIS_COFINS_TOTAL = Decimal("0.0925")
TOLERANCIA_PRECO = Decimal("0.02")


def _preco_com_pis_cofins(preco_liquido):
    p = _decimal(preco_liquido)
    if p is None:
        return None
    divisor = Decimal("1") - PIS_COFINS_TOTAL
    if divisor <= 0:
        return None
    return p / divisor


def _preco_min_max(candidatos, moeda):
    precos = []
    for c in candidatos:
        if moeda and _texto(c.get("moeda")) != moeda:
            continue
        p = _decimal(c.get("preco"))
        if p is not None:
            precos.append(p)
    if not precos:
        return None, None
    return min(precos), max(precos)


def _comparar_preco(preco_ariba, moeda_ariba, candidatos):
    p_ariba = _decimal(preco_ariba)
    moeda = _texto(moeda_ariba)

    mesmos_moeda = [
        c for c in candidatos
        if not moeda or _texto(c.get("moeda")) == moeda
    ]

    matches = []

    if p_ariba is not None:
        for c in mesmos_moeda:
            p_liquido = _decimal(c.get("preco"))
            p_esperado = _preco_com_pis_cofins(p_liquido)

            if (
                p_esperado is not None
                and abs(p_esperado - p_ariba) <= TOLERANCIA_PRECO
            ):
                matches.append(c)

    if not candidatos:
        return (
            "nao_encontrado", 0, 0,
            "Nenhuma condição ZNET vigente encontrada para o material.",
        )

    if not mesmos_moeda:
        return (
            "sem_mesma_moeda", len(candidatos), 0,
            "Há ZNET vigente para o material, porém nenhuma condição na mesma moeda do pedido.",
        )

    if matches:
        return (
            "compativel_candidato", len(candidatos), len(matches),
            "O preço do Ariba é compatível com o ZNET líquido + PIS/COFINS (9,25% por dentro).",
        )

    return (
        "sem_correspondencia_candidata", len(candidatos), 0,
        "Há ZNET vigente na mesma moeda, mas o valor esperado com PIS/COFINS não coincide com o Ariba.",
    )



def _dados_pagamento_ariba(payload):
    commercial = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}
    return {
        "codigo": _texto(commercial.get("payment_terms_code")),
        "descricao": _texto(commercial.get("payment_terms_description")),
        "detalhe": _texto(commercial.get("payment_terms_detail")),
        "valor": _texto(commercial.get("payment_terms")),
    }


def _normalizar_kunnr_pagamento(value):
    value = _texto(value)
    if not value:
        return None
    if value.isdigit():
        return value.zfill(10)
    return value.upper()


def _normalizar_mapeamentos_pagamento(mapeamentos):
    """Separa equivalências específicas por cliente e globais."""
    cliente = {}
    global_map = {}
    for item in (mapeamentos or []):
        if not isinstance(item, dict):
            continue
        kunnr = _normalizar_kunnr_pagamento(item.get("kunnr"))
        ariba = _texto(item.get("ariba_codigo") or item.get("ariba"))
        sap = _texto(item.get("sap_zterm") or item.get("zterm"))
        if not ariba or not sap:
            continue
        ariba = ariba.upper()
        sap = sap.upper()
        if kunnr:
            cliente.setdefault((kunnr, ariba), set()).add(sap)
        else:
            global_map.setdefault(ariba, set()).add(sap)
    return {
        "cliente": {k: sorted(v) for k, v in cliente.items()},
        "global": {k: sorted(v) for k, v in global_map.items()},
    }


def _resolver_mapeamento_pagamento(mapa, kunnr, codigo_ariba):
    """Prioriza KUNNR específico; usa global somente como fallback."""
    codigo = (_texto(codigo_ariba) or "").upper()
    kunnr_norm = _normalizar_kunnr_pagamento(kunnr)
    if not codigo:
        return [], None
    especificos = []
    if kunnr_norm:
        especificos = list((mapa.get("cliente") or {}).get((kunnr_norm, codigo), []))
    if especificos:
        return especificos, "cliente"
    globais = list((mapa.get("global") or {}).get(codigo, []))
    if globais:
        return globais, "global"
    return [], None


def _dados_entrega(payload):
    delivery = payload.get("delivery") if isinstance(payload.get("delivery"), dict) else {}
    customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
    return {
        "nome": _texto(customer.get("name")),
        "site": _texto(customer.get("site_name")),
        "cnpj": _texto(customer.get("cnpj")) or _texto(delivery.get("cnpj")) or _texto(delivery.get("bill_to_cnpj")),
        "cidade": _texto(delivery.get("city")),
        "cep": _texto(delivery.get("postal_code")),
        "rua": _texto(delivery.get("street")),
        "pais": _texto(delivery.get("country")),
        "ship_to_name": _texto(delivery.get("ship_to_name")),
    }


def _similaridade(a, b):
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return 0.0
    if a in b or b in a:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def _score_candidato(cliente, cand, knvv, kdgrp_hints):
    score = 0.0
    evidencias = []

    nome_cand = " ".join(x for x in [cand.get("name1"), cand.get("name2")] if x)
    sim_nome = _similaridade(cliente.get("nome"), nome_cand)
    score += sim_nome * 35
    if sim_nome >= 0.80:
        evidencias.append("nome")

    cnpj_pedido = _digits(cliente.get("cnpj"))
    if cnpj_pedido:
        cnpjs_cand = {_digits(cand.get("stcd1")), _digits(cand.get("stcd2"))} - {""}
        if cnpj_pedido in cnpjs_cand:
            score += 120
            evidencias.append("cnpj")
        elif cnpjs_cand:
            score -= 25

    cidade = _norm(cliente.get("cidade"))
    cidade_cand = _norm(cand.get("ort01"))
    if cidade and cidade_cand:
        if cidade == cidade_cand:
            score += 35
            evidencias.append("cidade")
        elif cidade in cidade_cand or cidade_cand in cidade:
            score += 20

    cep = _digits(cliente.get("cep"))
    cep_cand = _digits(cand.get("pstlz"))
    if cep and cep_cand:
        if cep == cep_cand:
            score += 40
            evidencias.append("cep")
        elif len(cep) >= 5 and len(cep_cand) >= 5 and cep[:5] == cep_cand[:5]:
            score += 18

    rua = _norm(cliente.get("rua"))
    rua_cand = _norm(cand.get("stras"))
    if rua and rua_cand:
        tokens = {x for x in rua.split() if len(x) >= 2}
        tokens_cand = {x for x in rua_cand.split() if len(x) >= 2}
        if tokens:
            overlap = len(tokens & tokens_cand) / max(1, len(tokens))
            if overlap >= 0.65:
                score += 35
                evidencias.append("endereco")
            elif overlap >= 0.35:
                score += 18

    site = " ".join(x for x in [cliente.get("site"), cliente.get("ship_to_name")] if x)
    if site:
        sim_site_nome = _similaridade(site, nome_cand)
        sim_site_cidade = _similaridade(site, cand.get("ort01"))
        score += max(sim_site_nome, sim_site_cidade) * 12

    kdgrps = {
        str(x.get("kdgrp") or "").strip()
        for x in (knvv or [])
        if str(x.get("vkorg") or "").strip().upper() == "BR10" and str(x.get("kdgrp") or "").strip()
    }
    if kdgrp_hints and kdgrps & set(kdgrp_hints):
        score += 70
        evidencias.append("kdgrp")

    return score, evidencias, sorted(kdgrps)



def _ship_to_code_payload(payload):
    """Obtém o código de local de entrega do Ariba sem depender de um único schema."""
    payload = payload if isinstance(payload, dict) else {}
    delivery = payload.get("delivery") if isinstance(payload.get("delivery"), dict) else {}

    candidatos = [
        delivery.get("ship_to_code"),
        delivery.get("po_ship_to_code"),
        delivery.get("item_ship_to_code"),
    ]

    itens = payload.get("items") if isinstance(payload.get("items"), list) else []
    for item in itens:
        if not isinstance(item, dict):
            continue

        item_ship_to = item.get("item_ship_to") if isinstance(item.get("item_ship_to"), dict) else {}
        raw_api = item.get("raw_api") if isinstance(item.get("raw_api"), dict) else {}

        candidatos.extend([
            item.get("ship_to_code"),
            item.get("item_ship_to_code"),
            item_ship_to.get("ship_to_code"),
            raw_api.get("itemShipToCode"),
            raw_api.get("poShipToCode"),
            raw_api.get("shipToCode"),
        ])

    for valor in candidatos:
        txt = _texto(valor)
        if txt:
            return txt.upper()
    return None


def _normalizar_mapeamentos_shipto(mapeamentos):
    mapa = {}
    for item in (mapeamentos or []):
        if not isinstance(item, dict):
            continue
        ship_to_code = (_texto(item.get("ship_to_code")) or "").upper()
        kunnr = _texto(item.get("kunnr"))
        if not ship_to_code or not kunnr:
            continue
        kunnr = kunnr.zfill(10) if kunnr.isdigit() else kunnr.upper()
        mapa[ship_to_code] = {
            "ship_to_code": ship_to_code,
            "kunnr": kunnr,
            "descricao": _texto(item.get("descricao")),
        }
    return mapa


def _resolver_kunnr(payload, kdgrp_hints, mapeamentos_shipto=None):
    explicito = _kunnr_explicito(payload)
    if explicito:
        return {
            "status": "explicito",
            "kunnr": explicito,
            "confianca": 100,
            "evidencias": ["campo explícito no payload"],
            "knvv": [],
        }

    ship_to_code = _ship_to_code_payload(payload)
    mapa_shipto = _normalizar_mapeamentos_shipto(mapeamentos_shipto)
    if ship_to_code and ship_to_code in mapa_shipto:
        regra = mapa_shipto[ship_to_code]
        return {
            "status": "resolvido_shipto",
            "kunnr": regra["kunnr"],
            "confianca": 100,
            "evidencias": ["ship_to_code_parametrizado"],
            "ship_to_code": ship_to_code,
            "ship_to_descricao": regra.get("descricao"),
            "knvv": [],
        }

    cliente = _dados_entrega(payload)
    if not cliente.get("nome"):
        return {
            "status": "sem_nome",
            "kunnr": None,
            "confianca": 0,
            "evidencias": [],
            "knvv": [],
        }

    candidatos = consultar_clientes_kna1(cliente.get("nome"), limite=80)
    if not candidatos:
        return {
            "status": "nao_encontrado",
            "kunnr": None,
            "confianca": 0,
            "evidencias": [],
            "knvv": [],
        }

    mapa_knvv = consultar_knvv_multiplos([c.get("kunnr") for c in candidatos])
    pontuados = []

    for cand in candidatos:
        kunnr = str(cand.get("kunnr") or "")
        knvv = mapa_knvv.get(kunnr, [])
        score, evidencias, kdgrps = _score_candidato(
            cliente, cand, knvv, kdgrp_hints
        )

        pontuados.append({
            "kunnr": kunnr,
            "score": round(score, 2),
            "evidencias": evidencias,
            "kdgrps": kdgrps,
            "cliente": cand,
            "knvv": knvv,
        })

    pontuados.sort(key=lambda x: x["score"], reverse=True)

    melhor = pontuados[0]
    segundo = pontuados[1] if len(pontuados) > 1 else None
    margem = melhor["score"] - (segundo["score"] if segundo else 0)

    # Regra original: evidência forte / margem suficiente.
    if melhor["score"] >= 70 and (
        margem >= 15
        or "cnpj" in melhor["evidencias"]
        or "kdgrp" in melhor["evidencias"]
    ):
        return {
            "status": "resolvido",
            "kunnr": melhor["kunnr"],
            "confianca": round(melhor["score"], 1),
            "evidencias": melhor["evidencias"],
            "kdgrps": melhor["kdgrps"],
            "knvv": melhor["knvv"],
            "candidato": melhor["cliente"],
        }

    # NOVA REGRA:
    # Em empate no MAIOR score, usa BR10 apenas se ele realmente
    # desambiguar sozinho. Não escolhe por "cadastro mais completo".
    maior_score = melhor["score"]
    empatados = [
        p for p in pontuados
        if abs(float(p["score"]) - float(maior_score)) < 0.01
    ]

    if melhor["score"] >= 70 and len(empatados) >= 2:
        empatados_br10 = []

        for p in empatados:
            possui_br10 = any(
                str(r.get("vkorg") or "").strip().upper() == "BR10"
                for r in (p.get("knvv") or [])
            )
            if possui_br10:
                empatados_br10.append(p)

        if len(empatados_br10) == 1:
            escolhido = empatados_br10[0]
            evidencias = list(escolhido.get("evidencias") or [])
            evidencias.append("desempate_knvv_br10")

            return {
                "status": "resolvido_br10",
                "kunnr": escolhido["kunnr"],
                "confianca": round(escolhido["score"], 1),
                "evidencias": evidencias,
                "kdgrps": escolhido["kdgrps"],
                "knvv": escolhido["knvv"],
                "candidato": escolhido["cliente"],
                "desempate": {
                    "regra": "unico_candidato_empatado_com_vkorg_br10",
                    "candidatos_empatados": [
                        p["kunnr"] for p in empatados
                    ],
                },
            }

    # Continua ambíguo quando não existe evidência suficiente.
    return {
        "status": "ambiguo",
        "kunnr": None,
        "confianca": round(melhor["score"], 1),
        "evidencias": melhor["evidencias"],
        "candidatos": pontuados[:5],
        "knvv": [],
    }

def _kdgrp_hints(pacotes_znet):
    hints = set()
    for pacote in pacotes_znet.values():
        for c in pacote.get("condicoes") or []:
            if c.get("origem") == "A813_KDGRP" and c.get("seletor"):
                hints.add(str(c.get("seletor")).strip())
    return sorted(hints)


def _selecionar_znet_cliente(candidatos, kunnr, kdgrps, kondas=None):
    """Replica a prioridade confirmada da access sequence ZNET no SAP.

    Ordem:
      10 -> A005 / KUNNR + MATNR
      15 -> A813 / KDGRP + MATNR
      20 -> A706 / KONDA (YR_KONDS) + MATNR

    Como os acessos estão marcados como Exclusive no SAP, a primeira
    condição aplicável encerra a seleção.
    """
    kunnr_sem_zero = (
        str(int(kunnr))
        if str(kunnr or "").isdigit()
        else str(kunnr or "").lstrip("0")
    )

    # 1) A005 — condição específica do cliente.
    a005 = [
        c for c in candidatos
        if c.get("origem") == "A005_KUNNR"
        and str(c.get("seletor") or "").lstrip("0") == kunnr_sem_zero
    ]
    if a005:
        return a005, "A005/KUNNR"

    # 2) A813 — grupo do cliente (KNVV.KDGRP).
    kdgrps = {str(x).strip() for x in (kdgrps or []) if str(x).strip()}
    a813 = [
        c for c in candidatos
        if c.get("origem") == "A813_KDGRP"
        and str(c.get("seletor") or "").strip() in kdgrps
    ]
    if a813:
        return a813, "A813/KDGRP"

    # 3) A706 — grupo de preço do cliente.
    # No DCLO, KNVV.KONDA é a fonte validada para o YR_KONDS da A706.
    kondas = {str(x).strip() for x in (kondas or []) if str(x).strip()}
    a706 = [
        c for c in candidatos
        if c.get("origem") == "A706_YR_KONDS"
        and str(c.get("seletor") or "").strip() in kondas
    ]
    if a706:
        return a706, "A706/KONDA"

    return [], None


# =============================================================================
# CONSTANTES FUNCIONAIS
# =============================================================================
CANAIS_VALIDOS = ("50", "52", "53")
CANAL_SEM_LOTE = "53"

VMSTA_DESCRICOES = {
    "AE": "Order/Production end",
    "AL": "Expired",
    "AN": "Active, not salable",
    "AS": "Order embargo",
    "AV": "Active, salable",
    "EW": "Development part",
    "LS": "Delivery embargo",
    "NL": "Not salable, expired",
    "PB": "Check valuation",
    "PT": "Prototype (specimen)",
    "PW": "Examination plant",
    "SN": "Service, not salable",
    "SR": "Service, repair only",
    "SV": "Service only",
    "UG": "Invalid (blocked)",
    "Z4": "Phase Out In Progress",
    "Z7": "New Material",
    "Z8": "PhaseOut / NoPurchase",
    "ZA": "Costing not Allowed",
    "ZP": "Quote/PriceBook Item",
}
VMSTA_LIBERADOS = {"AV", "AL"}

# Regras de Incoterm Ariba -> KNVV.INCO1 confirmadas funcionalmente.
INCOTERM_REGRAS = {"FOB": ["FCA"]}

BESKZ_DESCRICAO = {"F": "Comprado", "E": "Fabricado", "X": "Fabricado e comprado"}

_UNIDADES_PECA = {"EA", "EACH", "PC", "PCE", "PCS", "ST", "UN", "UND", "UNI", "UNID", "UNIT", "PÇ", "PECA", "PEÇA"}

FONTE_DALI_LOG = "DALI/KNVP (SP/ZR) + LFA1"
FONTE_DALI_REP = "DALI/KNVP (YV, BR10) + KNA1"

ZNET_ORIGEM_LABEL = {
    "A005_KUNNR": "A005 (cliente)",
    "A813_KDGRP": "A813 (grupo de clientes)",
    "A706_YR_KONDS": "A706 (grupo de preço)",
}


# =============================================================================
# UTILITÁRIOS
# =============================================================================
def _erro_txt(exc):
    return f"{type(exc).__name__}: {exc}"


def _safe(fn, *args, **kwargs):
    """Executa uma consulta externa sem deixar a exceção interromper o fluxo."""
    try:
        return fn(*args, **kwargs), None
    except Exception as exc:  # noqa: BLE001 — isolamento proposital
        return None, _erro_txt(exc)


def _crit(codigo, label, status, valor=None, detalhe=None, bloqueante=False, fonte=None):
    if fonte and detalhe:
        detalhe = f"{detalhe} Fonte: {fonte}."
    elif fonte:
        detalhe = f"Fonte: {fonte}."
    return {
        "codigo": codigo,
        "label": label,
        "status": status,
        "valor": valor,
        "detalhe": detalhe,
        "bloqueante": bool(bloqueante),
    }


def _dependente(codigo, label, motivo):
    """Critério que não pôde ser executado porque depende de outro.

    Não bloqueia sozinho: o critério de origem (KUNNR, canal, material...)
    já está bloqueando e aparece uma única vez em "O que impede a conclusão".
    """
    return _crit(codigo, label, "info", "Não executado", motivo, False)


def _fmt_num(value):
    d = _decimal(value)
    if d is None:
        return "—"
    if d == d.to_integral_value():
        return str(int(d))
    return f"{d.normalize():f}".replace(".", ",")


def _fmt_moeda(value, moeda):
    d = _decimal(value)
    if d is None:
        return "—"
    return f"{moeda or ''} {d.quantize(Decimal('0.01'))}".strip()


def _unidade(u):
    u = (_texto(u) or "").upper()
    return "UN" if u in _UNIDADES_PECA else u


def _kunnr_curto(kunnr):
    k = str(kunnr or "").strip()
    return str(int(k)) if k.isdigit() else k


# =============================================================================
# KNVV POR CANAL
# =============================================================================
def _knvv_canal(knvv, canal):
    """Valores da KNVV restritos ao canal (ou todos, quando o canal é desconhecido)."""
    detalhes = [d for d in (knvv or {}).get("detalhes") or [] if isinstance(d, dict)]
    if canal:
        detalhes = [d for d in detalhes if _texto(d.get("vtweg")) == canal]

    def valores(campo):
        return sorted({
            str(d.get(campo)).strip().upper()
            for d in detalhes
            if d.get(campo) not in (None, "") and str(d.get(campo)).strip()
        })

    return {
        "linhas": len(detalhes),
        "kdgrps": valores("kdgrp"),
        "kondas": valores("konda"),
        "zterms": valores("zterm"),
        "inco1s": valores("inco1"),
        "inco2s": valores("inco2"),
        "aufsds": valores("aufsd"),
        "lifsds": valores("lifsd"),
    }


def _determinar_canal(parametro_vtweg, knvv, knvv_erro):
    canais_knvv = sorted({
        _texto(d.get("vtweg"))
        for d in (knvv or {}).get("detalhes") or []
        if isinstance(d, dict) and _texto(d.get("vtweg"))
    })
    param = _texto(parametro_vtweg)

    if param:
        if knvv_erro:
            return {"canal": param, "status": "parametro_sem_conferencia",
                    "fonte": "Parâmetro do cliente no Portal", "disponiveis": canais_knvv}
        if canais_knvv and param not in canais_knvv:
            return {"canal": None, "status": "parametro_invalido",
                    "fonte": "Parâmetro do cliente no Portal", "disponiveis": canais_knvv,
                    "parametro": param}
        return {"canal": param, "status": "parametro",
                "fonte": "Parâmetro do cliente no Portal", "disponiveis": canais_knvv}

    if knvv_erro:
        return {"canal": None, "status": "erro", "fonte": "DCLO/KNVV_PRA",
                "disponiveis": [], "erro": knvv_erro}
    if len(canais_knvv) == 1:
        return {"canal": canais_knvv[0], "status": "knvv_unico",
                "fonte": "DCLO/KNVV_PRA (único canal BR10)", "disponiveis": canais_knvv}
    if len(canais_knvv) > 1:
        return {"canal": None, "status": "ambiguo", "fonte": "DCLO/KNVV_PRA",
                "disponiveis": canais_knvv}
    return {"canal": None, "status": "nao_encontrado", "fonte": "DCLO/KNVV_PRA",
            "disponiveis": []}


def _resolver_canal_por_historico_itens(canal_info, itens, kunnr):
    """Desempata cliente multicanal pelo histórico exato KUNNR + KDMAT.

    Só escolhe automaticamente quando todo histórico útil encontrado aponta
    exclusivamente para o mesmo VTWEG e esse canal existe na KNVV atual.
    Histórico ausente, misto ou conflitante mantém a pendência humana.
    """
    if not kunnr or (canal_info or {}).get("status") != "ambiguo":
        return canal_info, {}

    disponiveis = set((canal_info or {}).get("disponiveis") or [])
    historicos = {}
    canais_encontrados = set()
    conflito = False
    evidencias = []

    for it in itens or []:
        kdmat = _texto((it or {}).get("kdmat"))
        if not kdmat or kdmat in historicos:
            continue

        hist, err = _safe(consultar_historico_kdmat, kdmat, kunnr=kunnr)
        if err:
            historicos[kdmat] = {"erro": err}
            continue

        hist = hist or {}
        historicos[kdmat] = hist
        if hist.get("status") not in ("ok", "sugestao_ultimo"):
            continue

        vtwegs = sorted({
            _texto(v)
            for v in (hist.get("vtwegs") or [hist.get("vtweg")])
            if _texto(v)
        })

        # O próprio KDMAT já apareceu em mais de um canal: não é evidência
        # suficiente para escolher automaticamente.
        if len(vtwegs) != 1:
            if len(vtwegs) > 1:
                conflito = True
            continue

        vtweg = vtwegs[0]
        canais_encontrados.add(vtweg)
        evidencias.append({
            "kdmat": kdmat,
            "vtweg": vtweg,
            "ultimo_vbeln": _texto(hist.get("ultimo_vbeln")),
        })

    if conflito or len(canais_encontrados) != 1:
        return canal_info, historicos

    canal = next(iter(canais_encontrados))
    if disponiveis and canal not in disponiveis:
        return canal_info, historicos

    return {
        "canal": canal,
        "status": "historico_kdmat",
        "fonte": "DCLO/VBAK+VBAP (histórico KUNNR + KDMAT)",
        "disponiveis": sorted(disponiveis),
        "evidencias": evidencias,
    }, historicos


# =============================================================================
# PARÂMETROS DO CLIENTE (Portal)
# =============================================================================
def _parametro_cliente(kunnr, parametros):
    if not kunnr:
        return {}
    alvo = str(kunnr).strip()
    alvo = alvo.zfill(10) if alvo.isdigit() else alvo.upper()
    for p in parametros or []:
        if not isinstance(p, dict):
            continue
        k = str(p.get("kunnr") or "").strip()
        k = k.zfill(10) if k.isdigit() else k.upper()
        if k == alvo:
            return {
                "vtweg": _texto(p.get("vtweg")),
                "destino_mercadoria": _texto(p.get("destino_mercadoria")),
            }
    return {}


# =============================================================================
# DESTINO DA MERCADORIA
# =============================================================================
_CHAVES_DESTINO = ("material_usage", "materialUsage", "usage", "destino_mercadoria", "destinoMercadoria")


def _procurar_chave(obj, chaves, profundidade=3):
    if profundidade < 0:
        return None
    if isinstance(obj, dict):
        for chave in chaves:
            valor = _texto(obj.get(chave)) if not isinstance(obj.get(chave), (dict, list)) else None
            if valor:
                return valor
        for valor in obj.values():
            if isinstance(valor, (dict, list)):
                achado = _procurar_chave(valor, chaves, profundidade - 1)
                if achado:
                    return achado
    elif isinstance(obj, list):
        for valor in obj:
            achado = _procurar_chave(valor, chaves, profundidade - 1)
            if achado:
                return achado
    return None


def _resolver_destino(item_raw, payload, parametro):
    """Item → cabeçalho → contrato → parâmetro padrão do cliente."""
    destino = _procurar_chave(item_raw or {}, _CHAVES_DESTINO, 3)
    if destino:
        return destino, "item do pedido Ariba"

    additional = payload.get("additional") if isinstance(payload.get("additional"), dict) else {}
    destino = _procurar_chave(additional, _CHAVES_DESTINO, 1)
    if destino:
        return destino, "cabeçalho do pedido Ariba"

    for chave in ("contract", "contrato", "agreement", "master_agreement"):
        bloco = payload.get(chave)
        if bloco is None:
            bloco = (payload.get("commercial") or {}).get(chave) if isinstance(payload.get("commercial"), dict) else None
        destino = _procurar_chave(bloco, _CHAVES_DESTINO, 3) if bloco else None
        if destino:
            return destino, "contrato do pedido Ariba"

    destino = _texto((parametro or {}).get("destino_mercadoria"))
    if destino:
        return destino, "parâmetro padrão do cliente no Portal"
    return None, None


# =============================================================================
# CRITÉRIOS DO CLIENTE
# =============================================================================
def _criterios_cliente(ctx):
    cs = ctx["cliente_sap"]
    kunnr = ctx["kunnr"]
    canal = ctx["canal"]
    knvv_erro = ctx["knvv_erro"]
    kv = ctx["knvv_canal"]
    out = []

    # ---------------- KUNNR ----------------
    st = cs.get("status")
    if kunnr:
        evid = cs.get("evidencias") or []
        if st == "explicito":
            det = "KUNNR informado no pedido."
        elif st == "resolvido_shipto":
            det = f"Ship-to {cs.get('ship_to_code')} parametrizado no Portal."
        elif st == "resolvido_br10":
            det = "Único candidato empatado com área de vendas BR10."
        else:
            det = ("Evidências: " + ", ".join(evid) + ".") if evid else None
        out.append(_crit("kunnr", "Cliente SAP (KUNNR)", "ok", kunnr, det))
    elif st == "erro":
        out.append(_crit("kunnr", "Cliente SAP (KUNNR)", "erro", "Falha ao identificar o cliente",
                         cs.get("erro"), True))
    elif st == "ambiguo":
        cands = ", ".join(str(c.get("kunnr")) for c in (cs.get("candidatos") or [])[:5])
        out.append(_crit("kunnr", "Cliente SAP (KUNNR)", "dados", "Mais de um cliente possível",
                         f"Candidatos: {cands or '—'}. Cadastre o Ship-to do pedido em Parâmetros "
                         "para identificar o cliente sem ambiguidade.", True))
    else:
        out.append(_crit("kunnr", "Cliente SAP (KUNNR)", "dados", "Cliente não identificado",
                         "Nenhum cliente da KNA1 atende às evidências do pedido. Cadastre o Ship-to "
                         "do pedido em Parâmetros.", True))

    if not kunnr:
        aguardando = "Aguardando identificação do KUNNR."
        for cod, lab in (("canal", "Canal de distribuição"), ("pagamento", "Condição de pagamento"),
                         ("transportadora", "Transportadora"), ("redespacho", "Redespacho"),
                         ("representante", "Representante"), ("bloqueio_ordem", "Bloqueio de ordem"),
                         ("bloqueio_remessa", "Bloqueio de remessa")):
            out.append(_dependente(cod, lab, aguardando))
        return out

    # ---------------- Canal ----------------
    c = ctx["canal_info"]
    disp = "/".join(c.get("disponiveis") or []) or "nenhum"
    if c["status"] == "parametro":
        out.append(_crit("canal", "Canal de distribuição", "ok", f"VTWEG {canal}",
                         f"Definido no parâmetro do cliente. Canais na KNVV BR10: {disp}."))
    elif c["status"] == "parametro_sem_conferencia":
        out.append(_crit("canal", "Canal de distribuição", "ok", f"VTWEG {canal}",
                         "Definido no parâmetro do cliente (KNVV indisponível para conferência)."))
    elif c["status"] == "knvv_unico":
        out.append(_crit("canal", "Canal de distribuição", "ok", f"VTWEG {canal}",
                         "Único canal do cliente em BR10.", fonte="DCLO/KNVV_PRA"))
    elif c["status"] == "regra_sv_53":
        original = _texto(c.get("canal_original")) or "50/52"
        out.append(_crit(
            "canal", "Canal de distribuição", "ok", "VTWEG 53",
            f"Canal originalmente identificado: VTWEG {original}. O material está com VMSTA SV nesse canal; "
            "pela regra de Service, o item foi direcionado ao canal 53.",
            fonte="Regra funcional SV → canal 53",
        ))
    elif c["status"] == "historico_kdmat":
        evidencias = c.get("evidencias") or []
        refs = ", ".join(
            f"KDMAT {e.get('kdmat')} / OV {e.get('ultimo_vbeln') or '—'}"
            for e in evidencias
        )
        detalhe = (
            f"Cliente com múltiplos canais na KNVV ({disp}); o histórico exato "
            f"KUNNR + KDMAT aponta exclusivamente para VTWEG {canal}."
        )
        if refs:
            detalhe += f" Evidência: {refs}."
        out.append(_crit("canal", "Canal de distribuição", "ok", f"VTWEG {canal}",
                         detalhe, fonte="DCLO/VBAK+VBAP"))
    elif c["status"] == "parametro_invalido":
        out.append(_crit("canal", "Canal de distribuição", "divergencia",
                         f"Parâmetro {c.get('parametro')} não existe na KNVV",
                         f"O cliente possui em BR10 apenas os canais {disp}. Corrija o parâmetro do cliente.",
                         True))
    elif c["status"] == "ambiguo":
        out.append(_crit("canal", "Canal de distribuição", "dados", f"Canais {disp}",
                         "O cliente possui mais de um canal em BR10 e a automação não escolhe um "
                         "sozinha. Cadastre o canal em Parâmetros > Parâmetros por cliente.", True))
    elif c["status"] == "erro":
        out.append(_crit("canal", "Canal de distribuição", "erro", "Falha na consulta KNVV",
                         knvv_erro, True))
    else:
        out.append(_crit("canal", "Canal de distribuição", "divergencia", "Sem área de vendas BR10",
                         "O cliente não possui KNVV em BR10 nos canais 50/52/53.", True,
                         fonte="DCLO/KNVV_PRA"))

    sem_canal = "Aguardando definição do canal de distribuição."

    # ---------------- Pagamento ----------------
    pag = ctx["pagamento_ariba"]
    cod_ariba = (_texto(pag.get("codigo")) or "").upper() or None
    ariba_txt = pag.get("detalhe") or pag.get("descricao") or cod_ariba or "não informada"
    if knvv_erro:
        out.append(_crit("pagamento", "Condição de pagamento", "erro", "Falha na consulta KNVV", knvv_erro, True))
    elif not canal and len(kv["zterms"]) > 1:
        out.append(_dependente("pagamento", "Condição de pagamento",
                               f"ZTERM varia por canal ({'/'.join(kv['zterms'])}). {sem_canal}"))
    elif not cod_ariba:
        out.append(_crit("pagamento", "Condição de pagamento", "divergencia", f"Ariba: {ariba_txt}",
                         "O pedido não trouxe código de condição de pagamento.", True))
    elif not kv["zterms"]:
        out.append(_crit("pagamento", "Condição de pagamento", "divergencia", f"Ariba {cod_ariba} · SAP sem ZTERM",
                         "A KNVV do cliente não possui ZTERM no canal.", True, fonte="DCLO/KNVV_PRA"))
    else:
        zterms = kv["zterms"]
        esperados, escopo = _resolver_mapeamento_pagamento(ctx["mapa_pagamento"], kunnr, cod_ariba)
        valor = f"Ariba {cod_ariba} · SAP {'/'.join(zterms)}"
        if cod_ariba in zterms:
            out.append(_crit("pagamento", "Condição de pagamento", "ok", valor, "Código idêntico no Ariba e no SAP."))
        elif esperados and set(esperados) & set(zterms):
            esc = "específica do cliente" if escopo == "cliente" else "global"
            out.append(_crit("pagamento", "Condição de pagamento", "ok", valor,
                             f"Compatível pela equivalência {esc} {cod_ariba} → {'/'.join(esperados)}."))
        elif esperados:
            out.append(_crit("pagamento", "Condição de pagamento", "divergencia", valor,
                             f"A equivalência cadastrada espera ZTERM {'/'.join(esperados)}.", True))
        else:
            out.append(_crit("pagamento", "Condição de pagamento", "dados", valor,
                             f"Não há equivalência cadastrada para o código Ariba {cod_ariba}. "
                             "Cadastre em Parâmetros > Condição de pagamento (Ariba → ZTERM SAP).", True))

    # ---------------- Parceiros DALI ----------------
    dali = ctx["dali"]
    dali_erro = ctx["dali_erro"]

    def _nomes(regs):
        nomes = []
        for r in regs or []:
            if isinstance(r, dict):
                n = _texto(r.get("name1")) or _texto(r.get("lifnr")) or _texto(r.get("kunnr2"))
                if n and n not in nomes:
                    nomes.append(n)
        return " / ".join(nomes) or "Vários registros"

    if dali_erro:
        out.append(_crit("transportadora", "Transportadora", "erro", "Falha na consulta DALI", dali_erro, True))
    else:
        s = dali.get("transportadora_status")
        if s == "ok":
            out.append(_crit("transportadora", "Transportadora", "ok", dali.get("transportadora"),
                             fonte=FONTE_DALI_LOG + " – PARVW SP"))
        elif s == "ambiguo":
            out.append(_crit("transportadora", "Transportadora", "dados", _nomes(dali.get("transportadoras")),
                             "Mais de uma transportadora (SP) para o cliente; nenhuma foi escolhida.", True))
        else:
            out.append(_crit("transportadora", "Transportadora", "dados", "Não cadastrada",
                             "Nenhum parceiro SP no DALI para o cliente.", True))

    red_ariba = ctx["redespacho_ariba"]
    if red_ariba:
        out.append(_crit("redespacho", "Redespacho", "ok", red_ariba, "Informado no pedido do cliente."))
    elif dali_erro:
        out.append(_crit("redespacho", "Redespacho", "erro", "Falha na consulta DALI", dali_erro, True))
    else:
        s = dali.get("redespacho_status")
        if s == "ok":
            out.append(_crit("redespacho", "Redespacho", "ok", dali.get("redespacho"),
                             fonte=FONTE_DALI_LOG + " – PARVW ZR"))
        elif s == "ambiguo":
            out.append(_crit("redespacho", "Redespacho", "dados", _nomes(dali.get("redespachos")),
                             "Mais de um redespacho (ZR) para o cliente; nenhum foi escolhido.", True))
        else:
            out.append(_crit("redespacho", "Redespacho", "ok", "Sem redespacho",
                             "Pedido sem redespacho e cliente sem parceiro ZR no DALI.", False))

    if dali_erro:
        out.append(_crit("representante", "Representante", "erro", "Falha na consulta DALI", dali_erro, True))
    else:
        s = dali.get("representante_status")
        if s == "ok":
            out.append(_crit("representante", "Representante", "ok", dali.get("representante"),
                             fonte=FONTE_DALI_REP))
        elif s == "ambiguo":
            out.append(_crit("representante", "Representante", "dados", _nomes(dali.get("representantes")),
                             "Mais de um representante (YV) em BR10; nenhum foi escolhido.", True))
        else:
            out.append(_crit("representante", "Representante", "dados", "Não cadastrado",
                             "Nenhum parceiro YV em BR10 no DALI para o cliente.", True))

    # ---------------- Bloqueios (informativos) ----------------
    for cod, lab, campo, chave in (("bloqueio_ordem", "Bloqueio de ordem", "AUFSD", "aufsds"),
                                   ("bloqueio_remessa", "Bloqueio de remessa", "LIFSD", "lifsds")):
        if knvv_erro:
            out.append(_crit(cod, lab, "info", "Consulta não concluída", knvv_erro))
        elif kv[chave]:
            out.append(_crit(cod, lab, "info", f"{campo}: {'/'.join(kv[chave])}",
                             "Código presente no cadastro. A interpretação comercial cabe ao time de vendas."))
        else:
            out.append(_crit(cod, lab, "ok", "Sem código cadastrado",
                             f"{campo} vazio na KNVV{' do canal ' + canal if canal else ''}."))
    return out


# =============================================================================
# CONDIÇÃO DE TRANSPORTE (nível pedido, exibida em Logística)
# =============================================================================
def _criterio_transporte(ctx):
    if not ctx["kunnr"]:
        return _dependente("condicao_transporte", "Condição de transporte", "Aguardando identificação do KUNNR.")
    if ctx["knvv_erro"]:
        return _crit("condicao_transporte", "Condição de transporte", "erro", "Falha na consulta KNVV",
                     ctx["knvv_erro"], True)
    ariba = (_texto(ctx["transporte_ariba"].get("incoterms")) or "").upper() or None
    inco1s = ctx["knvv_canal"]["inco1s"]
    sap = "/".join(inco1s) or "sem INCO1"
    valor = f"Ariba {ariba or '—'} · SAP {sap}"
    if not ctx["canal"] and len(inco1s) > 1:
        return _dependente("condicao_transporte", "Condição de transporte",
                           f"INCO1 varia por canal ({sap}). Aguardando definição do canal.")
    if not ariba:
        return _crit("condicao_transporte", "Condição de transporte", "divergencia", valor,
                     "O pedido não trouxe Incoterm.", True)
    if not inco1s:
        return _crit("condicao_transporte", "Condição de transporte", "divergencia", valor,
                     "A KNVV do cliente não possui INCO1 no canal.", True)
    if ariba in inco1s:
        return _crit("condicao_transporte", "Condição de transporte", "ok", valor, "Incoterm idêntico.")
    esperados = INCOTERM_REGRAS.get(ariba)
    if esperados and inco1s[0] in esperados:
        return _crit("condicao_transporte", "Condição de transporte", "ok", valor,
                     f"Compatível pela regra funcional {ariba} → {'/'.join(esperados)}.")
    if esperados:
        return _crit("condicao_transporte", "Condição de transporte", "divergencia", valor,
                     f"A regra {ariba} → {'/'.join(esperados)} não confere com o INCO1 do cliente.", True)
    return _crit("condicao_transporte", "Condição de transporte", "dados", valor,
                 f"Não há regra confirmada para o Incoterm {ariba}. Hoje só FOB → FCA está validado.", True)


# =============================================================================
# MATERIAL
# =============================================================================
def _resolver_material(it, kunnr):
    """Resolve o MATNR do item e devolve o critério KNMT correspondente.

    Retorna dict com matnr, origem, critério matnr, critério knmt e campos de
    rastreabilidade usados pelo Portal (sugestão histórica).
    """
    matnr = it["matnr_ariba"]
    kdmat = it["kdmat"]
    r = {
        "matnr": matnr,
        "matnr_origem": "Pedido Ariba" if matnr else None,
        "knmt_status": None, "knmt_matnr": None, "knmt_erro": None,
        "historico_kdmat_status": None, "historico_kdmat_matnr": None,
        "historico_kdmat_matnrs": [], "historico_kdmat_ultimo_vbeln": None,
        "historico_kdmat_erro": None, "fallback_historico_usado": False,
        "crit_matnr": None, "crit_knmt": None,
    }

    # MATNR informado no pedido tem prioridade.
    if matnr:
        r["crit_matnr"] = _crit("matnr", "Material Bosch (MATNR)", "ok", matnr, "Informado no pedido.")
        if kdmat and kunnr:
            knmt, err = _safe(consultar_knmt, kdmat, kunnr=kunnr)
            if err:
                r["knmt_status"], r["knmt_erro"] = "erro", err
                r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "info",
                                       "Conferência não concluída", f"Falha na KNMT: {err}. O MATNR do pedido foi mantido.")
            else:
                r["knmt_status"] = knmt.get("status")
                r["knmt_matnr"] = _texto(knmt.get("matnr"))
                if r["knmt_status"] == "ok" and r["knmt_matnr"] and r["knmt_matnr"] != matnr:
                    r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "divergencia",
                                           f"KDMAT {kdmat} → MATNR {r['knmt_matnr']}",
                                           f"O pedido informa MATNR {matnr}, mas a KNMT do cliente aponta {r['knmt_matnr']}.",
                                           True)
                elif r["knmt_status"] == "ok":
                    r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "ok",
                                           f"KDMAT {kdmat} → MATNR {matnr}", "Relação cadastrada no SAP.")
                else:
                    r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "info",
                                           "Relação não cadastrada",
                                           f"KUNNR {kunnr} + KDMAT {kdmat} não está na KNMT. O MATNR do pedido "
                                           "foi utilizado; recomenda-se cadastrar a relação no SAP.")
        return r

    # Sem MATNR: depende do KDMAT.
    if not kdmat:
        r["crit_matnr"] = _crit("matnr", "Material Bosch (MATNR)", "divergencia", "Pedido sem material",
                                "O item não traz MATNR Bosch nem código de material do cliente.", True)
        return r
    if not kunnr:
        r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)",
                                      f"KDMAT {kdmat}: a KNMT depende do KUNNR.")
        return r

    knmt, err = _safe(consultar_knmt, kdmat, kunnr=kunnr)
    if err:
        r["knmt_status"], r["knmt_erro"] = "erro", err
        r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)", "Aguardando consulta KNMT.")
        r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "erro",
                               "Falha na consulta KNMT", err, True)
        return r

    r["knmt_status"] = knmt.get("status")
    r["knmt_matnr"] = _texto(knmt.get("matnr"))

    if r["knmt_status"] == "ok" and r["knmt_matnr"]:
        r["matnr"], r["matnr_origem"] = r["knmt_matnr"], "KNMT"
        r["crit_matnr"] = _crit("matnr", "Material Bosch (MATNR)", "ok", r["matnr"], "Obtido pela KNMT.")
        r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "ok",
                               f"KDMAT {kdmat} → MATNR {r['matnr']}", "Relação cadastrada no SAP.")
        return r

    if r["knmt_status"] == "ambiguo":
        lista = "/".join(knmt.get("matnrs") or [])
        r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)", "KNMT ambígua.")
        r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "divergencia",
                               "Mais de um MATNR na KNMT",
                               f"KUNNR {kunnr} + KDMAT {kdmat} aponta para {lista}. Corrija o cadastro no SAP.", True)
        return r

    if r["knmt_status"] == "matnr_invalido":
        r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)", "KNMT com MATNR inválido.")
        r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "divergencia",
                               "MATNR fora do padrão na KNMT",
                               "A KNMT retornou material sem 10 caracteres. Corrija o cadastro no SAP.", True)
        return r

    # KNMT sem relação → histórico VBAK/VBAP como sugestão.
    hist, herr = _safe(consultar_historico_kdmat, kdmat, kunnr=kunnr)
    if herr:
        r["historico_kdmat_status"], r["historico_kdmat_erro"] = "erro", herr
        r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)", "Aguardando consulta do histórico.")
        r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "erro",
                               "Falha na consulta do histórico",
                               f"KNMT sem relação e o histórico VBAK/VBAP falhou: {herr}", True)
        return r

    r["historico_kdmat_status"] = hist.get("status")
    r["historico_kdmat_matnr"] = _texto(hist.get("matnr"))
    r["historico_kdmat_matnrs"] = hist.get("matnrs") or []
    r["historico_kdmat_ultimo_vbeln"] = _texto(hist.get("ultimo_vbeln"))

    if r["historico_kdmat_status"] in ("ok", "sugestao_ultimo") and r["historico_kdmat_matnr"]:
        sug = r["historico_kdmat_matnr"]
        r["matnr"], r["matnr_origem"] = sug, "Histórico VBAK/VBAP (sugestão)"
        r["fallback_historico_usado"] = True
        varios = len(r["historico_kdmat_matnrs"]) > 1
        r["crit_matnr"] = _crit("matnr", "Material Bosch (MATNR)", "ok", sug,
                                "Sugestão do histórico usada para continuar as validações técnicas.")
        r["crit_knmt"] = _crit(
            "knmt_relacao", "Material do cliente (KNMT)", "funcional",
            f"Sugestão histórica: MATNR {sug}",
            f"KUNNR {kunnr} + KDMAT {kdmat} não está na KNMT. "
            + (f"O histórico tem {len(r['historico_kdmat_matnrs'])} materiais "
               f"({'/'.join(r['historico_kdmat_matnrs'])}); sugerido o do pedido mais recente "
               f"(OV {r['historico_kdmat_ultimo_vbeln']}). " if varios else
               f"O histórico aponta somente este material (OV {r['historico_kdmat_ultimo_vbeln'] or '—'}). ")
            + "Confirme ou rejeite a sugestão.",
            True)
        return r

    r["crit_matnr"] = _dependente("matnr", "Material Bosch (MATNR)", "Material não resolvido.")
    r["crit_knmt"] = _crit("knmt_relacao", "Material do cliente (KNMT)", "divergencia",
                           "Relação KNMT não cadastrada",
                           f"KUNNR {kunnr} + KDMAT {kdmat} não está na KNMT e não há histórico de vendas. "
                           "Solicite o cadastro da relação no SAP.", True)
    return r


def _normalizar_mapeamentos_mvke(mapeamentos):
    mapa = {}
    for item in (mapeamentos or []):
        if not isinstance(item, dict):
            continue
        codigo = (_texto(item.get("codigo_vmsta") or item.get("vmsta")) or "").upper()
        classificacao = (_texto(item.get("classificacao")) or "").lower()
        if codigo and classificacao in ("compativel", "divergencia", "informativo"):
            mapa[codigo] = {"classificacao": classificacao, "descricao": _texto(item.get("descricao"))}
    return mapa


def _avaliar_vmsta(canal, mvke_canal, mapa_mvke):
    if not canal:
        return _dependente("vmsta", "Status de venda (VMSTA)", "Aguardando definição do canal.")
    if not mvke_canal:
        return _crit("vmsta", "Status de venda (VMSTA)", "divergencia", f"Sem MVKE BR10/{canal}",
                     f"O material não está estendido para a organização BR10 no canal {canal}.", True,
                     fonte="DCLO/CL_MVKE_PRA")
    codigo = (_texto(mvke_canal.get("vmsta")) or "").upper()
    if not codigo:
        return _crit("vmsta", "Status de venda (VMSTA)", "ok", "Sem restrição",
                     f"VMSTA vazio no canal {canal}.", fonte="DCLO/CL_MVKE_PRA")
    desc = VMSTA_DESCRICOES.get(codigo) or (mapa_mvke.get(codigo) or {}).get("descricao")
    valor = f"{codigo} – {desc}" if desc else codigo
    if codigo in VMSTA_LIBERADOS:
        return _crit("vmsta", "Status de venda (VMSTA)", "ok", valor, f"Liberado para venda (canal {canal}).")
    regra = mapa_mvke.get(codigo)
    if regra:
        cls = regra.get("classificacao")
        if cls == "compativel":
            return _crit("vmsta", "Status de venda (VMSTA)", "ok", valor, "Compatível pelo mapeamento do Portal.")
        if cls == "informativo":
            return _crit("vmsta", "Status de venda (VMSTA)", "info", valor, "Informativo pelo mapeamento do Portal.")
        return _crit("vmsta", "Status de venda (VMSTA)", "divergencia", valor,
                     "Bloqueado pelo mapeamento do Portal.", True)
    if codigo == "SV":
        if canal == "53":
            return _crit(
                "vmsta", "Status de venda (VMSTA)", "ok", valor,
                "Status Service only permitido no canal 53 pela regra funcional de Service.",
                fonte="DCLO/CL_MVKE_PRA",
            )
        return _crit(
            "vmsta", "Status de venda (VMSTA)", "divergencia", valor,
            "Status SV exige processamento pelo canal 53. Não foi possível aplicar o redirecionamento "
            "automático para este item.",
            True, fonte="DCLO/CL_MVKE_PRA",
        )
    return _crit("vmsta", "Status de venda (VMSTA)", "divergencia", valor,
                 "Somente AV e AL seguem; os demais status bloqueiam (regra funcional).", True)


def _determinar_centro(canal, mvke_canal, marc):
    plantas = sorted({(_texto(m.get("werks")) or "").upper() for m in marc if _texto(m.get("werks"))})
    sobsls = sorted({(_texto(m.get("sobsl")) or "").upper() for m in marc if _texto(m.get("sobsl"))})
    dwerk = (_texto((mvke_canal or {}).get("dwerk")) or "").upper() or None
    info = {"plantas": plantas, "sobsl": sobsls, "dwerk": dwerk, "centro": None, "regra": None}

    if not canal:
        return info, _dependente("centro", "Centro fornecedor", "Aguardando definição do canal.")

    if canal == "53":
        info.update(centro="BR10", regra="Canal 53 sai por BR10")
    elif "BR10" in plantas and "BR20" in plantas:
        if "Z4" in sobsls:
            info.update(centro="BR20", regra="Material em BR10 e BR20 com suprimento especial SOBSL Z4")
        else:
            info.update(centro="BR10", regra="Material em BR10 e BR20 sem SOBSL Z4")
    elif dwerk:
        info.update(centro=dwerk, regra="Centro fornecedor da MVKE (DWERK)")
    elif len(plantas) == 1:
        info.update(centro=plantas[0], regra="Único centro BR na MARC")

    if not info["centro"]:
        return info, _crit("centro", "Centro fornecedor", "dados", "Não determinado",
                           f"MVKE sem DWERK no canal {canal} e material sem centro BR único na MARC.", True)

    if plantas and info["centro"] not in plantas:
        return info, _crit("centro", "Centro fornecedor", "divergencia", info["centro"],
                           f"{info['regra']}, mas o material não está cadastrado no centro {info['centro']} "
                           f"(MARC: {'/'.join(plantas)}).", True)

    det = f"{info['regra']}. DWERK do canal: {dwerk or '—'}; SOBSL: {'/'.join(sobsls) or '—'}."
    return info, _crit("centro", "Centro fornecedor", "ok", info["centro"], det)


def _criterio_obtencao(centro, marc):
    if not centro:
        return None
    linha = next((m for m in marc if (_texto(m.get("werks")) or "").upper() == centro), None)
    beskz = (_texto((linha or {}).get("beskz")) or "").upper()
    if not beskz:
        return _crit("obtencao", "Tipo de obtenção (BESKZ)", "info", "Não informado", f"MARC {centro} sem BESKZ.")
    return _crit("obtencao", "Tipo de obtenção (BESKZ)", "info",
                 f"{beskz} – {BESKZ_DESCRICAO.get(beskz, 'outro')}", f"MARC do centro {centro}.")


def _avaliar_lote(canal, quantidade, uom, mvke_canal):
    if not canal:
        return _dependente("lote", "Lote mínimo / múltiplo", "Aguardando definição do canal.")
    if canal == CANAL_SEM_LOTE:
        return _crit("lote", "Lote mínimo / múltiplo", "ok", "Não se aplica",
                     "Pedidos no canal 53 não utilizam lote.")
    if not mvke_canal:
        return _dependente("lote", "Lote mínimo / múltiplo", "Sem MVKE no canal.")

    minimo = _decimal(mvke_canal.get("lote_minimo_sd"))
    multiplo = _decimal(mvke_canal.get("lote_multiplo_sd"))
    un_lote = _unidade(mvke_canal.get("lote_multiplo_un_med_sd"))
    qtd = _decimal(quantidade)
    un_ped = _unidade(uom)
    minimo = minimo if minimo and minimo > 0 else None
    multiplo = multiplo if multiplo and multiplo > 0 else None

    if not minimo and not multiplo:
        return _crit("lote", "Lote mínimo / múltiplo", "ok", "Sem lote cadastrado",
                     f"MVKE BR10/{canal} sem AUMNG/SCMNG.")
    regra_txt = f"mínimo {_fmt_num(minimo) if minimo else '—'} · múltiplo {_fmt_num(multiplo) if multiplo else '—'}"
    if qtd is None:
        return _crit("lote", "Lote mínimo / múltiplo", "divergencia", f"Quantidade não informada · {regra_txt}",
                     "O item não traz quantidade.", True)
    if un_lote and un_ped and un_lote != un_ped:
        return _crit("lote", "Lote mínimo / múltiplo", "info", f"Qtd {_fmt_num(qtd)} {uom} · {regra_txt} {un_lote}",
                     "Unidades diferentes entre pedido e MVKE; confira o lote manualmente.")
    problemas = []
    if minimo and qtd < minimo:
        problemas.append(f"quantidade abaixo do mínimo {_fmt_num(minimo)}")
    if multiplo and (qtd % multiplo) != 0:
        problemas.append(f"quantidade não é múltipla de {_fmt_num(multiplo)}")
    valor = f"Qtd {_fmt_num(qtd)} · {regra_txt}"
    if problemas:
        return _crit("lote", "Lote mínimo / múltiplo", "divergencia", valor,
                     "Pedido fora do lote: " + "; ".join(problemas) + ".", True, fonte=f"MVKE BR10/{canal}")
    return _crit("lote", "Lote mínimo / múltiplo", "ok", valor, fonte=f"MVKE BR10/{canal}")


# =============================================================================
# PREÇO — ZNET / ZIAD
# =============================================================================
def _avaliar_znet(matnr, kunnr, kdgrps, kondas, preco_ariba, moeda_ariba, pacote, pacote_erro):
    r = {"znet_status": None, "znet_origem": "A005+A813+A706", "znet_condicoes": 0, "znet_matches": 0,
         "znet_preco_min": None, "znet_preco_max": None, "znet_detalhes": [], "crit": None}

    if not matnr:
        r["znet_status"] = "pendente_material"
        r["crit"] = _dependente("znet", "Preço ZNET", "Aguardando material.")
        return r
    if not kunnr:
        r["znet_status"] = "pendente_kunnr"
        r["crit"] = _dependente("znet", "Preço ZNET", "Aguardando identificação do KUNNR.")
        return r

    candidatos = (pacote or {}).get("condicoes") or []
    erros_fontes = (pacote or {}).get("erros_fontes") or []
    r["znet_condicoes"] = len(candidatos)

    selecionadas, regra = _selecionar_znet_cliente(candidatos, kunnr, kdgrps, kondas)
    if not selecionadas and not pacote_erro:
        direta, _ = _safe(consultar_znet, matnr, kunnr)
        if direta:
            selecionadas, regra = [direta], "A005/KUNNR"

    if not selecionadas:
        if pacote_erro or erros_fontes:
            falhas = pacote_erro or "; ".join(f"{e.get('origem')}: {e.get('erro')}" for e in erros_fontes)
            r["znet_status"] = "erro"
            r["crit"] = _crit("znet", "Preço ZNET", "erro", "Falha na consulta ZNET", falhas, True)
            return r
        r["znet_status"] = "nao_encontrado"
        r["crit"] = _crit("znet", "Preço ZNET", "divergencia", "Nenhuma condição encontrada",
                          f"Nenhuma ZNET vigente para o MATNR {matnr} em A005 (KUNNR {_kunnr_curto(kunnr)}), "
                          f"A813 (KDGRP {'/'.join(kdgrps) or '—'}) ou A706 (KONDA {'/'.join(kondas) or '—'}).",
                          True)
        return r

    r["znet_origem"] = regra
    r["znet_detalhes"] = selecionadas
    moeda = _texto(moeda_ariba)
    mesma_moeda = [c for c in selecionadas if not moeda or _texto(c.get("moeda")) == moeda]
    precos = [_decimal(c.get("preco")) for c in (mesma_moeda or selecionadas) if _decimal(c.get("preco")) is not None]
    if precos:
        r["znet_preco_min"], r["znet_preco_max"] = float(min(precos)), float(max(precos))

    if not mesma_moeda:
        moedas = "/".join(sorted({_texto(c.get("moeda")) or "—" for c in selecionadas}))
        r["znet_status"] = "sem_mesma_moeda"
        r["crit"] = _crit("znet", "Preço ZNET", "divergencia", f"Ariba {moeda} · ZNET {moedas}",
                          f"Condição {regra} encontrada em outra moeda. Sem regra oficial de câmbio, "
                          "verifique a moeda enviada pelo cliente.", True)
        return r

    p_ariba = _decimal(preco_ariba)
    if p_ariba is None:
        r["znet_status"] = "sem_preco_ariba"
        r["crit"] = _crit("znet", "Preço ZNET", "divergencia", "Pedido sem preço unitário",
                          "O item do Ariba não traz preço unitário.", True)
        return r

    esperados = []
    for c in mesma_moeda:
        liq = _decimal(c.get("preco"))
        esp = _preco_com_pis_cofins(liq)
        if esp is not None:
            esperados.append((c, liq, esp))
    matches = [e for e in esperados if abs(e[2] - p_ariba) <= TOLERANCIA_PRECO]
    r["znet_matches"] = len(matches)

    if matches:
        c, liq, esp = matches[0]
        r["znet_status"] = "compativel_exato"
        r["crit"] = _crit("znet", "Preço ZNET", "ok",
                          f"Ariba {_fmt_moeda(p_ariba, moeda)} · ZNET {_fmt_moeda(liq, moeda)} + PIS/COFINS",
                          f"Condição {regra} (chave {c.get('chave')}). Esperado com PIS/COFINS 9,25% por dentro: "
                          f"{_fmt_moeda(esp, moeda)}.")
        return r

    c, liq, esp = esperados[0] if esperados else (mesma_moeda[0], _decimal(mesma_moeda[0].get("preco")), None)
    r["znet_status"] = "divergente_exato"
    r["crit"] = _crit("znet", "Preço ZNET", "divergencia",
                      f"Ariba {_fmt_moeda(p_ariba, moeda)} · esperado {_fmt_moeda(esp, moeda)}",
                      f"Condição {regra} (chave {c.get('chave')}): ZNET líquido {_fmt_moeda(liq, moeda)}; "
                      f"com PIS/COFINS 9,25% por dentro esperado {_fmt_moeda(esp, moeda)}.", True)
    return r


def _avaliar_ziad(kunnr, prodh1, prodh1_status, material_ok, cache_ziad_cliente):
    r = {"ziad_status": None, "ziad_detalhes": [], "crit": None}
    if not kunnr:
        r["ziad_status"] = "aguardando_kunnr"
        r["crit"] = _dependente("ziad", "Desconto ZIAD", "Aguardando identificação do KUNNR.")
        return r

    if "tem" not in cache_ziad_cliente:
        tem, err = _safe(tem_ziad_cliente, kunnr)
        cache_ziad_cliente["tem"], cache_ziad_cliente["erro"] = tem, err
    if cache_ziad_cliente.get("erro"):
        r["ziad_status"] = "erro"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "erro", "Falha na consulta ZIAD", cache_ziad_cliente["erro"], True)
        return r
    if not cache_ziad_cliente.get("tem"):
        r["ziad_status"] = "nao_encontrada"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "ok", "Nenhuma ZIAD vigente",
                          "O cliente não possui ZIAD vigente; não há desconto adicional.")
        return r
    if not material_ok:
        r["ziad_status"] = "pendente_prodh1"
        r["crit"] = _dependente("ziad", "Desconto ZIAD", "O cliente possui ZIAD; aguardando dados do material.")
        return r
    if prodh1_status != "ok" or not prodh1:
        r["ziad_status"] = "prodh1_ambiguo" if prodh1_status == "ambiguo" else "pendente_prodh1"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "dados", "PRODH1 indisponível",
                          "O cliente possui ZIAD, mas a hierarquia do material (MARA.PRDHA) não é única.", True)
        return r

    ziad, err = _safe(consultar_ziad, kunnr, prodh1=prodh1)
    if err:
        r["ziad_status"] = "erro"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "erro", "Falha na consulta ZIAD", err, True)
        return r
    r["ziad_detalhes"] = ziad or []
    if ziad:
        descontos = sorted({z.get("desconto") for z in ziad if z.get("desconto") is not None})
        r["ziad_status"] = "encontrada"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "ok",
                          "Desconto " + "/".join(f"{_fmt_num(d)}%" for d in descontos) if descontos else "Condição vigente",
                          f"ZIAD vigente para PRODH1 {prodh1}.")
    else:
        r["ziad_status"] = "nao_encontrada_prodh1"
        r["crit"] = _crit("ziad", "Desconto ZIAD", "ok", "Nenhuma ZIAD para a hierarquia",
                          f"O cliente possui ZIAD, mas não para o PRODH1 {prodh1}.")
    return r


# =============================================================================
# RESULTADOS
# =============================================================================
_RESUMOS = {
    "concluido": ("Concluído tecnicamente", "Todas as validações obrigatórias foram concluídas."),
    "divergencia": ("Divergência", "Há divergência confirmada em pelo menos uma validação."),
    "dados_insuficientes": ("Pendente", "Há informação, parametrização ou decisão humana pendente."),
    "erro": ("Erro técnico", "Uma consulta falhou; reanalise o pedido ou verifique a fonte."),
}


def resultado_por_criterios(criterios):
    """Precedência: erro > divergência > pendência > concluído (somente bloqueantes)."""
    bloq = {str(c.get("status") or "") for c in criterios if isinstance(c, dict) and c.get("bloqueante")}
    if "erro" in bloq:
        return "erro"
    if "divergencia" in bloq:
        return "divergencia"
    if bloq & {"dados", "funcional", "pendente"}:
        return "dados_insuficientes"
    return "concluido"


def montar_resumo_item(item):
    """Recalcula resultado/resumo do item a partir dos critérios (usado também pelo app.py)."""
    det = item.get("detalhes_validacao") or {}
    criterios = [c for g in ("cliente", "item") for c in (det.get(g) or []) if isinstance(c, dict)]
    resultado = resultado_por_criterios(criterios)
    item["resultado"] = resultado
    titulo, descricao = _RESUMOS[resultado]
    motivos = [
        {"codigo": c.get("codigo"), "label": c.get("label"), "status": c.get("status"),
         "valor": c.get("valor"), "detalhe": c.get("detalhe")}
        for c in criterios
        if c.get("bloqueante") and c.get("status") != "ok"
    ]
    det["resumo"] = {"status": resultado, "titulo": titulo, "descricao": descricao}
    det["status_final_etapa2"] = {
        "status": "concluido" if resultado == "concluido" else "bloqueado",
        "titulo": "Concluído tecnicamente" if resultado == "concluido" else "Bloqueado",
        "descricao": descricao,
        "resultado_tecnico": resultado,
        "motivos": motivos,
    }
    item["detalhes_validacao"] = det
    return item


def status_ordem_por_resultados(resultados):
    resultados = [str(r or "") for r in resultados]
    if not resultados:
        return "idle"
    if "erro" in resultados:
        return "err"
    if "divergencia" in resultados:
        return "warn"
    if "dados_insuficientes" in resultados or "pendente" in resultados:
        return "dados"
    return "ok"


def _avaliar_quebra_pedido(itens):
    grupos = {}
    for it in itens:
        moeda = _texto(it.get("moeda_ariba")) or "SEM_MOEDA"
        centro = _texto((it.get("logistica") or {}).get("centro_expedicao")) or "CENTRO_PENDENTE"
        grupos.setdefault(f"{moeda}|{centro}", []).append(it.get("linha"))
    pendente = any(k.endswith("|CENTRO_PENDENTE") for k in grupos)
    return {
        "status": "pendente_centro" if pendente else ("multiplas_chaves" if len(grupos) > 1 else "chave_unica"),
        "grupos": [{"chave": k, "itens": v} for k, v in sorted(grupos.items())],
    }


# =============================================================================
# ANÁLISE DO PEDIDO
# =============================================================================
def analisar_pedido(payload, mapeamentos_pagamento=None, mapeamentos_mvke=None,
                    parametros_clientes=None, mapeamentos_shipto=None):
    payload = payload if isinstance(payload, dict) else {}
    numero = _texto(payload.get("order_number"))
    conta = (_texto(payload.get("account")) or "").upper()
    customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
    commercial = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}
    tipo = classificar_tipo(payload)

    base_ordem = {"numero": numero, "conta": conta, "cliente": _texto(customer.get("name")),
                  "tipo": tipo, "oracle_ambiente": ORACLE_ENV}

    if tipo != "Contrato":
        return {**base_ordem, "kunnr": None, "cliente_sap": {}, "status": "na",
                "resumo": "Não aplicável: a análise comercial é feita somente para pedidos de Contrato.",
                "erros": 0, "dados_insuficientes": 0, "pendentes": 0, "divergencias": 0,
                "concluidos": 0, "itens": []}

    # ------------------------------------------------------------- itens
    itens = []
    for idx, raw in enumerate(payload.get("items") or [], start=1):
        if not isinstance(raw, dict):
            continue
        itens.append({
            "raw": raw,
            "linha": _texto(raw.get("line_number")) or str(idx),
            "matnr_ariba": _matnr_item(raw),
            "kdmat": _kdmat_item(raw),
            "quantidade": raw.get("quantity"),
            "uom": _texto(raw.get("uom")),
            "preco_ariba": raw.get("unit_price"),
            "moeda_ariba": _texto(raw.get("currency")),
        })

    # ZNET por MATNR do Ariba ajuda a pontuar o KUNNR (KDGRP).
    pacotes_znet, erros_znet = {}, {}

    def _garantir_znet(matnr):
        if matnr and matnr not in pacotes_znet and matnr not in erros_znet:
            pac, err = _safe(consultar_znet_material, matnr)
            if err:
                erros_znet[matnr] = err
            else:
                pacotes_znet[matnr] = pac or {"condicoes": [], "erros_fontes": []}

    for it in itens:
        _garantir_znet(it["matnr_ariba"])

    # ------------------------------------------------------------- 1) KUNNR
    cliente_sap, err = _safe(_resolver_kunnr, payload, _kdgrp_hints(pacotes_znet),
                             mapeamentos_shipto=mapeamentos_shipto)
    if err:
        cliente_sap = {"status": "erro", "kunnr": None, "erro": err, "evidencias": []}
    kunnr = cliente_sap.get("kunnr")
    if kunnr and str(kunnr).isdigit():
        kunnr = str(kunnr).zfill(10)
    parametro = _parametro_cliente(kunnr, parametros_clientes)

    # ------------------------------------------------------------- 2) KNVV + canal
    knvv, knvv_erro = ({}, None)
    if kunnr:
        knvv, knvv_erro = _safe(consultar_knvv_pra, kunnr)
        knvv = knvv or {}
    canal_info = _determinar_canal(parametro.get("vtweg"), knvv, knvv_erro) if kunnr else \
        {"canal": None, "status": "sem_kunnr", "disponiveis": []}
    historicos_canal = {}
    if kunnr:
        canal_info, historicos_canal = _resolver_canal_por_historico_itens(
            canal_info, itens, kunnr
        )
    canal = canal_info.get("canal")
    kv = _knvv_canal(knvv, canal)
    kdgrps = kv["kdgrps"] or sorted({
        str(x.get("kdgrp")).strip() for x in (cliente_sap.get("knvv") or []) if str(x.get("kdgrp") or "").strip()
    })

    # ------------------------------------------------------------- DALI
    dali, dali_erro = ({}, None)
    if kunnr:
        dali, dali_erro = _safe(consultar_parceiros_dali, kunnr)
        dali = dali or {}

    transporte_ariba = {
        "incoterms": _texto(commercial.get("incoterms")) or _texto(commercial.get("transport_terms")),
        "delivery_terms": _texto(commercial.get("delivery_terms")),
    }
    ctx = {
        "cliente_sap": cliente_sap, "kunnr": kunnr, "canal": canal, "canal_info": canal_info,
        "knvv_erro": knvv_erro, "knvv_canal": kv, "dali": dali, "dali_erro": dali_erro,
        "pagamento_ariba": _dados_pagamento_ariba(payload),
        "mapa_pagamento": _normalizar_mapeamentos_pagamento(mapeamentos_pagamento),
        "redespacho_ariba": _texto(commercial.get("redespacho")),
        "transporte_ariba": transporte_ariba,
    }
    criterios_cliente = _criterios_cliente(ctx)
    criterio_transporte = _criterio_transporte(ctx)

    cliente_sap.update({
        "canal_vendas": canal, "canal_status": canal_info.get("status"),
        "vtwegs_disponiveis": canal_info.get("disponiveis"), "kdgrps_efetivos": kdgrps,
        "kondas_efetivos": kv["kondas"], "knvv_dclo": knvv, "parceiros_dali": dali,
    })

    mapa_mvke = _normalizar_mapeamentos_mvke(mapeamentos_mvke)
    cache_material = {}
    cache_ziad = {}

    # ------------------------------------------------------------- por item
    resultados = []
    canais_efetivos = []
    for it in itens:
        obs = []
        mat = _resolver_material(it, kunnr)
        matnr = mat["matnr"]
        crit_item = [mat["crit_matnr"]]
        if mat["crit_knmt"]:
            crit_item.append(mat["crit_knmt"])

        # Canal inicialmente resolvido pela regra comercial normal.
        # Um item de Service pode ser redirecionado de 50/52 para 53 sem
        # alterar o canal dos demais itens do mesmo pedido.
        canal_item = canal
        canal_info_item = dict(canal_info or {})
        kv_item = kv
        kdgrps_item = list(kdgrps)
        criterios_cliente_item = criterios_cliente
        criterio_transporte_item = criterio_transporte

        # ---- PRA (MARC/MARA/MAKT/MVKE do canal)
        material, mat_erro = {}, None
        if matnr:
            chave = (matnr, canal_item or "")
            if chave not in cache_material:
                cache_material[chave] = _safe(consultar_material_pra, matnr, vtweg=canal_item)
            material, mat_erro = cache_material[chave]
            material = material or {}
            _garantir_znet(matnr)

        material_ok = bool(matnr) and not mat_erro and material.get("status") == "ok"
        marc = (material.get("centros") or []) if material_ok else []
        mvke_rows = [
            m for m in (material.get("mvke") or [])
            if not canal_item or _texto(m.get("vtweg")) == canal_item
        ] if material_ok else []
        mvke_canal = mvke_rows[0] if (canal_item and mvke_rows) else None

        # Regra funcional de Service: SV em 50/52 deve ser processado no 53.
        # O redirecionamento só é feito se o material possuir MVKE BR10/53.
        # Após a troca, todas as validações dependentes de canal usam o 53.
        vmsta_inicial = (_texto((mvke_canal or {}).get("vmsta")) or "").upper()
        if material_ok and canal_item in {"50", "52"} and vmsta_inicial == "SV":
            chave_53 = (matnr, "53")
            if chave_53 not in cache_material:
                cache_material[chave_53] = _safe(consultar_material_pra, matnr, vtweg="53")
            material_53, erro_53 = cache_material[chave_53]
            material_53 = material_53 or {}
            material_53_ok = bool(matnr) and not erro_53 and material_53.get("status") == "ok"
            mvke_53_rows = [
                m for m in (material_53.get("mvke") or [])
                if _texto(m.get("vtweg")) == "53"
            ] if material_53_ok else []

            if mvke_53_rows:
                canal_original = canal_item
                canal_item = "53"
                canal_info_item = {
                    "canal": "53",
                    "status": "regra_sv_53",
                    "fonte": "Regra funcional SV → canal 53",
                    "disponiveis": (canal_info or {}).get("disponiveis") or [],
                    "canal_original": canal_original,
                }
                kv_item = _knvv_canal(knvv, canal_item)
                kdgrps_item = kv_item["kdgrps"] or sorted({
                    str(x.get("kdgrp")).strip()
                    for x in (cliente_sap.get("knvv") or [])
                    if str(x.get("kdgrp") or "").strip()
                })

                material = material_53
                mat_erro = None
                material_ok = True
                marc = material.get("centros") or []
                mvke_rows = mvke_53_rows
                mvke_canal = mvke_53_rows[0]

                ctx_item = dict(ctx)
                ctx_item.update({
                    "canal": canal_item,
                    "canal_info": canal_info_item,
                    "knvv_canal": kv_item,
                })
                criterios_cliente_item = _criterios_cliente(ctx_item)
                criterio_transporte_item = _criterio_transporte(ctx_item)

        if canal_item:
            canais_efetivos.append(canal_item)

        if not matnr:
            crit_item.append(_dependente("material_dclo", "Cadastro do material (PRA)", "Aguardando material."))
        elif mat_erro:
            crit_item.append(_crit("material_dclo", "Cadastro do material (PRA)", "erro",
                                   "Falha na consulta DCLO/PRA", mat_erro, True))
        elif not material_ok:
            crit_item.append(_crit("material_dclo", "Cadastro do material (PRA)", "divergencia",
                                   "MATNR não encontrado no PRA",
                                   f"O MATNR {matnr} não tem MARC em centros BR.", True))
        else:
            crit_item.append(_crit("material_dclo", "Cadastro do material (PRA)", "ok",
                                   material.get("descricao") or matnr,
                                   f"PRODH1 {material.get('prodh1') or '—'}; centros MARC "
                                   f"{'/'.join(sorted({_texto(m.get('werks')) for m in marc if _texto(m.get('werks'))}))}."))

        if material_ok:
            crit_item.append(_avaliar_vmsta(canal_item, mvke_canal, mapa_mvke))
            centro_info, crit_centro = _determinar_centro(canal_item, mvke_canal, marc)
            crit_obt = _criterio_obtencao(centro_info.get("centro"), marc)
            if crit_obt:
                crit_item.append(crit_obt)
            crit_item.append(_avaliar_lote(canal_item, it["quantidade"], it["uom"], mvke_canal))
        else:
            motivo = "Aguardando cadastro do material."
            centro_info = {"centro": None}
            crit_item.append(_dependente("vmsta", "Status de venda (VMSTA)", motivo))
            crit_centro = _dependente("centro", "Centro fornecedor", motivo)
            crit_item.append(_dependente("lote", "Lote mínimo / múltiplo", motivo))

        # ---- Preço
        preco_txt = _fmt_moeda(it["preco_ariba"], it["moeda_ariba"]) if it["preco_ariba"] is not None else "Não informado"
        crit_item.append(_crit("preco_ariba", "Preço no pedido Ariba", "info", preco_txt))
        if matnr and not mat_erro and not material_ok:
            zn = {
                "znet_status": "dependente_pra",
                "znet_origem": "A005+A813+A706",
                "znet_condicoes": 0,
                "znet_matches": 0,
                "znet_preco_min": None,
                "znet_preco_max": None,
                "znet_detalhes": [],
                "crit": _dependente(
                    "znet",
                    "Preço ZNET",
                    f"Depende do cadastro do MATNR {matnr} no PRA."
                ),
            }
        else:
            zn = _avaliar_znet(
                matnr,
                kunnr,
                kdgrps_item,
                kv_item["kondas"],
                it["preco_ariba"],
                it["moeda_ariba"],
                pacotes_znet.get(matnr),
                erros_znet.get(matnr),
            )

        crit_item.append(zn["crit"])
        zi = _avaliar_ziad(kunnr, material.get("prodh1") if material_ok else None,
                           material.get("prodh1_status") if material_ok else None, material_ok, cache_ziad)
        crit_item.append(zi["crit"])

        # ---- Logística
        crit_item.append(crit_centro)
        crit_item.append(criterio_transporte_item)
        destino, fonte_destino = _resolver_destino(it["raw"], payload, parametro)
        if destino:
            crit_item.append(_crit("destino_mercadoria", "Destino da mercadoria", "ok", destino,
                                   f"Fonte: {fonte_destino}."))
        else:
            crit_item.append(_crit(
                "destino_mercadoria",
                "Destino da mercadoria",
                "info",
                "Não informado",
                "O campo material_usage não está sendo fornecido nos pedidos Ariba atuais. "
                "A ausência do destino não bloqueia a Etapa 2 nesta versão.",
                False,
            ))

        for c in criterios_cliente_item + crit_item:
            if c.get("status") in ("erro", "divergencia", "dados", "funcional") and c.get("detalhe"):
                obs.append(f"{c.get('label')}: {c.get('detalhe')}")

        item_out = {
            "linha": it["linha"],
            "matnr": matnr,
            "matnr_origem": mat["matnr_origem"],
            "matnr_ariba_original": it["matnr_ariba"],
            "kdmat": it["kdmat"],
            "kunnr": kunnr,
            "knmt_status": mat["knmt_status"],
            "knmt_matnr": mat["knmt_matnr"],
            "knmt_erro": mat["knmt_erro"],
            "historico_kdmat_status": mat["historico_kdmat_status"],
            "historico_kdmat_matnr": mat["historico_kdmat_matnr"],
            "historico_kdmat_matnrs": mat["historico_kdmat_matnrs"],
            "historico_kdmat_ultimo_vbeln": mat["historico_kdmat_ultimo_vbeln"],
            "historico_kdmat_erro": mat["historico_kdmat_erro"],
            "fallback_historico_usado": mat["fallback_historico_usado"],
            "preco_ariba": it["preco_ariba"],
            "moeda_ariba": it["moeda_ariba"],
            "quantidade": it["quantidade"],
            "uom": it["uom"],
            "canal_vendas": canal_item,
            "prodh1": material.get("prodh1") if material_ok else None,
            "descricao_sap": material.get("descricao") if material_ok else None,
            "znet_status": zn["znet_status"],
            "znet_origem": zn["znet_origem"],
            "znet_condicoes": zn["znet_condicoes"],
            "znet_matches": zn["znet_matches"],
            "znet_preco_min": zn["znet_preco_min"],
            "znet_preco_max": zn["znet_preco_max"],
            "znet_detalhes": zn["znet_detalhes"],
            "ziad_status": zi["ziad_status"],
            "ziad_detalhes": zi["ziad_detalhes"],
            "logistica": {
                "canal_vendas": canal_item,
                "centro_expedicao": centro_info.get("centro"),
                "centro_regra": centro_info.get("regra"),
                "dwerk": centro_info.get("dwerk"),
                "sobsl_codigos": centro_info.get("sobsl"),
                "plantas_marc": centro_info.get("plantas"),
                "moeda_ariba": it["moeda_ariba"],
            },
            "detalhes_validacao": {"versao": 2, "cliente": criterios_cliente_item, "item": crit_item},
            # VEND_AnaliseItem.motivo é NVARCHAR(2000): texto maior derrubava o INSERT.
            "motivo": (" ".join(obs) or "Todas as validações concluídas.")[:1900],
        }
        montar_resumo_item(item_out)
        resultados.append(item_out)

    # ------------------------------------------------------------- ordem
    canais_unicos = sorted(set(canais_efetivos))
    canal_final = canais_unicos[0] if len(canais_unicos) == 1 else canal
    if canal_final and canal_final != canal:
        cliente_sap["canal_vendas"] = canal_final
        cliente_sap["canal_status"] = "regra_sv_53"

    res = [r["resultado"] for r in resultados]
    status = status_ordem_por_resultados(res)
    concl = res.count("concluido")
    div = res.count("divergencia")
    pend = res.count("dados_insuficientes")
    errs = res.count("erro")
    resumo = (
        f"{len(res)} item(ns): {concl} concluído(s), {div} divergência(s), "
        f"{pend} pendente(s), {errs} erro(s). "
        f"KUNNR {kunnr or 'não identificado'}; canal {canal_final or 'não definido'}."
    )
    return {
        **base_ordem,
        "kunnr": kunnr,
        "canal_vendas": canal_final,
        "cliente_sap": cliente_sap,
        "quebra_pedido": _avaliar_quebra_pedido(resultados),
        "status": status,
        "resumo": resumo,
        "erros": errs,
        "dados_insuficientes": pend,
        "pendentes": 0,
        "divergencias": div,
        "concluidos": concl,
        "itens": resultados,
    }