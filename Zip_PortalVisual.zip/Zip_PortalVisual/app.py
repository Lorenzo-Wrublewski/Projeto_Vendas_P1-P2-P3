# -*- coding: utf-8 -*-
"""
Portal Automação de Vendas — etapa 1 (SAP Business Network via API)

Responsabilidades:
- servir o portal visual;
- permitir configurar, por conta (ITA/POP), as credenciais da API Ariba;
- iniciar o coletor API sem Playwright/Tkinter;
- receber eventos do coletor e transmiti-los ao navegador via SSE;
- persistir execução/ordens no SQL Server;
- permitir abrir o JSON e o PDF visual de cada pedido coletado.

Não existe cadastro/configuração de cliente no Portal. Todo pedido é salvo
com o JSON completo normalizado pela automação.

IMPORTANTE:
- Credenciais Ariba NÃO ficam neste código. O portal lê/grava o arquivo
  ariba_api_config.json da pasta do coletor.
- Credenciais do SQL também não ficam hardcoded. Use portal_config.json ou
  variáveis de ambiente.
"""

import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
from collections import deque
from datetime import datetime, date, timedelta
from pathlib import Path
from urllib.parse import urlparse

from flask import (
    Flask,
    Response,
    abort,
    jsonify,
    render_template,
    request,
    send_file,
    stream_with_context,
)
from werkzeug.exceptions import HTTPException

try:
    import pyodbc
except ImportError:
    pyodbc = None

try:
    from order_pdf import build_order_pdf
except ImportError:
    build_order_pdf = None

try:
    from order_fields import extrair_campos_uteis
except ImportError:
    extrair_campos_uteis = None

try:
    from etapa2_validacao import (
        analisar_pedido,
        montar_resumo_item,
        status_ordem_por_resultados,
    )
    ETAPA2_IMPORT_ERROR = None
except Exception as exc:
    analisar_pedido = None
    montar_resumo_item = None
    status_ordem_por_resultados = None
    ETAPA2_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"


# =============================================================================
# CONFIGURAÇÃO DO PORTAL / CAMINHOS
# =============================================================================
BASE_DIR = Path(__file__).resolve().parent
PORTAL_CONFIG_FILE = Path(
    os.environ.get("PORTAL_CONFIG", str(BASE_DIR / "portal_config.json"))
)


def _read_json(path, default=None):
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else (default or {})
    except Exception:
        pass
    return default or {}


PORTAL_CONFIG = _read_json(PORTAL_CONFIG_FILE, {})
DB_CFG = PORTAL_CONFIG.get("database") or {}

DB_SERVER = os.environ.get("DB_SERVER") or DB_CFG.get("server") or "ca0vsql09.br.bosch.com,56482"
DB_DATABASE = os.environ.get("DB_DATABASE") or DB_CFG.get("database") or "DB_DCLA_DATA_LAKE_SQL"
DB_USER = os.environ.get("DB_USER") or DB_CFG.get("user") or ""
DB_PASSWORD = os.environ.get("DB_PASSWORD") or DB_CFG.get("password") or ""

_default_automation_dir = (BASE_DIR.parent / "ariba_automation_v2 - api").resolve()
AUTOMATION_DIR = Path(
    os.environ.get("ARIBA_AUTOMATION_DIR")
    or PORTAL_CONFIG.get("automation_dir")
    or _default_automation_dir
).expanduser().resolve()

COLLECTOR_SCRIPT = Path(
    os.environ.get("ARIBA_COLLECTOR_SCRIPT")
    or PORTAL_CONFIG.get("collector_script")
    or (AUTOMATION_DIR / "ariba_automation_vAPI.py")
).expanduser().resolve()

ARIBA_CONFIG_FILE = Path(
    os.environ.get("ARIBA_API_CONFIG")
    or PORTAL_CONFIG.get("ariba_api_config")
    or (AUTOMATION_DIR / "ariba_api_config.json")
).expanduser().resolve()

PEDIDOS_ROOT = (AUTOMATION_DIR / "Pedidos Baixados").resolve()
LEGACY_DATA_ROOT = (AUTOMATION_DIR / "data").resolve()
ALLOWED_JSON_ROOTS = (PEDIDOS_ROOT, LEGACY_DATA_ROOT)
LOOKBACK_DAYS = int(os.environ.get("ARIBA_LOOKBACK_DAYS", "365"))
PORT = int(os.environ.get("PORT") or PORTAL_CONFIG.get("port") or 5000)
PORTAL_INTERNAL_URL = str(
    os.environ.get("PORTAL_INTERNAL_URL")
    or PORTAL_CONFIG.get("portal_internal_url")
    or f"http://127.0.0.1:{PORT}"
).rstrip("/")

app = Flask(__name__)


# =============================================================================
# SQL SERVER
# =============================================================================
def _connection_string():
    base = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        f"SERVER={DB_SERVER};"
        f"DATABASE={DB_DATABASE};"
        "TrustServerCertificate=yes;"
    )
    if DB_USER and DB_PASSWORD:
        return base + f"UID={DB_USER};PWD={DB_PASSWORD};"
    return base + "Trusted_Connection=yes;"


CONN_STR = _connection_string()


def get_conn():
    if pyodbc is None:
        raise RuntimeError(
            "pyodbc não instalado. Rode: pip install pyodbc e instale o ODBC Driver 17."
        )
    return pyodbc.connect(CONN_STR)





def ensure_feature_schema():
    """Garante apenas as estruturas técnicas usadas pelo Portal atual."""
    with get_conn() as cn:
        cur = cn.cursor()
        statements = [
            """
            IF COL_LENGTH('dbo.VEND_Ordem', 'buyer_anid') IS NULL
                ALTER TABLE dbo.VEND_Ordem ADD buyer_anid NVARCHAR(100) NULL;
            """,
            """
            IF COL_LENGTH('dbo.VEND_Ordem', 'etapa2_status') IS NULL
                ALTER TABLE dbo.VEND_Ordem ADD etapa2_status VARCHAR(12) NOT NULL
                    CONSTRAINT DF_VEND_Ordem_etapa2_status DEFAULT 'idle';
            """,
            """
            IF COL_LENGTH('dbo.VEND_Ordem', 'etapa2_msg') IS NULL
                ALTER TABLE dbo.VEND_Ordem ADD etapa2_msg NVARCHAR(1000) NULL;
            """,
            """
            IF COL_LENGTH('dbo.VEND_Ordem', 'etapa2_atualizado_em') IS NULL
                ALTER TABLE dbo.VEND_Ordem ADD etapa2_atualizado_em DATETIME2 NULL;
            """,
            """
            IF OBJECT_ID('dbo.VEND_AnaliseItem', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_AnaliseItem (
                    id BIGINT IDENTITY(1,1) PRIMARY KEY,
                    conta VARCHAR(3) NOT NULL,
                    numero NVARCHAR(100) NOT NULL,
                    linha NVARCHAR(50) NOT NULL,
                    matnr NVARCHAR(100) NULL,
                    preco_ariba DECIMAL(20,6) NULL,
                    moeda_ariba NVARCHAR(10) NULL,
                    kunnr NVARCHAR(30) NULL,
                    znet_status VARCHAR(40) NULL,
                    znet_origem VARCHAR(40) NULL,
                    znet_condicoes INT NOT NULL DEFAULT 0,
                    znet_matches INT NOT NULL DEFAULT 0,
                    znet_preco_min DECIMAL(20,6) NULL,
                    znet_preco_max DECIMAL(20,6) NULL,
                    znet_detalhes_json NVARCHAR(MAX) NULL,
                    ziad_status VARCHAR(40) NULL,
                    ziad_detalhes_json NVARCHAR(MAX) NULL,
                    resultado VARCHAR(20) NULL,
                    motivo NVARCHAR(2000) NULL,
                    atualizado_em DATETIME2 NOT NULL DEFAULT GETDATE()
                );
                CREATE INDEX IX_VEND_AnaliseItem_Ordem
                    ON dbo.VEND_AnaliseItem(conta, numero);
            END
            """,
            """
            IF COL_LENGTH('dbo.VEND_AnaliseItem', 'detalhes_validacao_json') IS NULL
                ALTER TABLE dbo.VEND_AnaliseItem ADD detalhes_validacao_json NVARCHAR(MAX) NULL;
            """,
            """
            IF OBJECT_ID('dbo.VEND_MapeamentoPagamento', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_MapeamentoPagamento (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    kunnr NVARCHAR(30) NULL,
                    ariba_codigo NVARCHAR(50) NOT NULL,
                    sap_zterm NVARCHAR(50) NOT NULL,
                    descricao NVARCHAR(250) NULL,
                    ativo BIT NOT NULL CONSTRAINT DF_VEND_MapeamentoPagamento_ativo DEFAULT 1,
                    criado_por NVARCHAR(150) NULL,
                    criado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoPagamento_criado DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoPagamento_atualizado DEFAULT GETDATE(),
                    CONSTRAINT UQ_VEND_MapeamentoPagamento_KUNNR
                        UNIQUE (kunnr, ariba_codigo, sap_zterm)
                );
            END
            ELSE
            BEGIN
                IF COL_LENGTH('dbo.VEND_MapeamentoPagamento', 'kunnr') IS NULL
                    ALTER TABLE dbo.VEND_MapeamentoPagamento ADD kunnr NVARCHAR(30) NULL;

                IF EXISTS (
                    SELECT 1
                    FROM sys.key_constraints
                    WHERE [name] = 'UQ_VEND_MapeamentoPagamento'
                      AND parent_object_id = OBJECT_ID('dbo.VEND_MapeamentoPagamento')
                )
                    ALTER TABLE dbo.VEND_MapeamentoPagamento
                    DROP CONSTRAINT UQ_VEND_MapeamentoPagamento;

                IF NOT EXISTS (
                    SELECT 1
                    FROM sys.key_constraints
                    WHERE [name] = 'UQ_VEND_MapeamentoPagamento_KUNNR'
                      AND parent_object_id = OBJECT_ID('dbo.VEND_MapeamentoPagamento')
                )
                    ALTER TABLE dbo.VEND_MapeamentoPagamento
                    ADD CONSTRAINT UQ_VEND_MapeamentoPagamento_KUNNR
                    UNIQUE (kunnr, ariba_codigo, sap_zterm);
            END
            """,
            """
            IF OBJECT_ID('dbo.VEND_MapeamentoMVKE', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_MapeamentoMVKE (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    codigo_vmsta NVARCHAR(20) NOT NULL,
                    classificacao VARCHAR(20) NOT NULL,
                    descricao NVARCHAR(250) NULL,
                    ativo BIT NOT NULL CONSTRAINT DF_VEND_MapeamentoMVKE_ativo DEFAULT 1,
                    criado_por NVARCHAR(150) NULL,
                    criado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoMVKE_criado DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoMVKE_atualizado DEFAULT GETDATE(),
                    CONSTRAINT UQ_VEND_MapeamentoMVKE UNIQUE (codigo_vmsta)
                );
            END
            """,
            """
            IF OBJECT_ID('dbo.VEND_ParametroCliente', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_ParametroCliente (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    kunnr NVARCHAR(30) NOT NULL,
                    representante NVARCHAR(200) NULL,
                    comissao NVARCHAR(100) NULL,
                    motivo_beneficio_fiscal NVARCHAR(250) NULL,
                    transportadora NVARCHAR(200) NULL,
                    redespacho NVARCHAR(200) NULL,
                    vtweg NVARCHAR(10) NULL,
                    destino_mercadoria NVARCHAR(100) NULL,
                    ativo BIT NOT NULL CONSTRAINT DF_VEND_ParametroCliente_ativo DEFAULT 1,
                    criado_por NVARCHAR(150) NULL,
                    criado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_ParametroCliente_criado DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_ParametroCliente_atualizado DEFAULT GETDATE(),
                    CONSTRAINT UQ_VEND_ParametroCliente_KUNNR UNIQUE (kunnr)
                );
            END
            ELSE
            BEGIN
                IF COL_LENGTH('dbo.VEND_ParametroCliente', 'transportadora') IS NULL
                    ALTER TABLE dbo.VEND_ParametroCliente ADD transportadora NVARCHAR(200) NULL;
                IF COL_LENGTH('dbo.VEND_ParametroCliente', 'redespacho') IS NULL
                    ALTER TABLE dbo.VEND_ParametroCliente ADD redespacho NVARCHAR(200) NULL;
                IF COL_LENGTH('dbo.VEND_ParametroCliente', 'vtweg') IS NULL
                    ALTER TABLE dbo.VEND_ParametroCliente ADD vtweg NVARCHAR(10) NULL;
                IF COL_LENGTH('dbo.VEND_ParametroCliente', 'destino_mercadoria') IS NULL
                    ALTER TABLE dbo.VEND_ParametroCliente ADD destino_mercadoria NVARCHAR(100) NULL;
            END
            """,
            """
            IF OBJECT_ID('dbo.VEND_MapeamentoShipTo', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_MapeamentoShipTo (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    ship_to_code NVARCHAR(50) NOT NULL,
                    kunnr NVARCHAR(30) NOT NULL,
                    descricao NVARCHAR(250) NULL,
                    ativo BIT NOT NULL CONSTRAINT DF_VEND_MapeamentoShipTo_ativo DEFAULT 1,
                    criado_por NVARCHAR(150) NULL,
                    criado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoShipTo_criado DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL CONSTRAINT DF_VEND_MapeamentoShipTo_atualizado DEFAULT GETDATE(),
                    CONSTRAINT UQ_VEND_MapeamentoShipTo UNIQUE (ship_to_code)
                );
            END
            """,
            """
            IF OBJECT_ID('dbo.VEND_ValidacaoFuncional', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_ValidacaoFuncional (
                    id BIGINT IDENTITY(1,1) PRIMARY KEY,
                    conta VARCHAR(3) NOT NULL,
                    numero NVARCHAR(100) NOT NULL,
                    linha NVARCHAR(50) NULL,
                    codigo NVARCHAR(100) NOT NULL,
                    assinatura NVARCHAR(1000) NOT NULL,
                    titulo NVARCHAR(250) NOT NULL,
                    descricao NVARCHAR(2000) NULL,
                    valor_detectado NVARCHAR(1000) NULL,
                    status VARCHAR(20) NOT NULL
                        CONSTRAINT DF_VEND_ValidacaoFuncional_status DEFAULT 'pendente',
                    ativo BIT NOT NULL
                        CONSTRAINT DF_VEND_ValidacaoFuncional_ativo DEFAULT 1,
                    decisao_por NVARCHAR(150) NULL,
                    decisao_em DATETIME2 NULL,
                    motivo_rejeicao NVARCHAR(1000) NULL,
                    criado_em DATETIME2 NOT NULL
                        CONSTRAINT DF_VEND_ValidacaoFuncional_criado DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL
                        CONSTRAINT DF_VEND_ValidacaoFuncional_atualizado DEFAULT GETDATE()
                );

                CREATE INDEX IX_VEND_ValidacaoFuncional_Ordem
                    ON dbo.VEND_ValidacaoFuncional(conta, numero, ativo);

                CREATE UNIQUE INDEX UX_VEND_ValidacaoFuncional_Assinatura
                    ON dbo.VEND_ValidacaoFuncional(conta, numero, linha, codigo, assinatura);
            END
            """,
            """
            IF OBJECT_ID('dbo.VEND_Agendamento', 'U') IS NULL
            BEGIN
                CREATE TABLE dbo.VEND_Agendamento (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    conta VARCHAR(3) NOT NULL,
                    horario TIME(0) NOT NULL,
                    frequencia VARCHAR(10) NOT NULL,
                    data_execucao DATE NULL,
                    periodo VARCHAR(10) NOT NULL DEFAULT '24h',
                    ativo BIT NOT NULL DEFAULT 1,
                    ultima_execucao DATETIME2 NULL,
                    criado_por NVARCHAR(150) NULL,
                    criado_em DATETIME2 NOT NULL DEFAULT GETDATE(),
                    atualizado_em DATETIME2 NOT NULL DEFAULT GETDATE()
                );
            END
            """,
        ]
        for statement in statements:
            cur.execute(statement)
        cn.commit()


def _recuperar_etapa2_interrompida():
    """Evita status 'Analisando' eterno após reinício/interrupção do Portal."""
    try:
        with get_conn() as cn:
            cn.cursor().execute(
                """UPDATE dbo.VEND_Ordem
                   SET etapa2_status='err',
                       etapa2_msg='Reanálise interrompida antes da conclusão. Execute novamente.',
                       etapa2_atualizado_em=GETDATE()
                   WHERE etapa2_status='run'"""
            )
            cn.commit()
    except Exception:
        pass


def usuario_atual():
    return (
        request.headers.get("X-Forwarded-User")
        or os.environ.get("USERNAME")
        or "desconhecido"
    )


def _hora(dt):
    if dt is None:
        return ""
    return dt.strftime("%H:%M:%S") if hasattr(dt, "strftime") else str(dt)[11:19]


def _dm(dt):
    if dt is None:
        return ""
    return dt.strftime("%d/%m %H:%M") if hasattr(dt, "strftime") else str(dt)[:16]


# =============================================================================
# SSE — ATUALIZAÇÃO AO VIVO
# =============================================================================
class EventBus:
    def __init__(self):
        self._subs = []
        self._lock = threading.Lock()

    def subscribe(self):
        q = queue.Queue(maxsize=1000)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q):
        with self._lock:
            if q in self._subs:
                self._subs.remove(q)

    def publish(self, event):
        data = json.dumps(event, ensure_ascii=False, default=str)
        with self._lock:
            subs = list(self._subs)
        for q in subs:
            try:
                q.put_nowait(data)
            except queue.Full:
                pass


bus = EventBus()


@app.route("/api/stream")
def stream():
    conta = request.args.get("conta", "").upper()

    @stream_with_context
    def gen():
        q = bus.subscribe()
        yield "event: ping\ndata: {}\n\n"
        try:
            while True:
                try:
                    data = q.get(timeout=15)
                except queue.Empty:
                    yield ": keep-alive\n\n"
                    continue
                try:
                    ev = json.loads(data)
                    if conta and ev.get("conta") and ev["conta"] != conta:
                        continue
                except Exception:
                    pass
                yield f"data: {data}\n\n"
        finally:
            bus.unsubscribe(q)

    return Response(
        gen(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# =============================================================================
# GRAVAÇÃO ASSÍNCRONA DE ORDENS NO BANCO
# =============================================================================
_db_fila = queue.Queue(maxsize=10000)


def _db_worker():
    while True:
        fn = _db_fila.get()
        if fn is None:
            break
        try:
            fn()
        except Exception:
            pass
        finally:
            _db_fila.task_done()


threading.Thread(target=_db_worker, daemon=True).start()


def gravar_async(fn):
    try:
        _db_fila.put_nowait(fn)
    except queue.Full:
        pass


# =============================================================================
# ETAPA 2 — FILA / ESTADO
# =============================================================================
_etapa2_fila = queue.Queue(maxsize=1000)
_ETAPA2_THREAD = None
_ETAPA2_STATE_LOCK = threading.Lock()
_ETAPA2_STATE = {
    "ITA": {"running": False, "execucao_id": None, "total": 0, "concluido": 0, "erros": 0},
    "POP": {"running": False, "execucao_id": None, "total": 0, "concluido": 0, "erros": 0},
}


def _set_etapa2_state(conta, **values):
    conta = str(conta or "").upper()
    if conta not in _ETAPA2_STATE:
        return
    with _ETAPA2_STATE_LOCK:
        _ETAPA2_STATE[conta].update(values)


def _get_etapa2_state(conta):
    conta = str(conta or "").upper()
    with _ETAPA2_STATE_LOCK:
        return dict(_ETAPA2_STATE.get(conta, {}))


def _etapa2_worker():
    while True:
        job = _etapa2_fila.get()
        if job is None:
            break

        conta = None
        exec_id = None
        numero = None
        try:
            if isinstance(job, dict) and job.get("tipo") == "ordem":
                conta = str(job.get("conta") or "").upper()
                numero = str(job.get("numero") or "")
                _executar_etapa2_ordem_manual(conta, numero)
            else:
                conta, exec_id = job
                _executar_etapa2_execucao(conta, exec_id)
        except Exception as exc:
            if conta:
                _set_etapa2_state(conta, running=False)
            bus.publish({
                "tipo": "etapa2_fim",
                "conta": conta,
                "execucao_id": exec_id,
                "numero": numero,
                "status": "err",
                "erro": f"{type(exc).__name__}: {exc}",
            })
        finally:
            _etapa2_fila.task_done()


def _ensure_etapa2_worker():
    global _ETAPA2_THREAD
    if _ETAPA2_THREAD and _ETAPA2_THREAD.is_alive():
        return
    _ETAPA2_THREAD = threading.Thread(target=_etapa2_worker, daemon=True)
    _ETAPA2_THREAD.start()


def agendar_etapa2(conta, exec_id):
    if not exec_id:
        return
    _ensure_etapa2_worker()
    try:
        _etapa2_fila.put_nowait((str(conta).upper(), int(exec_id)))
    except queue.Full:
        bus.publish({
            "tipo": "etapa2_fim",
            "conta": str(conta).upper(),
            "execucao_id": exec_id,
            "status": "err",
            "erro": "Fila da Etapa 2 cheia.",
        })


# =============================================================================
# CONFIGURAÇÃO ARIBA — ARQUIVO EXTERNO; SEGREDOS SÓ SOB REVELAÇÃO EXPLÍCITA
# =============================================================================
_CONFIG_LOCK = threading.Lock()


def _empty_ariba_config():
    return {
        "ITA": {"anid": "", "client_id": "", "client_secret": "", "api_key": ""},
        "POP": {"anid": "", "client_id": "", "client_secret": "", "api_key": ""},
    }


def _load_ariba_config():
    cfg = _empty_ariba_config()
    raw = _read_json(ARIBA_CONFIG_FILE, {})
    for conta in ("ITA", "POP"):
        bloco = raw.get(conta) or {}
        if isinstance(bloco, dict):
            for key in ("anid", "client_id", "client_secret", "api_key"):
                if bloco.get(key) is not None:
                    cfg[conta][key] = str(bloco.get(key)).strip()
    return cfg


def _save_ariba_config(cfg):
    ARIBA_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = ARIBA_CONFIG_FILE.with_suffix(ARIBA_CONFIG_FILE.suffix + ".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, ARIBA_CONFIG_FILE)
    try:
        os.chmod(ARIBA_CONFIG_FILE, 0o600)
    except Exception:
        pass


def _public_profile(conta, bloco):
    return {
        "conta": conta,
        "anid": bloco.get("anid") or "",
        "client_id": bloco.get("client_id") or "",
        "tem_client_secret": bool(bloco.get("client_secret")),
        "tem_api_key": bool(bloco.get("api_key")),
        "lookback_days": LOOKBACK_DAYS,
        "collector_ok": COLLECTOR_SCRIPT.exists(),
        "config_path_ok": ARIBA_CONFIG_FILE.parent.exists(),
    }


def _validate_profile(bloco):
    faltando = [
        key
        for key in ("anid", "client_id", "client_secret", "api_key")
        if not str(bloco.get(key) or "").strip()
    ]
    return faltando


# =============================================================================
# CONTROLE DO PROCESSO DO COLETOR
# =============================================================================
_PROCESS_LOCK = threading.Lock()
_PROCESSES = {"ITA": None, "POP": None}
_PROCESS_OUTPUT = {"ITA": deque(maxlen=30), "POP": deque(maxlen=30)}


def _proc_running(conta):
    proc = _PROCESSES.get(conta)
    return bool(proc and proc.poll() is None)


def _collector_env(portal_url, started_by=None, period="365d"):
    env = os.environ.copy()
    portal_url = portal_url.rstrip("/")
    env["PYTHONUNBUFFERED"] = "1"
    env["PORTAL_URL"] = portal_url
    env["ARIBA_API_CONFIG"] = str(ARIBA_CONFIG_FILE)
    env["ARIBA_RUN_PERIOD"] = str(period or "365d")

    # O coletor precisa continuar usando o proxy corporativo para a SAP,
    # porém o callback de telemetria para o próprio Portal deve ser LOCAL.
    # Incluímos apenas o host do Portal no NO_PROXY, sem remover HTTP(S)_PROXY.
    try:
        host = (urlparse(portal_url).hostname or "").strip()
        bypass = ["localhost", "127.0.0.1", "::1"]
        if host and host not in bypass:
            bypass.append(host)
        for key in ("NO_PROXY", "no_proxy"):
            current = [x.strip() for x in str(env.get(key) or "").split(",") if x.strip()]
            merged = []
            for item in current + bypass:
                if item not in merged:
                    merged.append(item)
            env[key] = ",".join(merged)
    except Exception:
        pass

    if started_by:
        env["ARIBA_STARTED_BY"] = str(started_by)
    return env


def _start_collector(conta, period="365d", started_by=None, portal_url=None):
    conta = str(conta or "").upper()
    period = str(period or "365d").lower()

    if conta not in ("ITA", "POP"):
        raise ValueError("Conta inválida.")
    if period not in ("24h", "365d"):
        raise ValueError("Período inválido. Use 24h ou 365d.")
    if not COLLECTOR_SCRIPT.exists():
        raise RuntimeError(f"Coletor não encontrado: {COLLECTOR_SCRIPT}")

    with _CONFIG_LOCK:
        cfg = _load_ariba_config()
        faltando = _validate_profile(cfg[conta])
    if faltando:
        raise ValueError("Configure a API antes de executar: " + ", ".join(faltando))

    with _PROCESS_LOCK:
        if _proc_running(conta):
            raise RuntimeError(f"Já existe uma execução {conta} em andamento.")
        if _get_etapa2_state(conta).get("running"):
            raise RuntimeError(f"Já existe uma análise da Etapa 2 {conta} em andamento.")

        portal_url = (portal_url or PORTAL_INTERNAL_URL).rstrip("/")
        cmd = [
            sys.executable,
            str(COLLECTOR_SCRIPT),
            "--account", conta,
            "--headless",
            "--period", period,
        ]
        kwargs = {
            "cwd": str(AUTOMATION_DIR),
            "env": _collector_env(portal_url, started_by=started_by, period=period),
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "encoding": "utf-8",
            "errors": "replace",
            "bufsize": 1,
        }
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        proc = subprocess.Popen(cmd, **kwargs)
        _PROCESSES[conta] = proc
        _PROCESS_OUTPUT[conta].clear()
        threading.Thread(target=_watch_process, args=(conta, proc), daemon=True).start()

    bus.publish({
        "tipo": "processo_inicio",
        "conta": conta,
        "pid": proc.pid,
        "iniciado_por": started_by,
        "periodo": period,
    })
    return proc


def _watch_process(conta, proc):
    try:
        if proc.stdout:
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    _PROCESS_OUTPUT[conta].append(line)
        code = proc.wait()
    except Exception:
        code = -1
    finally:
        with _PROCESS_LOCK:
            if _PROCESSES.get(conta) is proc:
                _PROCESSES[conta] = None
        bus.publish({"tipo": "processo_fim", "conta": conta, "exit_code": code})


# =============================================================================
# PÁGINA / LEITURA
# =============================================================================
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    return jsonify(
        {
            "ok": True,
            "collector_exists": COLLECTOR_SCRIPT.exists(),
            "automation_dir": str(AUTOMATION_DIR),
        }
    )


def _tipo_e_condicao(conta, numero):
    """
    Determina o tipo (Contrato/Oferta) e a condição de pagamento de um pedido
    lendo o JSON final já salvo. Falhas são silenciosas: sem JSON, devolve
    (None, None) e o front exibe "—".
    """
    if extrair_campos_uteis is None:
        return None, None
    try:
        path = _find_new_order_json(conta, numero)
        if path is None:
            return None, None
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None, None

    tipo = None
    try:
        from order_fields import classificar_tipo
        tipo = classificar_tipo(payload)
    except Exception:
        tipo = None

    condicao = None
    try:
        from order_fields import _condicao_pagamento
        comercial = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}
        condicao = _condicao_pagamento(comercial)
    except Exception:
        condicao = None
    return tipo, condicao


@app.route("/api/ordens")
def listar_ordens():
    conta = request.args.get("conta", "ITA").upper()
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT numero, cliente, cliente_id, buyer_anid, itens, valor, moeda,
                      etapa1_status, etapa2_status, etapa2_msg, etapa2_atualizado_em,
                      qualidade, erro_msg, json_path, atualizado_em
               FROM dbo.VEND_Ordem
               WHERE conta = ?
               ORDER BY atualizado_em DESC""",
            conta,
        ).fetchall()

    resultado = []
    for r in rows:
        tipo, condicao = _tipo_e_condicao(conta, r.numero)
        resultado.append({
            "numero": r.numero,
            "cliente": r.cliente,
            "cliente_id": r.cliente_id,
            "buyer_anid": r.buyer_anid,
            "itens": r.itens,
            "valor": float(r.valor) if r.valor is not None else None,
            "moeda": r.moeda,
            "etapa1": r.etapa1_status,
            "etapa2": r.etapa2_status or "idle",
            "etapa2_msg": r.etapa2_msg,
            "etapa2_atualizado_em": _dm(r.etapa2_atualizado_em),
            "qualidade": r.qualidade,
            "erro": r.erro_msg,
            "tem_json": bool(r.json_path),
            "tipo": tipo,
            "condicao_pagamento": condicao,
            "atualizado_em": _dm(r.atualizado_em),
        })
    return jsonify(resultado)


def _path_is_under(path, root):
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _find_new_order_json(conta, numero):
    """
    Localiza um JSON final na nova pasta amigável.
    Aceita também o sufixo __<buyerANID> usado em uma rara colisão de números.
    """
    safe_number = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(numero))
    account_root = (PEDIDOS_ROOT / conta).resolve()

    if not account_root.exists():
        return None

    candidates = sorted(
        (
            p.resolve()
            for p in account_root.rglob(f"{safe_number}*.json")
            if p.is_file()
            and (
                p.stem == safe_number
                or p.stem.startswith(safe_number + "__")
            )
        ),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    return candidates[0] if candidates else None


def _resolve_order_json_path(conta, numero):
    conta = conta.upper()
    if conta not in ("ITA", "POP"):
        abort(400, "Conta inválida.")

    with get_conn() as cn:
        row = cn.cursor().execute(
            """SELECT TOP 1 json_path FROM dbo.VEND_Ordem
               WHERE conta=? AND numero=? ORDER BY atualizado_em DESC""",
            conta,
            str(numero),
        ).fetchone()

    path = None
    if row and row.json_path:
        candidate = Path(row.json_path).expanduser().resolve()
        if any(_path_is_under(candidate, root) for root in ALLOWED_JSON_ROOTS):
            if candidate.exists() and candidate.is_file():
                path = candidate

    if path is None:
        path = _find_new_order_json(conta, numero)

    if path is None:
        abort(404, "JSON não encontrado para esse pedido.")

    if not _path_is_under(path, PEDIDOS_ROOT) and not _path_is_under(
        path, LEGACY_DATA_ROOT
    ):
        abort(403, "Caminho de arquivo fora das pastas permitidas.")

    return path


@app.route("/api/ordens/<conta>/<numero>/json")
def baixar_json(conta, numero):
    path = _resolve_order_json_path(conta, numero)
    return send_file(path, mimetype="application/json", as_attachment=False)


@app.route("/api/ordens/<conta>/<numero>/pdf")
def visualizar_pdf(conta, numero):
    if build_order_pdf is None:
        abort(500, "Geração de PDF indisponível. Instale o pacote reportlab.")

    path = _resolve_order_json_path(conta, numero)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        abort(500, f"Não foi possível ler o JSON do pedido: {exc}")

    logo_path = BASE_DIR / "static" / "boschlogo.gif"
    try:
        pdf_bytes = build_order_pdf(
            payload,
            logo_path=logo_path if logo_path.exists() else None,
            account=conta.upper(),
        )
    except Exception as exc:
        abort(500, f"Não foi possível gerar o PDF do pedido: {exc}")

    from io import BytesIO
    return send_file(
        BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=False,
        download_name=f"{numero}.pdf",
    )


@app.route("/api/ordens/<conta>/<numero>/diag")
def diagnostico_json(conta, numero):
    """
    Diagnóstico: mostra onde o servidor procura o JSON de um pedido e o que
    encontra. Serve para investigar erros de "JSON não encontrado" sem adivinhar.
    Não expõe conteúdo do pedido — apenas caminhos e existência.
    """
    conta_up = (conta or "").upper()
    info = {
        "conta": conta_up,
        "numero": str(numero),
        "pedidos_root": str(PEDIDOS_ROOT),
        "pedidos_root_existe": PEDIDOS_ROOT.exists(),
        "conta_root": str((PEDIDOS_ROOT / conta_up)),
        "conta_root_existe": (PEDIDOS_ROOT / conta_up).exists(),
        "legacy_root": str(LEGACY_DATA_ROOT),
        "legacy_root_existe": LEGACY_DATA_ROOT.exists(),
        "json_path_no_banco": None,
        "json_path_no_banco_existe": None,
        "json_path_permitido": None,
        "encontrado_por_busca": None,
    }

    try:
        with get_conn() as cn:
            row = cn.cursor().execute(
                """SELECT TOP 1 json_path FROM dbo.VEND_Ordem
                   WHERE conta=? AND numero=? ORDER BY atualizado_em DESC""",
                conta_up, str(numero),
            ).fetchone()
        if row and row.json_path:
            info["json_path_no_banco"] = row.json_path
            cand = Path(row.json_path).expanduser().resolve()
            info["json_path_no_banco_existe"] = cand.exists() and cand.is_file()
            info["json_path_permitido"] = any(
                _path_is_under(cand, r) for r in ALLOWED_JSON_ROOTS
            )
    except Exception as exc:
        info["erro_banco"] = str(exc)

    try:
        achado = _find_new_order_json(conta_up, numero)
        info["encontrado_por_busca"] = str(achado) if achado else None
    except Exception as exc:
        info["erro_busca"] = str(exc)

    return jsonify(info)


def _carregar_analise_etapa2(conta, numero):
    try:
        with get_conn() as cn:
            rows = cn.cursor().execute(
                """SELECT linha, matnr, preco_ariba, moeda_ariba, kunnr,
                          znet_status, znet_origem, znet_condicoes, znet_matches,
                          znet_preco_min, znet_preco_max, znet_detalhes_json,
                          ziad_status, ziad_detalhes_json, detalhes_validacao_json,
                          resultado, motivo, atualizado_em
FROM dbo.VEND_AnaliseItem
                   WHERE conta=? AND numero=?
                   ORDER BY id""",
                str(conta).upper(), str(numero),
            ).fetchall()
    except Exception:
        return []

    resultado = []
    for r in rows:
        try:
            znet_detalhes = json.loads(r.znet_detalhes_json) if r.znet_detalhes_json else []
        except Exception:
            znet_detalhes = []
        try:
            ziad_detalhes = json.loads(r.ziad_detalhes_json) if r.ziad_detalhes_json else []
        except Exception:
            ziad_detalhes = []
        try:
            detalhes_validacao = (
                json.loads(r.detalhes_validacao_json)
                if r.detalhes_validacao_json else {}
            )
        except Exception:
            detalhes_validacao = {}
        resultado.append({
            "linha": r.linha,
            "matnr": r.matnr,
            "preco_ariba": float(r.preco_ariba) if r.preco_ariba is not None else None,
            "moeda_ariba": r.moeda_ariba,
            "kunnr": r.kunnr,
            "znet_status": r.znet_status,
            "znet_origem": r.znet_origem,
            "znet_condicoes": int(r.znet_condicoes or 0),
            "znet_matches": int(r.znet_matches or 0),
            "znet_preco_min": float(r.znet_preco_min) if r.znet_preco_min is not None else None,
            "znet_preco_max": float(r.znet_preco_max) if r.znet_preco_max is not None else None,
            "znet_detalhes": znet_detalhes,
            "ziad_status": r.ziad_status,
            "ziad_detalhes": ziad_detalhes,
            "detalhes_validacao": detalhes_validacao,
            "resultado": r.resultado,
            "motivo": r.motivo,
            "atualizado_em": _dm(r.atualizado_em),
        })
    return resultado



def _carregar_validacoes_funcionais(conta, numero):
    try:
        with get_conn() as cn:
            rows = cn.cursor().execute(
                """SELECT id, conta, numero, linha, codigo, assinatura,
                          titulo, descricao, valor_detectado, status,
                          decisao_por, decisao_em, motivo_rejeicao,
                          criado_em, atualizado_em
                   FROM dbo.VEND_ValidacaoFuncional
                   WHERE conta=? AND numero=? AND ativo=1
                   ORDER BY id""",
                str(conta).upper(),
                str(numero),
            ).fetchall()
    except Exception:
        return []

    return [
        {
            "id": int(r.id),
            "conta": r.conta,
            "numero": r.numero,
            "linha": r.linha,
            "codigo": r.codigo,
            "assinatura": r.assinatura,
            "titulo": r.titulo,
            "descricao": r.descricao,
            "valor_detectado": r.valor_detectado,
            "status": r.status,
            "decisao_por": r.decisao_por,
            "decisao_em": _dm(r.decisao_em),
            "motivo_rejeicao": r.motivo_rejeicao,
            "criado_em": _dm(r.criado_em),
            "atualizado_em": _dm(r.atualizado_em),
        }
        for r in rows
    ]


def _criterio_por_codigo(item, codigo):
    detalhes = item.get("detalhes_validacao") or {}
    for grupo in ("cliente", "item"):
        criterios = detalhes.get(grupo) or []
        if not isinstance(criterios, list):
            continue
        for criterio in criterios:
            if isinstance(criterio, dict) and str(criterio.get("codigo") or "") == codigo:
                return criterio
    return None


def _sincronizar_validacoes_funcionais(conta, numero, analise):
    """Sincroniza condições que exigem decisão humana.

    A assinatura é estável por condição. Portanto, se uma sugestão já foi
    confirmada/rejeitada e a ordem for reanalisada com a mesma evidência, a
    decisão é preservada e a validação apenas volta a ficar ativa.
    """
    itens = analise.get("itens") or []
    detectadas = []

    for item in itens:
        if not isinstance(item, dict):
            continue

        linha = str(item.get("linha") or "")

        # --------------------------------------------------------------
        # 1) Regra já existente: retirada sem transportadora
        # --------------------------------------------------------------
        redespacho = _criterio_por_codigo(item, "redespacho")
        transportadora = _criterio_por_codigo(item, "transportadora")

        valor_redespacho = str((redespacho or {}).get("valor") or "").strip()
        valor_transportadora = str((transportadora or {}).get("valor") or "").strip()

        redespacho_retira = "RETIRA" in valor_redespacho.upper()
        transportadora_ausente = (
            not valor_transportadora
            or valor_transportadora.upper() in {
                "NÃO DISPONÍVEL",
                "NAO DISPONIVEL",
                "—",
                "NONE",
            }
            or str((transportadora or {}).get("status") or "") in {"dados", "pendente"}
        )

        if redespacho_retira and transportadora_ausente:
            assinatura = (
                f"redespacho={valor_redespacho.upper()}|"
                f"transportadora={valor_transportadora.upper() or 'AUSENTE'}"
            )
            detectadas.append({
                "linha": linha,
                "codigo": "retira_sem_transportadora",
                "assinatura": assinatura,
                "titulo": "Retirada sem transportadora",
                "descricao": (
                    "O cadastro indica retirada e não há transportadora definida. "
                    "Confirme se o pedido realmente deve seguir como retirada pelo cliente."
                ),
                "valor_detectado": (
                    f"Redespacho: {valor_redespacho or 'RETIRA'} · "
                    f"Transportadora: {valor_transportadora or 'não cadastrada'}"
                ),
            })

        # --------------------------------------------------------------
        # 2) Sugestão histórica de MATNR
        # --------------------------------------------------------------
        knmt_status = str(item.get("knmt_status") or "").strip().lower()
        hist_status = str(item.get("historico_kdmat_status") or "").strip().lower()
        hist_matnr = str(item.get("historico_kdmat_matnr") or "").strip()
        kunnr = str(item.get("kunnr") or "").strip()
        kdmat = str(item.get("kdmat") or "").strip()
        matnr_ariba = str(item.get("matnr_ariba_original") or "").strip()

        knmt_ausente = knmt_status in {"nao_encontrado", "não_encontrado", "not_found"}
        historico_unico_compativel = (
            knmt_ausente
            and hist_status in {"ok", "sugestao_ultimo"}
            and bool(hist_matnr)
            and bool(kunnr)
            and bool(kdmat)
            and (not matnr_ariba or matnr_ariba == hist_matnr)
        )

        if historico_unico_compativel:
            assinatura = (
                f"kunnr={kunnr}|kdmat={kdmat}|matnr={hist_matnr}"
            )
            ultimo_vbeln = str(item.get("historico_kdmat_ultimo_vbeln") or "").strip()
            detectadas.append({
                "linha": linha,
                "codigo": "sugestao_historica_matnr",
                "assinatura": assinatura,
                "titulo": "Sugestão histórica",
                "descricao": (
                    "A relação KUNNR + KDMAT não está cadastrada na KNMT. "
                    "O histórico de ordens encontrou um MATNR sugerido. Quando houver "
                    "mais de um material histórico, é sugerido o material do pedido mais recente. "
                    "Confirme a sugestão para aceitar esse material neste pedido ou "
                    "rejeite para bloquear e solicitar cadastro no SAP."
                ),
                "valor_detectado": (
                    f"KUNNR {kunnr} · KDMAT {kdmat} → MATNR sugerido {hist_matnr}"
                    + (f" (OV {ultimo_vbeln})" if ultimo_vbeln else "")
                ),
            })

    with get_conn() as cn:
        cur = cn.cursor()

        cur.execute(
            """UPDATE dbo.VEND_ValidacaoFuncional
               SET ativo=0, atualizado_em=GETDATE()
               WHERE conta=? AND numero=? AND ativo=1""",
            str(conta).upper(),
            str(numero),
        )

        for item in detectadas:
            row = cur.execute(
                """SELECT TOP 1 id
                   FROM dbo.VEND_ValidacaoFuncional
                   WHERE conta=? AND numero=?
                     AND ISNULL(linha,'')=?
                     AND codigo=?
                     AND assinatura=?
                   ORDER BY id DESC""",
                str(conta).upper(),
                str(numero),
                item["linha"],
                item["codigo"],
                item["assinatura"],
            ).fetchone()

            if row:
                # Não altera status/decisão: confirmação/rejeição anterior é
                # preservada quando a mesma evidência reaparece na reanálise.
                cur.execute(
                    """UPDATE dbo.VEND_ValidacaoFuncional
                       SET ativo=1,
                           titulo=?,
                           descricao=?,
                           valor_detectado=?,
                           atualizado_em=GETDATE()
                       WHERE id=?""",
                    item["titulo"],
                    item["descricao"],
                    item["valor_detectado"],
                    int(row.id),
                )
            else:
                cur.execute(
                    """INSERT INTO dbo.VEND_ValidacaoFuncional
                       (conta, numero, linha, codigo, assinatura,
                        titulo, descricao, valor_detectado,
                        status, ativo)
                       VALUES (?,?,?,?,?,?,?,?, 'pendente', 1)""",
                    str(conta).upper(),
                    str(numero),
                    item["linha"],
                    item["codigo"],
                    item["assinatura"],
                    item["titulo"],
                    item["descricao"],
                    item["valor_detectado"],
                )

        cn.commit()


def _recalcular_resultado_visual_item(item):
    if montar_resumo_item is not None:
        montar_resumo_item(item)
        return
    detalhes = item.get("detalhes_validacao") or {}
    criterios = []
    for grupo in ("cliente", "item"):
        grupo_itens = detalhes.get(grupo) or []
        if isinstance(grupo_itens, list):
            criterios.extend(x for x in grupo_itens if isinstance(x, dict))

    bloqueantes = [c for c in criterios if c.get("bloqueante")]
    statuses = {str(c.get("status") or "") for c in bloqueantes}

    if "erro" in statuses:
        item["resultado"] = "erro"
    elif "divergencia" in statuses:
        item["resultado"] = "divergencia"
    elif statuses.intersection({"dados", "pendente", "funcional"}):
        item["resultado"] = "dados_insuficientes"
    else:
        item["resultado"] = "concluido"

    resumo = detalhes.setdefault("resumo", {})
    if item["resultado"] == "concluido":
        resumo["titulo"] = "Concluído tecnicamente"
        resumo["descricao"] = "Todas as validações obrigatórias disponíveis foram concluídas."
    elif item["resultado"] == "divergencia":
        resumo["titulo"] = "Divergência"
        resumo["descricao"] = "Existe uma divergência que impede a conclusão da Etapa 2."
    elif item["resultado"] == "erro":
        resumo["titulo"] = "Erro técnico"
        resumo["descricao"] = "Ocorreu uma falha técnica durante a análise."
    else:
        resumo["titulo"] = "Dados insuficientes"
        resumo["descricao"] = "Ainda existem validações obrigatórias pendentes."

    # O front usa status_final_etapa2 para o gate principal.
    detalhes["status_final_etapa2"] = {
        "status": item["resultado"],
        "titulo": resumo.get("titulo"),
        "descricao": resumo.get("descricao"),
    }


def _aplicar_validacoes_funcionais(analises, validacoes):
    por_linha = {}
    for validacao in validacoes or []:
        por_linha.setdefault(str(validacao.get("linha") or ""), []).append(validacao)

    for item in analises or []:
        linha = str(item.get("linha") or "")

        for validacao in por_linha.get(linha, []):
            codigo_validacao = str(validacao.get("codigo") or "")
            status = str(validacao.get("status") or "pendente").lower()

            # ----------------------------------------------------------
            # Retirada sem transportadora (regra já existente)
            # ----------------------------------------------------------
            if codigo_validacao == "retira_sem_transportadora":
                criterio = _criterio_por_codigo(item, "transportadora")
                if not criterio:
                    continue

                if status == "confirmado":
                    criterio.update({
                        "status": "ok",
                        "valor": "Não aplicável — retirada confirmada",
                        "detalhe": (
                            f"Retirada confirmada por {validacao.get('decisao_por') or 'usuário'} "
                            f"em {validacao.get('decisao_em') or 'data não disponível'}."
                        ),
                        "bloqueante": False,
                    })
                elif status == "rejeitado":
                    criterio.update({
                        "status": "divergencia",
                        "valor": "Retirada rejeitada",
                        "detalhe": (
                            f"A condição de retirada foi rejeitada por "
                            f"{validacao.get('decisao_por') or 'usuário'}"
                            + (
                                f". Motivo: {validacao.get('motivo_rejeicao')}."
                                if validacao.get("motivo_rejeicao") else "."
                            )
                        ),
                        "bloqueante": True,
                    })
                else:
                    criterio.update({
                        "status": "funcional",
                        "valor": "Aguardando confirmação de retirada",
                        "detalhe": (
                            "A automação identificou uma condição de retirada sem transportadora. "
                            "É necessária confirmação humana."
                        ),
                        "bloqueante": True,
                    })

            # ----------------------------------------------------------
            # Sugestão histórica de MATNR
            # ----------------------------------------------------------
            elif codigo_validacao == "sugestao_historica_matnr":
                criterio = _criterio_por_codigo(item, "knmt_relacao")
                if not criterio:
                    continue

                valor_detectado = str(validacao.get("valor_detectado") or "").strip()
                auditor = validacao.get("decisao_por") or "usuário"
                quando = validacao.get("decisao_em") or "data não disponível"

                if status == "confirmado":
                    criterio.update({
                        "status": "ok",
                        "valor": "Sugestão histórica confirmada",
                        "detalhe": (
                            f"{valor_detectado}. Confirmado por {auditor} em {quando}. "
                            "Origem: histórico DCLO/VBAK+VBAP. A confirmação vale para este pedido."
                        ),
                        "bloqueante": False,
                    })
                    criterio_matnr = _criterio_por_codigo(item, "matnr")
                    if criterio_matnr:
                        criterio_matnr["detalhe"] = (
                            f"Origem: sugestão histórica DCLO/VBAK+VBAP confirmada por "
                            f"{auditor} em {quando}."
                        )

                elif status == "rejeitado":
                    criterio.update({
                        "status": "divergencia",
                        "valor": "Sugestão histórica rejeitada",
                        "detalhe": (
                            f"{valor_detectado}. Rejeitado por {auditor} em {quando}. "
                            "O material histórico não será aceito para a Parte 3. "
                            "Solicitar cadastro manual da relação KUNNR + KDMAT no SAP."
                            + (
                                f" Motivo: {validacao.get('motivo_rejeicao')}."
                                if validacao.get("motivo_rejeicao") else ""
                            )
                        ),
                        "bloqueante": True,
                    })

                else:
                    criterio.update({
                        "status": "funcional",
                        "valor": "Sugestão histórica aguardando confirmação",
                        "detalhe": (
                            f"{valor_detectado}. A KNMT não possui a relação oficial. "
                            "Confirme ou rejeite a sugestão antes de liberar este item para a Parte 3."
                        ),
                        "bloqueante": True,
                    })

        _recalcular_resultado_visual_item(item)

    return analises


def _atualizar_status_etapa2_por_validacoes(conta, numero):
    """Atualiza o status exibido na lista usando as decisões humanas ativas."""
    analises = _carregar_analise_etapa2(conta, numero)
    validacoes = _carregar_validacoes_funcionais(conta, numero)
    analises = _aplicar_validacoes_funcionais(analises, validacoes)

    resultados = [str(x.get("resultado") or "").lower() for x in analises]
    if status_ordem_por_resultados is not None:
        status = status_ordem_por_resultados(resultados)
    elif not resultados:
        status = "idle"
    elif "erro" in resultados:
        status = "err"
    elif "divergencia" in resultados:
        status = "warn"
    elif any(x in {"dados_insuficientes", "pendente"} for x in resultados):
        status = "dados"
    else:
        status = "ok"

    concluidos = resultados.count("concluido")
    divergencias = resultados.count("divergencia")
    dados = sum(1 for x in resultados if x in {"dados_insuficientes", "pendente"})
    erros = resultados.count("erro")
    msg = (
        f"{len(resultados)} item(ns): {concluidos} concluído(s), "
        f"{divergencias} divergência(s), {dados} pendente(s), {erros} erro(s)."
    )

    with get_conn() as cn:
        cn.cursor().execute(
            """UPDATE dbo.VEND_Ordem
               SET etapa2_status=?, etapa2_msg=?, etapa2_atualizado_em=GETDATE()
               WHERE conta=? AND numero=?""",
            status,
            msg,
            str(conta).upper(),
            str(numero),
        )
        cn.commit()

    return status, msg


def _ler_payload_etapa2(conta, numero, json_path=None):
    path = None
    if json_path:
        try:
            candidate = Path(json_path).expanduser().resolve()
            if any(_path_is_under(candidate, root) for root in ALLOWED_JSON_ROOTS):
                if candidate.exists() and candidate.is_file():
                    path = candidate
        except Exception:
            path = None
    if path is None:
        path = _find_new_order_json(str(conta).upper(), str(numero))
    if path is None:
        raise FileNotFoundError(f"JSON não encontrado para {conta}/{numero}")

    texto = None
    ultimo = None
    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            texto = path.read_text(encoding=enc)
            break
        except Exception as exc:
            ultimo = exc
    if texto is None:
        raise RuntimeError(f"Não foi possível ler o JSON: {ultimo}")
    return json.loads(texto)


def _persistir_analise_etapa2(conta, numero, analise):
    itens = analise.get("itens") or []
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            "DELETE FROM dbo.VEND_AnaliseItem WHERE conta=? AND numero=?",
            conta, str(numero),
        )
        for item in itens:
            cur.execute(
                """INSERT INTO dbo.VEND_AnaliseItem
                   (conta, numero, linha, matnr, preco_ariba, moeda_ariba, kunnr,
                    znet_status, znet_origem, znet_condicoes, znet_matches,
                    znet_preco_min, znet_preco_max, znet_detalhes_json,
                    ziad_status, ziad_detalhes_json, detalhes_validacao_json,
                    resultado, motivo)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                conta,
                str(numero),
                str(item.get("linha") or ""),
                item.get("matnr"),
                item.get("preco_ariba"),
                item.get("moeda_ariba"),
                item.get("kunnr"),
                item.get("znet_status"),
                item.get("znet_origem"),
                int(item.get("znet_condicoes") or 0),
                int(item.get("znet_matches") or 0),
                item.get("znet_preco_min"),
                item.get("znet_preco_max"),
                json.dumps(item.get("znet_detalhes") or [], ensure_ascii=False, default=str),
                item.get("ziad_status"),
                json.dumps(item.get("ziad_detalhes") or [], ensure_ascii=False, default=str),
                json.dumps(item.get("detalhes_validacao") or {}, ensure_ascii=False, default=str),
                item.get("resultado"),
                item.get("motivo"),
            )

        cur.execute(
            """UPDATE dbo.VEND_Ordem
               SET etapa2_status=?, etapa2_msg=?, etapa2_atualizado_em=GETDATE()
               WHERE conta=? AND numero=?""",
            analise.get("status") or "dados",
            (analise.get("resumo") or "")[:1000],
            conta,
            str(numero),
        )
        cn.commit()

    _sincronizar_validacoes_funcionais(conta, numero, analise)

    # A reclassificação por validações funcionais depende de itens gravados em
    # VEND_AnaliseItem. Ofertas retornam status "na" e, por definição, não
    # geram itens de análise. Recalcular uma lista vazia transformava
    # incorretamente "na" em "idle". Quando não há itens, preserva o status
    # devolvido pelo motor da Etapa 2.
    if itens:
        _atualizar_status_etapa2_por_validacoes(conta, numero)


def _executar_etapa2_execucao(conta, exec_id):
    conta = str(conta or "").upper()
    # Garante que todas as ordens recebidas pela ingestão assíncrona da Etapa 1
    # já tenham sido persistidas antes de começar a análise.
    _db_fila.join()

    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT numero, json_path
               FROM dbo.VEND_Ordem
               WHERE conta=? AND etapa1_status='ok'
               ORDER BY numero""",
            conta,
        ).fetchall()

    total = len(rows)
    _set_etapa2_state(
        conta, running=True, execucao_id=exec_id, total=total, concluido=0, erros=0
    )
    bus.publish({
        "tipo": "etapa2_inicio",
        "conta": conta,
        "execucao_id": exec_id,
        "total": total,
    })

    if analisar_pedido is None:
        erro = ETAPA2_IMPORT_ERROR or "Módulo etapa2_validacao indisponível."
        with get_conn() as cn:
            cn.cursor().execute(
                """UPDATE dbo.VEND_Ordem
                   SET etapa2_status='err', etapa2_msg=?, etapa2_atualizado_em=GETDATE()
                   WHERE conta=? AND etapa1_status='ok'""",
                erro[:990], conta,
            )
            cn.commit()
        _set_etapa2_state(conta, running=False, erros=total)
        bus.publish({"tipo": "etapa2_fim", "conta": conta, "execucao_id": exec_id, "status": "err", "erro": erro})
        return

    erros = 0
    concluido = 0
    for row in rows:
        numero = str(row.numero)
        try:
            with get_conn() as cn:
                cn.cursor().execute(
                    """UPDATE dbo.VEND_Ordem
                       SET etapa2_status='run', etapa2_msg='Analisando ZNET/ZIAD...',
                           etapa2_atualizado_em=GETDATE()
                       WHERE conta=? AND numero=?""",
                    conta, numero,
                )
                cn.commit()

            bus.publish({"tipo": "etapa2_ordem", "conta": conta, "numero": numero, "status": "run"})
            payload = _ler_payload_etapa2(conta, numero, row.json_path)
            analise = analisar_pedido(payload, mapeamentos_pagamento=_carregar_mapeamentos_pagamento(), mapeamentos_mvke=_carregar_mapeamentos_mvke(), parametros_clientes=_carregar_parametros_clientes(), mapeamentos_shipto=_carregar_mapeamentos_shipto())
            _persistir_analise_etapa2(conta, numero, analise)
            status = analise.get("status") or "dados"
            if status == "err":
                erros += 1
            concluido += 1
            _set_etapa2_state(conta, concluido=concluido, erros=erros)
            bus.publish({
                "tipo": "etapa2_ordem",
                "conta": conta,
                "numero": numero,
                "status": status,
                "resumo": analise.get("resumo"),
                "concluido": concluido,
                "total": total,
                "erros": erros,
            })
        except Exception as exc:
            erros += 1
            concluido += 1
            mensagem = f"{type(exc).__name__}: {exc}"[:990]
            app.logger.exception("Etapa 2 falhou no pedido %s/%s", conta, numero)
            try:
                with get_conn() as cn:
                    cn.cursor().execute(
                        """UPDATE dbo.VEND_Ordem
                           SET etapa2_status='err', etapa2_msg=?, etapa2_atualizado_em=GETDATE()
                           WHERE conta=? AND numero=?""",
                        mensagem, conta, numero,
                    )
                    cn.commit()
            except Exception:
                # Falha ao registrar o erro não pode interromper os demais pedidos.
                app.logger.exception("Não foi possível registrar o erro do pedido %s/%s", conta, numero)
            _set_etapa2_state(conta, concluido=concluido, erros=erros)
            bus.publish({
                "tipo": "etapa2_ordem",
                "conta": conta,
                "numero": numero,
                "status": "err",
                "resumo": mensagem,
                "concluido": concluido,
                "total": total,
                "erros": erros,
            })

    _set_etapa2_state(conta, running=False, concluido=concluido, erros=erros)
    bus.publish({
        "tipo": "etapa2_fim",
        "conta": conta,
        "execucao_id": exec_id,
        "status": "err" if erros and erros == total and total else "ok",
        "total": total,
        "concluido": concluido,
        "erros": erros,
    })


def _executar_etapa2_ordem_manual(conta, numero):
    """Reexecuta somente a Etapa 2 de um pedido já coletado, sem baixar Ariba novamente."""
    conta = str(conta or "").upper()
    numero = str(numero or "")

    with get_conn() as cn:
        row = cn.cursor().execute(
            """SELECT TOP 1 json_path, etapa1_status
               FROM dbo.VEND_Ordem
               WHERE conta=? AND numero=?
               ORDER BY atualizado_em DESC""",
            conta, numero,
        ).fetchone()

    if not row:
        raise ValueError("Pedido não encontrado.")
    if str(row.etapa1_status or "") != "ok":
        raise ValueError("A Etapa 1 deste pedido ainda não está concluída com sucesso.")
    if analisar_pedido is None:
        raise RuntimeError(ETAPA2_IMPORT_ERROR or "Módulo etapa2_validacao indisponível.")

    _set_etapa2_state(conta, running=True, execucao_id=None, total=1, concluido=0, erros=0)
    bus.publish({"tipo": "etapa2_inicio", "conta": conta, "execucao_id": None, "total": 1})

    with get_conn() as cn:
        cn.cursor().execute(
            """UPDATE dbo.VEND_Ordem
               SET etapa2_status='run', etapa2_msg='Reanalisando Etapa 2...',
                   etapa2_atualizado_em=GETDATE()
               WHERE conta=? AND numero=?""",
            conta, numero,
        )
        cn.commit()

    bus.publish({"tipo": "etapa2_ordem", "conta": conta, "numero": numero, "status": "run", "total": 1, "concluido": 0})

    try:
        payload = _ler_payload_etapa2(conta, numero, row.json_path)
        analise = analisar_pedido(payload, mapeamentos_pagamento=_carregar_mapeamentos_pagamento(), mapeamentos_mvke=_carregar_mapeamentos_mvke(), parametros_clientes=_carregar_parametros_clientes(), mapeamentos_shipto=_carregar_mapeamentos_shipto())
        _persistir_analise_etapa2(conta, numero, analise)
    except Exception as exc:
        # Não deixa o pedido preso em "Analisando".
        app.logger.exception("Reanálise da Etapa 2 falhou no pedido %s/%s", conta, numero)
        try:
            with get_conn() as cn:
                cn.cursor().execute(
                    """UPDATE dbo.VEND_Ordem
                       SET etapa2_status='err', etapa2_msg=?, etapa2_atualizado_em=GETDATE()
                       WHERE conta=? AND numero=?""",
                    f"{type(exc).__name__}: {exc}"[:990], conta, numero,
                )
                cn.commit()
        except Exception:
            pass
        raise
    status = analise.get("status") or "dados"
    erros = 1 if status == "err" else 0

    _set_etapa2_state(conta, running=False, concluido=1, erros=erros)
    bus.publish({
        "tipo": "etapa2_ordem",
        "conta": conta,
        "numero": numero,
        "status": status,
        "resumo": analise.get("resumo"),
        "concluido": 1,
        "total": 1,
        "erros": erros,
    })
    bus.publish({
        "tipo": "etapa2_fim",
        "conta": conta,
        "execucao_id": None,
        "status": "err" if erros else "ok",
        "total": 1,
        "concluido": 1,
        "erros": erros,
    })


@app.route("/api/ordens/<conta>/<numero>/reanalisar", methods=["POST"])
def reanalisar_etapa2_ordem(conta, numero):
    conta = str(conta or "").upper()
    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400
    if _get_etapa2_state(conta).get("running"):
        return jsonify({"erro": f"Já existe uma análise da conta {conta} em andamento."}), 409

    _ensure_etapa2_worker()
    try:
        _etapa2_fila.put_nowait({"tipo": "ordem", "conta": conta, "numero": str(numero)})
    except queue.Full:
        return jsonify({"erro": "Fila da Etapa 2 cheia."}), 503

    return jsonify({"ok": True, "conta": conta, "numero": str(numero)}), 202


@app.route("/api/ordens/<conta>/reanalisar-todos", methods=["POST"])
def reanalisar_etapa2_todos(conta):
    """Reexecuta a Etapa 2 de todos os pedidos já coletados da conta.

    Não chama a API do Ariba novamente. A rotina em lote usa somente pedidos
    persistidos com Etapa 1 concluída e publica o progresso pelo mesmo stream
    já utilizado pela execução normal da Etapa 2.
    """
    conta = str(conta or "").upper()
    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400

    if _proc_running(conta):
        return jsonify({
            "erro": f"A coleta da conta {conta} está em andamento. Aguarde a Etapa 1 terminar."
        }), 409

    if _get_etapa2_state(conta).get("running"):
        return jsonify({"erro": f"Já existe uma análise da conta {conta} em andamento."}), 409

    with get_conn() as cn:
        total = cn.cursor().execute(
            """SELECT COUNT(*)
               FROM dbo.VEND_Ordem
               WHERE conta=? AND etapa1_status='ok'""",
            conta,
        ).fetchone()[0]

    if not total:
        return jsonify({
            "erro": f"Não há pedidos da conta {conta} com a Etapa 1 concluída para reanalisar."
        }), 409

    _ensure_etapa2_worker()
    try:
        # O worker já trata tuplas como execução em lote. exec_id=None sinaliza
        # reanálise manual de tudo que já foi coletado, sem uma nova coleta.
        _etapa2_fila.put_nowait((conta, None))
    except queue.Full:
        return jsonify({"erro": "Fila da Etapa 2 cheia."}), 503

    return jsonify({
        "ok": True,
        "conta": conta,
        "total": int(total),
        "mensagem": f"{int(total)} pedido(s) enviado(s) para reanálise da Etapa 2.",
    }), 202


@app.route("/api/ordens/<conta>/<numero>/uteis")
def campos_uteis(conta, numero):
    """
    Retorna apenas os campos ÚTEIS do pedido (subconjunto grifado pelo time),
    já classificado como Contrato/Oferta, para exibição em tabela.

    Lê o JSON final já salvo pela automação — não altera o banco nem reexecuta
    a coleta. Campos que a API de Purchase Orders não expõe voltam com
    coletavel=False para o front mostrar "— não coletado".
    """
    if extrair_campos_uteis is None:
        return jsonify({"erro": "Extração de campos indisponível: módulo order_fields ausente."}), 500

    try:
        path = _resolve_order_json_path(conta, numero)
    except HTTPException:
        raise
    except Exception as exc:
        return jsonify({"erro": f"Falha ao localizar o JSON: {exc}"}), 500

    # Lê o arquivo tolerando variações de encoding (utf-8 com/sem BOM, latin-1).
    texto = None
    ultimo_erro = None
    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            texto = path.read_text(encoding=enc)
            ultimo_erro = None
            break
        except Exception as exc:
            ultimo_erro = exc
    if texto is None:
        return jsonify({
            "erro": f"Não foi possível ler o arquivo do pedido: {ultimo_erro}",
            "arquivo": str(path),
        }), 500

    try:
        payload = json.loads(texto)
    except Exception as exc:
        return jsonify({
            "erro": f"JSON inválido no arquivo do pedido: {exc}",
            "arquivo": str(path),
        }), 500

    try:
        resultado = extrair_campos_uteis(payload)
        validacoes_funcionais = _carregar_validacoes_funcionais(conta, numero)
        analise_etapa2 = _carregar_analise_etapa2(conta, numero)
        analise_etapa2 = _aplicar_validacoes_funcionais(
            analise_etapa2,
            validacoes_funcionais,
        )
        resultado["analise_etapa2"] = analise_etapa2
        resultado["validacoes_funcionais"] = validacoes_funcionais
        return jsonify(resultado)
    except Exception as exc:
        app.logger.exception("Falha ao extrair campos úteis do pedido %s/%s", conta, numero)
        return jsonify({
            "erro": f"Não foi possível extrair os campos do pedido: {type(exc).__name__}: {exc}",
            "arquivo": str(path),
        }), 500



@app.route(
    "/api/ordens/<conta>/<numero>/validacoes-funcionais/<int:validacao_id>/decidir",
    methods=["POST"],
)
def decidir_validacao_funcional(conta, numero, validacao_id):
    conta = str(conta or "").upper()
    numero = str(numero or "")
    dados = request.get_json(silent=True) or {}

    decisao = str(dados.get("decisao") or "").strip().lower()
    motivo = str(dados.get("motivo") or "").strip() or None

    if decisao not in ("confirmado", "rejeitado"):
        return jsonify({"erro": "Decisão inválida. Use confirmado ou rejeitado."}), 400

    usuario = usuario_atual()

    with get_conn() as cn:
        cur = cn.cursor()
        row = cur.execute(
            """SELECT TOP 1 id
               FROM dbo.VEND_ValidacaoFuncional
               WHERE id=? AND conta=? AND numero=? AND ativo=1""",
            int(validacao_id),
            conta,
            numero,
        ).fetchone()

        if not row:
            return jsonify({"erro": "Validação funcional não encontrada ou não está mais ativa."}), 404

        cur.execute(
            """UPDATE dbo.VEND_ValidacaoFuncional
               SET status=?,
                   decisao_por=?,
                   decisao_em=GETDATE(),
                   motivo_rejeicao=?,
                   atualizado_em=GETDATE()
               WHERE id=?""",
            decisao,
            usuario,
            motivo if decisao == "rejeitado" else None,
            int(validacao_id),
        )
        cn.commit()

    status_etapa2, resumo_etapa2 = _atualizar_status_etapa2_por_validacoes(conta, numero)

    bus.publish({
        "tipo": "validacao_funcional",
        "conta": conta,
        "numero": numero,
        "id": int(validacao_id),
        "status": decisao,
        "usuario": usuario,
    })

    return jsonify({
        "ok": True,
        "id": int(validacao_id),
        "status": decisao,
        "usuario": usuario,
        "etapa2_status": status_etapa2,
        "etapa2_resumo": resumo_etapa2,
    })

@app.route("/api/logs")
def listar_logs():
    conta = request.args.get("conta", "ITA").upper()
    limite = request.args.get("limite", default=100, type=int)
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT TOP (?) nivel, mensagem, criado_em
               FROM dbo.VEND_Log WHERE conta = ? ORDER BY id DESC""",
            limite,
            conta,
        ).fetchall()
    return jsonify(
        [
            {"nivel": r.nivel, "mensagem": r.mensagem, "hora": _hora(r.criado_em)}
            for r in reversed(rows)
        ]
    )


@app.route("/api/resumo")
def resumo():
    conta = request.args.get("conta", "ITA").upper()
    with get_conn() as cn:
        cur = cn.cursor()
        k = cur.execute(
            """SELECT
                 SUM(CASE WHEN etapa1_status IN ('idle','run') THEN 1 ELSE 0 END) AS fila,
                 SUM(CASE WHEN etapa1_status = 'ok'  THEN 1 ELSE 0 END) AS ok,
                 SUM(CASE WHEN etapa1_status = 'run' THEN 1 ELSE 0 END) AS run,
                 SUM(CASE WHEN etapa1_status = 'err' THEN 1 ELSE 0 END) AS err
               FROM dbo.VEND_Ordem WHERE conta = ?""",
            conta,
        ).fetchone()
        ex = cur.execute(
            """SELECT TOP 1 status, total, sucesso, erros, iniciado_em, finalizado_em, iniciado_por
               FROM dbo.VEND_Execucao WHERE conta = ? ORDER BY iniciado_em DESC""",
            conta,
        ).fetchone()
        e2 = cur.execute(
            """SELECT
                 SUM(CASE WHEN etapa2_status = 'idle' THEN 1 ELSE 0 END) AS aguardando,
                 SUM(CASE WHEN etapa2_status = 'run' THEN 1 ELSE 0 END) AS run,
                 SUM(CASE WHEN etapa2_status = 'ok' THEN 1 ELSE 0 END) AS analisado,
                 SUM(CASE WHEN etapa2_status = 'warn' THEN 1 ELSE 0 END) AS divergencia,
                 SUM(CASE WHEN etapa2_status = 'dados' THEN 1 ELSE 0 END) AS dados_insuficientes,
                 SUM(CASE WHEN etapa2_status IN ('pending','partial') THEN 1 ELSE 0 END) AS pendente,
                 SUM(CASE WHEN etapa2_status = 'na' THEN 1 ELSE 0 END) AS nao_aplicavel,
                 SUM(CASE WHEN etapa2_status = 'err' THEN 1 ELSE 0 END) AS err
               FROM dbo.VEND_Ordem WHERE conta = ? AND etapa1_status='ok'""",
            conta,
        ).fetchone()

    etapa2_state = _get_etapa2_state(conta)

    return jsonify(
        {
            "kpi": {
                "fila": k.fila or 0,
                "ok": k.ok or 0,
                "run": k.run or 0,
                "err": k.err or 0,
            },
            "execucao": None
            if not ex
            else {
                "status": ex.status,
                "total": ex.total or 0,
                "sucesso": ex.sucesso or 0,
                "erros": ex.erros or 0,
                "iniciado_em": _dm(ex.iniciado_em),
                "finalizado_em": _dm(ex.finalizado_em),
                "iniciado_por": ex.iniciado_por,
            },
            "processo": {"running": _proc_running(conta)},
            "etapa2": {
                "running": bool(etapa2_state.get("running")),
                "execucao_id": etapa2_state.get("execucao_id"),
                "total_execucao": int(etapa2_state.get("total") or 0),
                "concluido_execucao": int(etapa2_state.get("concluido") or 0),
                "erros_execucao": int(etapa2_state.get("erros") or 0),
                "aguardando": int((e2.aguardando if e2 else 0) or 0),
                "run": int((e2.run if e2 else 0) or 0),
                "analisado": int((e2.analisado if e2 else 0) or 0),
                "divergencia": int((e2.divergencia if e2 else 0) or 0),
                "dados_insuficientes": int((e2.dados_insuficientes if e2 else 0) or 0),
                "pendente": int((e2.pendente if e2 else 0) or 0),
                "nao_aplicavel": int((e2.nao_aplicavel if e2 else 0) or 0),
                "err": int((e2.err if e2 else 0) or 0),
            },
        }
    )


# =============================================================================
# AGENDAMENTOS
# =============================================================================
def _parse_hhmm(value):
    text = str(value or "").strip()
    if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", text):
        raise ValueError("Horário inválido. Use HH:MM.")
    return text


def _validate_schedule_payload(d):
    conta = str(d.get("conta") or "ITA").upper()
    periodo = str(d.get("periodo") or "24h").lower()
    frequencia = str(d.get("frequencia") or "DAILY").upper()
    horario = _parse_hhmm(d.get("horario"))
    data_execucao = str(d.get("data_execucao") or "").strip() or None
    ativo = bool(d.get("ativo", True))

    if conta not in ("ITA", "POP"):
        raise ValueError("Conta inválida.")
    if periodo not in ("24h", "365d"):
        raise ValueError("Período inválido.")
    if frequencia not in ("DAILY", "ONCE"):
        raise ValueError("Recorrência inválida.")
    if frequencia == "ONCE":
        if not data_execucao:
            raise ValueError("Informe a data da execução única.")
        try:
            date.fromisoformat(data_execucao)
        except Exception:
            raise ValueError("Data inválida.")
    else:
        data_execucao = None

    return conta, horario, frequencia, data_execucao, periodo, ativo


def _schedule_json(row):
    hora = row.horario.strftime("%H:%M") if hasattr(row.horario, "strftime") else str(row.horario)[:5]
    data_exec = row.data_execucao.isoformat() if getattr(row, "data_execucao", None) else None
    return {
        "id": int(row.id),
        "conta": row.conta,
        "horario": hora,
        "frequencia": row.frequencia,
        "data_execucao": data_exec,
        "periodo": row.periodo,
        "ativo": bool(row.ativo),
        "ultima_execucao": _dm(row.ultima_execucao),
    }


@app.route("/api/agendamentos", methods=["GET"])
def listar_agendamentos():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, conta, horario, frequencia, data_execucao, periodo,
                      ativo, ultima_execucao
               FROM dbo.VEND_Agendamento ORDER BY ativo DESC, conta, horario"""
        ).fetchall()
    return jsonify([_schedule_json(r) for r in rows])


@app.route("/api/agendamentos", methods=["POST"])
def criar_agendamento():
    try:
        conta, horario, frequencia, data_execucao, periodo, ativo = _validate_schedule_payload(request.json or {})
    except ValueError as exc:
        return jsonify({"erro": str(exc)}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """INSERT INTO dbo.VEND_Agendamento
               (conta, horario, frequencia, data_execucao, periodo, ativo, criado_por)
               OUTPUT INSERTED.id VALUES (?, ?, ?, ?, ?, ?, ?)""",
            conta, horario, frequencia, data_execucao, periodo, 1 if ativo else 0, usuario_atual(),
        )
        schedule_id = int(cur.fetchone()[0])
        cn.commit()
    return jsonify({"ok": True, "id": schedule_id}), 201


@app.route("/api/agendamentos/<int:schedule_id>", methods=["PUT"])
def atualizar_agendamento(schedule_id):
    try:
        conta, horario, frequencia, data_execucao, periodo, ativo = _validate_schedule_payload(request.json or {})
    except ValueError as exc:
        return jsonify({"erro": str(exc)}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_Agendamento
               SET conta=?, horario=?, frequencia=?, data_execucao=?, periodo=?, ativo=?,
                   atualizado_em=GETDATE()
               WHERE id=?""",
            conta, horario, frequencia, data_execucao, periodo, 1 if ativo else 0, schedule_id,
        )
        cn.commit()
    return jsonify({"ok": True})


@app.route("/api/agendamentos/<int:schedule_id>", methods=["DELETE"])
def excluir_agendamento(schedule_id):
    with get_conn() as cn:
        cn.cursor().execute("DELETE FROM dbo.VEND_Agendamento WHERE id=?", schedule_id)
        cn.commit()
    return jsonify({"ok": True})


def _run_due_schedules():
    now = datetime.now()
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, conta, horario, frequencia, data_execucao, periodo,
                      ativo, ultima_execucao
               FROM dbo.VEND_Agendamento WHERE ativo=1"""
        ).fetchall()

    for row in rows:
        hh = row.horario.hour if hasattr(row.horario, "hour") else int(str(row.horario)[:2])
        mm = row.horario.minute if hasattr(row.horario, "minute") else int(str(row.horario)[3:5])
        due_time = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if now < due_time:
            continue

        last = row.ultima_execucao
        due = False
        if str(row.frequencia).upper() == "DAILY":
            due = last is None or last.date() < now.date()
        else:
            target_date = row.data_execucao
            due = (
                target_date is not None
                and target_date <= now.date()
                and last is None
            )

        if not due or _proc_running(row.conta):
            continue

        try:
            _start_collector(
                row.conta,
                period=row.periodo,
                started_by=f"agendamento:{row.id}",
                portal_url=PORTAL_INTERNAL_URL,
            )
            bus.publish({
                "tipo": "agendamento_disparado",
                "conta": str(row.conta).upper(),
                "agendamento_id": int(row.id),
                "periodo": str(row.periodo),
                "horario": f"{hh:02d}:{mm:02d}",
            })
        except Exception as exc:
            print(f"[AGENDADOR] Não foi possível iniciar #{row.id}: {exc}", flush=True)
            continue

        with get_conn() as cn:
            cur = cn.cursor()
            if str(row.frequencia).upper() == "ONCE":
                cur.execute(
                    """UPDATE dbo.VEND_Agendamento
                       SET ultima_execucao=GETDATE(), ativo=0, atualizado_em=GETDATE()
                       WHERE id=?""",
                    row.id,
                )
            else:
                cur.execute(
                    """UPDATE dbo.VEND_Agendamento
                       SET ultima_execucao=GETDATE(), atualizado_em=GETDATE()
                       WHERE id=?""",
                    row.id,
                )
            cn.commit()


_SCHEDULER_THREAD = None


def _scheduler_loop():
    while True:
        try:
            _run_due_schedules()
        except Exception as exc:
            print(f"[AGENDADOR] Erro: {exc}", flush=True)
        time.sleep(20)


def start_scheduler():
    global _SCHEDULER_THREAD
    if _SCHEDULER_THREAD and _SCHEDULER_THREAD.is_alive():
        return
    _SCHEDULER_THREAD = threading.Thread(target=_scheduler_loop, daemon=True)
    _SCHEDULER_THREAD.start()


# =============================================================================
# PARÂMETROS API ARIBA
# =============================================================================
@app.route("/api/parametros", methods=["GET"])
def get_parametros():
    conta = request.args.get("conta", "ITA").upper()
    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400
    with _CONFIG_LOCK:
        cfg = _load_ariba_config()
    return jsonify(_public_profile(conta, cfg[conta]))



@app.route("/api/parametros/revelar", methods=["POST"])
def revelar_parametro():
    """
    Revela UMA credencial somente após solicitação explícita do front
    (clique no ícone de olho).

    O endpoint:
    - aceita apenas ITA/POP;
    - aceita somente client_secret ou api_key;
    - não grava nem loga o valor;
    - responde com Cache-Control: no-store para evitar cache no navegador/proxy.
    """
    d = request.json or {}
    conta = (d.get("conta") or "").upper()
    campo = str(d.get("campo") or "").strip()

    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400

    nomes_permitidos = {
        "client_secret": "OAuth Secret",
        "api_key": "Application Key",
    }

    if campo not in nomes_permitidos:
        return jsonify({"erro": "Campo de credencial inválido."}), 400

    with _CONFIG_LOCK:
        cfg = _load_ariba_config()
        valor = str((cfg.get(conta) or {}).get(campo) or "")

    if not valor:
        return jsonify({"erro": f"{nomes_permitidos[campo]} não configurado para {conta}."}), 404

    resp = jsonify({
        "ok": True,
        "conta": conta,
        "campo": campo,
        "valor": valor,
    })
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/api/parametros", methods=["POST"])
def salvar_parametros():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400

    with _CONFIG_LOCK:
        cfg = _load_ariba_config()
        bloco = cfg[conta]
        for key in ("anid", "client_id"):
            if key in d:
                bloco[key] = str(d.get(key) or "").strip()
        # Segredos vazios significam "manter o atual".
        if str(d.get("client_secret") or "").strip():
            bloco["client_secret"] = str(d["client_secret"]).strip()
        if str(d.get("api_key") or "").strip():
            bloco["api_key"] = str(d["api_key"]).strip()

        faltando = _validate_profile(bloco)
        if faltando:
            return jsonify({"erro": "Campos obrigatórios ausentes: " + ", ".join(faltando)}), 400

        cfg[conta] = bloco
        _save_ariba_config(cfg)

    return jsonify({"ok": True, "parametros": _public_profile(conta, bloco)})


# =============================================================================
# =============================================================================
# =============================================================================
# PARÂMETROS COMERCIAIS POR CLIENTE
# =============================================================================
def _normalizar_kunnr_parametro(value):
    text = str(value or "").strip()
    if not text:
        return None
    return text.zfill(10) if text.isdigit() else text.upper()


def _carregar_parametros_clientes():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT kunnr, representante, comissao, motivo_beneficio_fiscal,
                      transportadora, redespacho, vtweg, destino_mercadoria
               FROM dbo.VEND_ParametroCliente
               WHERE ativo=1
               ORDER BY kunnr"""
        ).fetchall()

    return [
        {
            "kunnr": _normalizar_kunnr_parametro(r.kunnr),
            "representante": str(r.representante or "").strip(),
            "comissao": str(r.comissao or "").strip(),
            "motivo_beneficio_fiscal": str(r.motivo_beneficio_fiscal or "").strip(),
            "transportadora": str(r.transportadora or "").strip(),
            "redespacho": str(r.redespacho or "").strip(),
            "vtweg": str(r.vtweg or "").strip(),
            "destino_mercadoria": str(r.destino_mercadoria or "").strip(),
        }
        for r in rows
        if _normalizar_kunnr_parametro(r.kunnr)
    ]


@app.route("/api/parametros/clientes", methods=["GET"])
def listar_parametros_clientes():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, kunnr, representante, comissao, motivo_beneficio_fiscal,
                      transportadora, redespacho, vtweg, destino_mercadoria, atualizado_em
               FROM dbo.VEND_ParametroCliente
               WHERE ativo=1
               ORDER BY kunnr"""
        ).fetchall()

    return jsonify([
        {
            "id": int(r.id),
            "kunnr": _normalizar_kunnr_parametro(r.kunnr),
            "representante": r.representante or "",
            "comissao": r.comissao or "",
            "motivo_beneficio_fiscal": r.motivo_beneficio_fiscal or "",
            "transportadora": r.transportadora or "",
            "redespacho": r.redespacho or "",
            "vtweg": r.vtweg or "",
            "destino_mercadoria": r.destino_mercadoria or "",
            "atualizado_em": _dm(r.atualizado_em),
        }
        for r in rows
    ])


@app.route("/api/parametros/clientes", methods=["POST"])
def salvar_parametro_cliente():
    d = request.json or {}

    kunnr = _normalizar_kunnr_parametro(d.get("kunnr"))
    representante = str(d.get("representante") or "").strip() or None
    comissao = str(d.get("comissao") or "").strip() or None
    motivo = str(d.get("motivo_beneficio_fiscal") or "").strip() or None
    transportadora = str(d.get("transportadora") or "").strip() or None
    redespacho = str(d.get("redespacho") or "").strip() or None
    vtweg = str(d.get("vtweg") or "").strip() or None
    destino_mercadoria = str(d.get("destino_mercadoria") or "").strip() or None

    if vtweg and vtweg not in ("50", "52", "53"):
        return jsonify({"erro": "VTWEG inválido. Use 50, 52 ou 53."}), 400

    if not kunnr:
        return jsonify({"erro": "Informe o KUNNR."}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        row = cur.execute(
            "SELECT TOP 1 id FROM dbo.VEND_ParametroCliente WHERE kunnr=?",
            kunnr,
        ).fetchone()

        if row:
            parametro_id = int(row.id)
            cur.execute(
                """UPDATE dbo.VEND_ParametroCliente
                   SET representante=?, comissao=?, motivo_beneficio_fiscal=?,
                       transportadora=?, redespacho=?, vtweg=?, destino_mercadoria=?,
                       ativo=1, atualizado_em=GETDATE()
                   WHERE id=?""",
                representante, comissao, motivo, transportadora, redespacho,
                vtweg, destino_mercadoria, parametro_id,
            )
        else:
            cur.execute(
                """INSERT INTO dbo.VEND_ParametroCliente
                   (kunnr, representante, comissao, motivo_beneficio_fiscal,
                    transportadora, redespacho, vtweg, destino_mercadoria,
                    ativo, criado_por)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)""",
                kunnr, representante, comissao, motivo,
                transportadora, redespacho, vtweg, destino_mercadoria,
                usuario_atual(),
            )
            row_novo = cur.execute(
                "SELECT TOP 1 id FROM dbo.VEND_ParametroCliente WHERE kunnr=?",
                kunnr,
            ).fetchone()
            if not row_novo:
                raise RuntimeError("Parâmetro de cliente foi inserido, mas não foi possível recuperar o ID.")
            parametro_id = int(row_novo.id)

        cn.commit()

    return jsonify({
        "ok": True,
        "id": parametro_id,
        "kunnr": kunnr,
        "representante": representante or "",
        "comissao": comissao or "",
        "motivo_beneficio_fiscal": motivo or "",
        "transportadora": transportadora or "",
        "redespacho": redespacho or "",
        "vtweg": vtweg or "",
        "destino_mercadoria": destino_mercadoria or "",
    })


@app.route("/api/parametros/clientes/<int:parametro_id>", methods=["DELETE"])
def remover_parametro_cliente(parametro_id):
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_ParametroCliente
               SET ativo=0, atualizado_em=GETDATE()
               WHERE id=?""",
            int(parametro_id),
        )
        if cur.rowcount == 0:
            return jsonify({"erro": "Parâmetro de cliente não encontrado."}), 404
        cn.commit()

    return jsonify({"ok": True})


# MAPEAMENTO DE STATUS MVKE / VMSTA
# =============================================================================
def _carregar_mapeamentos_mvke():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT codigo_vmsta, classificacao, descricao
               FROM dbo.VEND_MapeamentoMVKE
               WHERE ativo=1
               ORDER BY codigo_vmsta"""
        ).fetchall()
    return [
        {
            "codigo_vmsta": str(r.codigo_vmsta or "").strip().upper(),
            "classificacao": str(r.classificacao or "").strip().lower(),
            "descricao": str(r.descricao or "").strip(),
        }
        for r in rows
        if str(r.codigo_vmsta or "").strip()
    ]


@app.route("/api/mapeamentos/mvke", methods=["GET"])
def listar_mapeamentos_mvke():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, codigo_vmsta, classificacao, descricao, atualizado_em
               FROM dbo.VEND_MapeamentoMVKE
               WHERE ativo=1
               ORDER BY codigo_vmsta"""
        ).fetchall()
    return jsonify([
        {
            "id": int(r.id),
            "codigo_vmsta": str(r.codigo_vmsta or "").strip().upper(),
            "classificacao": str(r.classificacao or "").strip().lower(),
            "descricao": r.descricao or "",
            "atualizado_em": _dm(r.atualizado_em),
        }
        for r in rows
    ])


@app.route("/api/mapeamentos/mvke", methods=["POST"])
def salvar_mapeamento_mvke():
    d = request.json or {}
    codigo = str(d.get("codigo_vmsta") or "").strip().upper()
    classificacao = str(d.get("classificacao") or "").strip().lower()
    descricao = str(d.get("descricao") or "").strip() or None

    if not codigo:
        return jsonify({"erro": "Informe o código VMSTA."}), 400
    if classificacao not in ("compativel", "divergencia", "informativo"):
        return jsonify({"erro": "Classificação MVKE inválida."}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        row = cur.execute(
            "SELECT TOP 1 id FROM dbo.VEND_MapeamentoMVKE WHERE codigo_vmsta=?",
            codigo,
        ).fetchone()

        if row:
            mapping_id = int(row.id)
            cur.execute(
                """UPDATE dbo.VEND_MapeamentoMVKE
                   SET classificacao=?, descricao=?, ativo=1, atualizado_em=GETDATE()
                   WHERE id=?""",
                classificacao, descricao, mapping_id,
            )
        else:
            cur.execute(
                """INSERT INTO dbo.VEND_MapeamentoMVKE
                   (codigo_vmsta, classificacao, descricao, ativo, criado_por)
                   VALUES (?, ?, ?, 1, ?)""",
                codigo, classificacao, descricao, usuario_atual(),
            )
            row_novo = cur.execute(
                "SELECT TOP 1 id FROM dbo.VEND_MapeamentoMVKE WHERE codigo_vmsta=?",
                codigo,
            ).fetchone()
            if not row_novo:
                raise RuntimeError("Mapeamento MVKE foi inserido, mas não foi possível recuperar o ID.")
            mapping_id = int(row_novo.id)

        cn.commit()

    return jsonify({
        "ok": True,
        "id": mapping_id,
        "codigo_vmsta": codigo,
        "classificacao": classificacao,
        "descricao": descricao or "",
    })


@app.route("/api/mapeamentos/mvke/<int:mapping_id>", methods=["DELETE"])
def remover_mapeamento_mvke(mapping_id):
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_MapeamentoMVKE
               SET ativo=0, atualizado_em=GETDATE()
               WHERE id=?""",
            mapping_id,
        )
        if cur.rowcount == 0:
            return jsonify({"erro": "Mapeamento MVKE não encontrado."}), 404
        cn.commit()
    return jsonify({"ok": True})



# MAPEAMENTO SHIP-TO ARIBA -> KUNNR SAP
# =============================================================================
def _normalizar_ship_to_code(value):
    text = str(value or "").strip()
    return text.upper() if text else None


def _carregar_mapeamentos_shipto():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT ship_to_code, kunnr, descricao
               FROM dbo.VEND_MapeamentoShipTo
               WHERE ativo=1
               ORDER BY ship_to_code"""
        ).fetchall()

    resultado = []
    for r in rows:
        ship_to_code = _normalizar_ship_to_code(r.ship_to_code)
        kunnr = _normalizar_kunnr_parametro(r.kunnr)
        if not ship_to_code or not kunnr:
            continue
        resultado.append({
            "ship_to_code": ship_to_code,
            "kunnr": kunnr,
            "descricao": str(r.descricao or "").strip(),
        })
    return resultado


@app.route("/api/mapeamentos/shipto", methods=["GET"])
def listar_mapeamentos_shipto():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, ship_to_code, kunnr, descricao, atualizado_em
               FROM dbo.VEND_MapeamentoShipTo
               WHERE ativo=1
               ORDER BY ship_to_code"""
        ).fetchall()

    return jsonify([
        {
            "id": int(r.id),
            "ship_to_code": _normalizar_ship_to_code(r.ship_to_code),
            "kunnr": _normalizar_kunnr_parametro(r.kunnr),
            "descricao": r.descricao or "",
            "atualizado_em": _dm(r.atualizado_em),
        }
        for r in rows
    ])


@app.route("/api/mapeamentos/shipto", methods=["POST"])
def salvar_mapeamento_shipto():
    d = request.json or {}
    ship_to_code = _normalizar_ship_to_code(d.get("ship_to_code"))
    kunnr = _normalizar_kunnr_parametro(d.get("kunnr"))
    descricao = str(d.get("descricao") or "").strip() or None

    if not ship_to_code or not kunnr:
        return jsonify({"erro": "Informe o código Ship-to e o KUNNR SAP."}), 400
    if len(ship_to_code) > 50:
        return jsonify({"erro": "Código Ship-to excede 50 caracteres."}), 400
    if len(kunnr) > 30:
        return jsonify({"erro": "KUNNR excede 30 caracteres."}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        existente = cur.execute(
            """SELECT TOP 1 id
               FROM dbo.VEND_MapeamentoShipTo
               WHERE ship_to_code=?""",
            ship_to_code,
        ).fetchone()

        if existente:
            mapping_id = int(existente.id)
            cur.execute(
                """UPDATE dbo.VEND_MapeamentoShipTo
                   SET kunnr=?, descricao=?, ativo=1, atualizado_em=GETDATE()
                   WHERE id=?""",
                kunnr, descricao, mapping_id,
            )
        else:
            cur.execute(
                """INSERT INTO dbo.VEND_MapeamentoShipTo
                   (ship_to_code, kunnr, descricao, ativo, criado_por)
                   VALUES (?, ?, ?, 1, ?)""",
                ship_to_code, kunnr, descricao, usuario_atual(),
            )
            row_novo = cur.execute(
                "SELECT TOP 1 id FROM dbo.VEND_MapeamentoShipTo WHERE ship_to_code=?",
                ship_to_code,
            ).fetchone()
            if not row_novo:
                raise RuntimeError("Mapeamento Ship-to foi inserido, mas não foi possível recuperar o ID.")
            mapping_id = int(row_novo.id)
        cn.commit()

    return jsonify({
        "ok": True,
        "id": mapping_id,
        "ship_to_code": ship_to_code,
        "kunnr": kunnr,
        "descricao": descricao or "",
    })


@app.route("/api/mapeamentos/shipto/<int:mapping_id>", methods=["DELETE"])
def remover_mapeamento_shipto(mapping_id):
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_MapeamentoShipTo
               SET ativo=0, atualizado_em=GETDATE()
               WHERE id=?""",
            int(mapping_id),
        )
        if cur.rowcount == 0:
            return jsonify({"erro": "Mapeamento Ship-to não encontrado."}), 404
        cn.commit()

    return jsonify({"ok": True})


# MAPEAMENTO DE CONDIÇÃO DE PAGAMENTO — ARIBA -> SAP ZTERM
# =============================================================================
def _normalizar_kunnr_mapeamento(value):
    """Normaliza KUNNR para comparação; vazio representa regra global."""
    text = str(value or "").strip()
    if not text:
        return None
    if text.isdigit():
        return text.zfill(10)
    return text.upper()


def _carregar_mapeamentos_pagamento():
    """Retorna equivalências ativas para uso pela Etapa 2.

    Prioridade aplicada no motor:
      1) KUNNR específico + código Ariba
      2) regra global (KUNNR vazio) + código Ariba
    """
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT kunnr, ariba_codigo, sap_zterm
               FROM dbo.VEND_MapeamentoPagamento
               WHERE ativo = 1
               ORDER BY
                   CASE WHEN kunnr IS NULL OR LTRIM(RTRIM(kunnr)) = '' THEN 1 ELSE 0 END,
                   kunnr, ariba_codigo, sap_zterm"""
        ).fetchall()

    resultado = []
    for r in rows:
        ariba = str(r.ariba_codigo or "").strip().upper()
        sap = str(r.sap_zterm or "").strip().upper()
        if not ariba or not sap:
            continue
        resultado.append({
            "kunnr": _normalizar_kunnr_mapeamento(r.kunnr),
            "ariba_codigo": ariba,
            "sap_zterm": sap,
        })
    return resultado


@app.route("/api/mapeamentos/pagamento", methods=["GET"])
def listar_mapeamentos_pagamento():
    with get_conn() as cn:
        rows = cn.cursor().execute(
            """SELECT id, kunnr, ariba_codigo, sap_zterm, descricao, ativo,
                      criado_por, criado_em, atualizado_em
               FROM dbo.VEND_MapeamentoPagamento
               WHERE ativo = 1
               ORDER BY
                   CASE WHEN kunnr IS NULL OR LTRIM(RTRIM(kunnr)) = '' THEN 1 ELSE 0 END,
                   kunnr, ariba_codigo, sap_zterm"""
        ).fetchall()

    return jsonify([
        {
            "id": int(r.id),
            "kunnr": _normalizar_kunnr_mapeamento(r.kunnr),
            "escopo": "cliente" if _normalizar_kunnr_mapeamento(r.kunnr) else "global",
            "ariba_codigo": r.ariba_codigo,
            "sap_zterm": r.sap_zterm,
            "descricao": r.descricao or "",
            "ativo": bool(r.ativo),
            "criado_por": r.criado_por or "",
            "criado_em": _dm(r.criado_em),
            "atualizado_em": _dm(r.atualizado_em),
        }
        for r in rows
    ])


@app.route("/api/mapeamentos/pagamento", methods=["POST"])
def salvar_mapeamento_pagamento():
    d = request.json or {}
    kunnr = _normalizar_kunnr_mapeamento(d.get("kunnr"))
    ariba_codigo = str(d.get("ariba_codigo") or "").strip().upper()
    sap_zterm = str(d.get("sap_zterm") or "").strip().upper()
    descricao = str(d.get("descricao") or "").strip() or None

    if not ariba_codigo or not sap_zterm:
        return jsonify({"erro": "Informe o código Ariba e o ZTERM SAP."}), 400
    if len(ariba_codigo) > 50 or len(sap_zterm) > 50:
        return jsonify({"erro": "Código Ariba/ZTERM excede 50 caracteres."}), 400
    if kunnr and len(kunnr) > 30:
        return jsonify({"erro": "KUNNR excede 30 caracteres."}), 400

    with get_conn() as cn:
        cur = cn.cursor()
        if kunnr:
            existente = cur.execute(
                """SELECT TOP 1 id
                   FROM dbo.VEND_MapeamentoPagamento
                   WHERE kunnr=? AND ariba_codigo=? AND sap_zterm=?""",
                kunnr, ariba_codigo, sap_zterm,
            ).fetchone()
        else:
            existente = cur.execute(
                """SELECT TOP 1 id
                   FROM dbo.VEND_MapeamentoPagamento
                   WHERE (kunnr IS NULL OR LTRIM(RTRIM(kunnr)) = '')
                     AND ariba_codigo=? AND sap_zterm=?""",
                ariba_codigo, sap_zterm,
            ).fetchone()

        if existente:
            cur.execute(
                """UPDATE dbo.VEND_MapeamentoPagamento
                   SET kunnr=?, descricao=?, ativo=1, atualizado_em=GETDATE()
                   WHERE id=?""",
                kunnr, descricao, int(existente.id),
            )
            mapping_id = int(existente.id)
        else:
            cur.execute(
                """INSERT INTO dbo.VEND_MapeamentoPagamento
                   (kunnr, ariba_codigo, sap_zterm, descricao, ativo, criado_por)
                   VALUES (?, ?, ?, ?, 1, ?)""",
                kunnr, ariba_codigo, sap_zterm, descricao, usuario_atual(),
            )
            if kunnr:
                row_novo = cur.execute(
                    """SELECT TOP 1 id
                       FROM dbo.VEND_MapeamentoPagamento
                       WHERE kunnr=? AND ariba_codigo=? AND sap_zterm=?""",
                    kunnr, ariba_codigo, sap_zterm,
                ).fetchone()
            else:
                row_novo = cur.execute(
                    """SELECT TOP 1 id
                       FROM dbo.VEND_MapeamentoPagamento
                       WHERE (kunnr IS NULL OR LTRIM(RTRIM(kunnr)) = '')
                         AND ariba_codigo=? AND sap_zterm=?""",
                    ariba_codigo, sap_zterm,
                ).fetchone()
            if not row_novo:
                raise RuntimeError("Mapeamento de pagamento foi inserido, mas não foi possível recuperar o ID.")
            mapping_id = int(row_novo.id)
        cn.commit()

    return jsonify({
        "ok": True,
        "id": mapping_id,
        "kunnr": kunnr,
        "escopo": "cliente" if kunnr else "global",
        "ariba_codigo": ariba_codigo,
        "sap_zterm": sap_zterm,
        "descricao": descricao or "",
    })


@app.route("/api/mapeamentos/pagamento/<int:mapping_id>", methods=["DELETE"])
def remover_mapeamento_pagamento(mapping_id):
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_MapeamentoPagamento
               SET ativo=0, atualizado_em=GETDATE()
               WHERE id=?""",
            int(mapping_id),
        )
        if cur.rowcount == 0:
            return jsonify({"erro": "Mapeamento não encontrado."}), 404
        cn.commit()
    return jsonify({"ok": True, "id": int(mapping_id)})


# =============================================================================
# INICIAR COLETA A PARTIR DO PORTAL
# =============================================================================
@app.route("/api/automacao/status")
def automacao_status():
    conta = request.args.get("conta", "ITA").upper()
    proc = _PROCESSES.get(conta)
    return jsonify(
        {
            "conta": conta,
            "running": _proc_running(conta),
            "pid": proc.pid if proc and proc.poll() is None else None,
            "ultimas_saidas": list(_PROCESS_OUTPUT.get(conta, []))[-5:],
        }
    )


@app.route("/api/automacao/iniciar", methods=["POST"])
def iniciar_automacao():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    periodo = str(d.get("periodo") or "365d").lower()

    try:
        proc = _start_collector(
            conta,
            period=periodo,
            started_by=usuario_atual(),
            portal_url=request.host_url.rstrip("/"),
        )
    except ValueError as exc:
        return jsonify({"erro": str(exc)}), 400
    except RuntimeError as exc:
        message = str(exc)
        status = 409 if "andamento" in message else 500
        return jsonify({"erro": message}), status
    except Exception as exc:
        return jsonify({"erro": f"Não consegui iniciar o coletor: {exc}"}), 500

    return jsonify({"ok": True, "conta": conta, "periodo": periodo, "pid": proc.pid}), 202


@app.route("/api/limpar", methods=["POST"])
def limpar_painel():
    conta = (request.json or {}).get("conta", "ITA").upper()
    if conta not in ("ITA", "POP"):
        return jsonify({"erro": "Conta inválida."}), 400
    if _proc_running(conta):
        return jsonify({"erro": "Não é possível limpar enquanto a automação está rodando."}), 409

    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute("DELETE FROM dbo.VEND_ValidacaoFuncional WHERE conta=?", conta)
        cur.execute("DELETE FROM dbo.VEND_AnaliseItem WHERE conta=?", conta)
        cur.execute("DELETE FROM dbo.VEND_Ordem WHERE conta=?", conta)
        cur.execute("DELETE FROM dbo.VEND_Log WHERE conta=?", conta)
        cur.execute("DELETE FROM dbo.VEND_Execucao WHERE conta=?", conta)
        cn.commit()

    bus.publish({"tipo": "limpar", "conta": conta})
    return jsonify({"ok": True})


# =============================================================================
# INGESTÃO PELO COLETOR API — APENAS ETAPA 1
# =============================================================================
@app.route("/api/ingest/execucao/abrir", methods=["POST"])
def ingest_abrir():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    total = int(d.get("total", 0) or 0)
    with get_conn() as cn:
        cur = cn.cursor()
        cur.execute(
            """UPDATE dbo.VEND_Execucao
               SET status='interrompida', finalizado_em=GETDATE()
               WHERE conta=? AND status='run'""",
            conta,
        )
        cur.execute(
            """INSERT INTO dbo.VEND_Execucao (conta, etapa, status, total, iniciado_por)
               OUTPUT INSERTED.id VALUES (?,1,'run',?,?)""",
            conta,
            total,
            d.get("iniciado_por"),
        )
        exec_id = cur.fetchone()[0]
        cn.commit()
    bus.publish(
        {
            "tipo": "execucao_abrir",
            "conta": conta,
            "execucao_id": exec_id,
            "total": total,
            "reset": False,
        }
    )
    return jsonify({"execucao_id": exec_id})


@app.route("/api/ingest/execucao/atualizar", methods=["POST"])
def ingest_atualizar_execucao():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    exec_id = d.get("execucao_id")
    total = int(d.get("total", 0) or 0)
    if exec_id:
        with get_conn() as cn:
            cn.cursor().execute(
                "UPDATE dbo.VEND_Execucao SET total=? WHERE id=?", total, exec_id
            )
            cn.commit()
    bus.publish(
        {
            "tipo": "execucao_atualizar",
            "conta": conta,
            "execucao_id": exec_id,
            "total": total,
        }
    )
    return jsonify({"ok": True})


@app.route("/api/ingest/ordem", methods=["POST"])
def ingest_ordem():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    numero = str(d.get("numero"))
    campos_pend = (
        json.dumps(d.get("campos_pendentes"), ensure_ascii=False)
        if d.get("campos_pendentes") is not None
        else None
    )

    bus.publish(
        {
            "tipo": "ordem",
            "conta": conta,
            "ordem": {
                "numero": numero,
                "cliente": d.get("cliente"),
                "cliente_id": d.get("cliente_id"),
                "buyer_anid": d.get("buyer_anid"),
                "itens": d.get("itens"),
                "valor": d.get("valor"),
                "moeda": d.get("moeda"),
                "etapa1": d.get("etapa1"),
                "qualidade": d.get("qualidade"),
                "erro": d.get("erro_msg"),
                "tem_json": bool(d.get("json_path")),
            },
        }
    )

    def _gravar():
        with get_conn() as cn:
            cur = cn.cursor()
            cur.execute(
                """MERGE dbo.VEND_Ordem AS alvo
                   USING (SELECT ? AS conta, ? AS numero) AS src
                     ON alvo.conta = src.conta AND alvo.numero = src.numero
                   WHEN MATCHED THEN UPDATE SET
                       execucao_id      = COALESCE(?, alvo.execucao_id),
                       cliente          = COALESCE(?, alvo.cliente),
                       cliente_id       = COALESCE(?, alvo.cliente_id),
                       buyer_anid        = COALESCE(?, alvo.buyer_anid),
                       itens            = COALESCE(?, alvo.itens),
                       valor            = COALESCE(?, alvo.valor),
                       moeda            = COALESCE(?, alvo.moeda),
                       etapa1_status    = COALESCE(?, alvo.etapa1_status),
                       qualidade        = COALESCE(?, alvo.qualidade),
                       campos_pendentes = COALESCE(?, alvo.campos_pendentes),
                       json_path        = COALESCE(?, alvo.json_path),
                       erro_msg         = COALESCE(?, alvo.erro_msg),
                       atualizado_em    = GETDATE()
                   WHEN NOT MATCHED THEN
                       INSERT (execucao_id, conta, numero, cliente, cliente_id, buyer_anid, itens,
                               valor, moeda, etapa1_status, qualidade,
                               campos_pendentes, json_path, erro_msg)
                       VALUES (?,?,?,?,?,?,?,?,?,COALESCE(?,'idle'),?,?,?,?);""",
                conta,
                numero,
                d.get("execucao_id"),
                d.get("cliente"),
                d.get("cliente_id"),
                d.get("buyer_anid"),
                d.get("itens"),
                d.get("valor"),
                d.get("moeda"),
                d.get("etapa1"),
                d.get("qualidade"),
                campos_pend,
                d.get("json_path"),
                d.get("erro_msg"),
                d.get("execucao_id"),
                conta,
                numero,
                d.get("cliente"),
                d.get("cliente_id"),
                d.get("buyer_anid"),
                d.get("itens"),
                d.get("valor"),
                d.get("moeda"),
                d.get("etapa1"),
                d.get("qualidade"),
                campos_pend,
                d.get("json_path"),
                d.get("erro_msg"),
            )
            if d.get("etapa1") == "ok":
                cur.execute(
                    """UPDATE dbo.VEND_Ordem
                       SET etapa2_status='idle', etapa2_msg=NULL, etapa2_atualizado_em=NULL
                       WHERE conta=? AND numero=?""",
                    conta, numero,
                )

            # Mantém VEND_Execucao atualizada durante a execução (não só no final).
            # Assim o progresso de um agendamento reaparece corretamente após refresh.
            exec_id = d.get("execucao_id")
            if exec_id and d.get("etapa1") in ("ok", "err"):
                cur.execute(
                    """UPDATE dbo.VEND_Execucao
                       SET sucesso = (SELECT COUNT(*) FROM dbo.VEND_Ordem
                                      WHERE execucao_id=? AND etapa1_status='ok'),
                           erros   = (SELECT COUNT(*) FROM dbo.VEND_Ordem
                                      WHERE execucao_id=? AND etapa1_status='err')
                       WHERE id=?""",
                    exec_id, exec_id, exec_id,
                )
            cn.commit()

    gravar_async(_gravar)
    return jsonify({"ok": True})


@app.route("/api/ingest/log", methods=["POST"])
def ingest_log():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    nivel = str(d.get("nivel") or "info").lower()
    if nivel in ("erro", "error"):
        nivel = "err"
    elif nivel in ("aviso", "warning", "warn"):
        nivel = "warn"
    msg = d.get("mensagem", "")

    bus.publish(
        {
            "tipo": "log",
            "conta": conta,
            "nivel": nivel,
            "mensagem": msg,
            "hora": datetime.now().strftime("%H:%M:%S"),
        }
    )

    # Todos os logs que chegam aqui já são os logs ENXUTOS do Portal.
    # Persistimos todos eles para que uma execução agendada continue visível
    # mesmo se o navegador estiver fechado, trocar de página ou for recarregado.
    try:
        with get_conn() as cn:
            cn.cursor().execute(
                """INSERT INTO dbo.VEND_Log (execucao_id, conta, etapa, nivel, mensagem)
                   VALUES (?,?,?,?,?)""",
                d.get("execucao_id"),
                conta,
                1,
                nivel,
                msg,
            )
            cn.commit()
    except Exception:
        pass
    return jsonify({"ok": True})


@app.route("/api/ingest/execucao/fechar", methods=["POST"])
def ingest_fechar():
    d = request.json or {}
    conta = (d.get("conta") or "ITA").upper()
    exec_id = d.get("execucao_id")
    status = d.get("status", "ok")
    if exec_id:
        with get_conn() as cn:
            cn.cursor().execute(
                """UPDATE dbo.VEND_Execucao
                   SET status=?, sucesso=?, erros=?, total=?, finalizado_em=GETDATE()
                   WHERE id=?""",
                status,
                int(d.get("sucesso", 0) or 0),
                int(d.get("erros", 0) or 0),
                int(d.get("total", 0) or 0),
                exec_id,
            )
            cn.commit()
    if exec_id:
        agendar_etapa2(conta, exec_id)

    bus.publish(
        {
            "tipo": "execucao_fechar",
            "conta": conta,
            "execucao_id": exec_id,
            "status": status,
            "sucesso": int(d.get("sucesso", 0) or 0),
            "erros": int(d.get("erros", 0) or 0),
            "total": int(d.get("total", 0) or 0),
        }
    )
    return jsonify({"ok": True})


if __name__ == "__main__":
    try:
        ensure_feature_schema()
        _recuperar_etapa2_interrompida()
        start_scheduler()
        print(" * Estruturas do Portal/Agendamentos verificadas.")
    except Exception as exc:
        print(f" * AVISO ao preparar recursos do portal: {exc}")

    try:
        from waitress import serve

        print(f" * Portal em http://localhost:{PORT}  (servidor: waitress)")
        print(f" * Coletor: {COLLECTOR_SCRIPT}")
        serve(
            app,
            host="0.0.0.0",
            port=PORT,
            threads=32,
            channel_timeout=3600,
            connection_limit=200,
        )
    except ImportError:
        print(" * waitress não instalado — usando servidor Flask.")
        print(f" * Portal em http://localhost:{PORT}")
        app.run(host="0.0.0.0", port=PORT, threaded=True, use_reloader=False)