# -*- coding: utf-8 -*-



#DCLO.PY



"""Acesso ao DCLO/Azure Synapse para a Etapa 2.







Uso atual:



- KNMT oficial: LO.CL_KNMT_PRA converte KUNNR + KDMAT em MATNR Bosch.



- PRA material: consulta MARA/MARC/MAKT/MVKE.



- KNVV/PRA: consulta dados comerciais do cliente em BR10.







Autenticação:



- ActiveDirectoryIntegrated



- usa o usuário Windows/Entra que está executando o Python.



- não há senha armazenada neste arquivo.



"""







from __future__ import annotations







import json



import os



from pathlib import Path







import pyodbc











BASE_DIR = Path(__file__).resolve().parent



PORTAL_CONFIG_FILE = Path(



    os.environ.get("PORTAL_CONFIG", str(BASE_DIR / "portal_config.json"))



).expanduser()











def _read_config():



    try:



        if PORTAL_CONFIG_FILE.exists():



            data = json.loads(PORTAL_CONFIG_FILE.read_text(encoding="utf-8-sig"))



            return data if isinstance(data, dict) else {}



    except Exception:



        pass



    return {}











_CONFIG = _read_config()



_DCLO = _CONFIG.get("dclo") if isinstance(_CONFIG.get("dclo"), dict) else {}







DCLO_SERVER = (



    os.environ.get("DCLO_SERVER")



    or _DCLO.get("server")



    or "dcanalyticssynwsprodwe01-ondemand.sql.azuresynapse.net"



)



DCLO_DATABASE = (



    os.environ.get("DCLO_DATABASE")



    or _DCLO.get("database")



    or "dcanalyticssynwsprodwe01"



)



DCLO_DRIVER = (



    os.environ.get("DCLO_DRIVER")



    or _DCLO.get("driver")



    or "ODBC Driver 18 for SQL Server"



)



DCLO_SCHEMA = (



    os.environ.get("DCLO_SCHEMA")



    or _DCLO.get("schema")



    or "LO"



)



DCLO_TIMEOUT = int(



    os.environ.get("DCLO_TIMEOUT")



    or _DCLO.get("timeout")



    or 20



)







# KNMT pode ser mais pesado no Synapse. Mantemos o timeout geral curto,



# mas permitimos UMA segunda tentativa controlada somente para KNMT.



DCLO_KNMT_RETRY_TIMEOUT = int(



    os.environ.get("DCLO_KNMT_RETRY_TIMEOUT")



    or _DCLO.get("knmt_retry_timeout")



    or 35



)





DCLO_MATERIAL_TIMEOUT = int(

    os.environ.get("DCLO_MATERIAL_TIMEOUT")

    or _DCLO.get("material_timeout")

    or 45

)



DCLO_MATERIAL_RETRY_TIMEOUT = int(

    os.environ.get("DCLO_MATERIAL_RETRY_TIMEOUT")

    or _DCLO.get("material_retry_timeout")

    or 90

)











def _connection_string():



    return (



        f"DRIVER={{{DCLO_DRIVER}}};"



        f"SERVER={DCLO_SERVER};"



        f"DATABASE={DCLO_DATABASE};"



        "Authentication=ActiveDirectoryIntegrated;"



        "Encrypt=yes;"



        "TrustServerCertificate=no;"



    )











def get_connection():



    """Abre conexão usando o usuário Windows/Entra do processo atual.







    O mesmo limite é aplicado às consultas para evitar espera indefinida.



    """



    conn = pyodbc.connect(_connection_string(), timeout=DCLO_TIMEOUT)



    try:



        conn.timeout = DCLO_TIMEOUT



    except Exception:



        pass



    return conn













def _executar_com_retry(cur, sql, params, nome, timeout=None, retry_timeout=None):

    """Executa a consulta e, só em timeout (HYT00), tenta mais uma vez com prazo maior."""

    timeout = timeout or DCLO_TIMEOUT

    retry_timeout = retry_timeout or DCLO_MATERIAL_RETRY_TIMEOUT

    try:

        cur.timeout = timeout

    except Exception:

        pass

    try:

        cur.execute(sql, *params)

        return cur.fetchall()

    except pyodbc.OperationalError as exc:

        if "HYT00" not in str(exc).upper():

            raise

    try:

        cur.timeout = retry_timeout

    except Exception:

        pass

    try:

        cur.execute(sql, *params)

        return cur.fetchall()

    except pyodbc.OperationalError as exc:

        if "HYT00" not in str(exc).upper():

            raise

        raise RuntimeError(

            f"Consulta {nome}/DCLO excedeu o tempo mesmo após nova tentativa ({retry_timeout}s)."

        ) from exc



def _texto(value):



    if value is None:



        return None



    value = str(value).strip()



    return value or None











def _numero(value):



    if value is None:



        return None



    try:



        return float(value)



    except Exception:



        return value











def _normalizar_kunnr(kunnr):



    value = _texto(kunnr)



    if not value:



        return None



    if value.isdigit():



        return value.zfill(10)



    return value











def _deduplicar(rows):



    unicos = {}



    for item in rows:



        chave = (



            item.get("kunnr"),



            item.get("kdmat"),



            item.get("matnr"),



            item.get("vkorg"),



            item.get("vtweg"),



            item.get("werks"),



            item.get("sistema"),



        )



        existente = unicos.get(chave)



        if existente:



            origens = set(existente.get("origens") or [])



            origens.update(item.get("origens") or [])



            existente["origens"] = sorted(origens)



        else:



            unicos[chave] = item



    return list(unicos.values())











def _consultar_tabela(cur, tabela, kdmat, kunnr=None):



    # IMPORTANTE:



    # Não aplicar LTRIM/RTRIM nas colunas do WHERE. No Synapse isso força



    # transformação linha a linha e pode impedir pushdown/poda, deixando a



    # consulta KNMT muito mais pesada. Os valores retornados continuam sendo



    # normalizados por _texto().



    binds = [str(kdmat)]



    filtro_kunnr = ""



    if kunnr:



        filtro_kunnr = " AND KUNNR = ?"



        binds.append(_normalizar_kunnr(kunnr))







    sql = f"""



        SELECT TOP 100



            KUNNR,



            KDMAT,



            MATNR,



            VKORG,



            VTWEG,



            WERKS,



            TECH_NAME_SOURCESYSTEM



        FROM [{DCLO_SCHEMA}].[{tabela}]



        WHERE KDMAT = ?



          {filtro_kunnr}



          AND MATNR IS NOT NULL



          AND MATNR <> ''



    """







    cur.execute(sql, *binds)



    result = []



    for row in cur.fetchall():



        result.append({



            "kunnr": _texto(row.KUNNR),



            "kdmat": _texto(row.KDMAT),



            "matnr": _texto(row.MATNR),



            "vkorg": _texto(row.VKORG),



            "vtweg": _texto(row.VTWEG),



            "werks": _texto(row.WERKS),



            "sistema": _texto(row.TECH_NAME_SOURCESYSTEM),



            "origens": [tabela],



        })



    return result











def _matnr_bosch_valido(matnr):

    """Regra funcional confirmada: MATNR Bosch possui 10 caracteres."""

    value = _texto(matnr)

    if not value:

        return False

    return len(value) == 10 and value.isalnum()





def _executar_knmt_oficial(cur, kdmat, kunnr):
    """Consulta a fonte oficial KNMT por KUNNR + KDMAT."""

    sql = f"""
        SELECT TOP 100
            VKORG,
            VTWEG,
            KUNNR,
            MATNR,
            KDMAT
        FROM [{DCLO_SCHEMA}].[CL_KNMT_PRA]
        WHERE KDMAT = ?
          AND KUNNR = ?
          AND VKORG = 'BR10'
          AND MATNR IS NOT NULL
          AND MATNR <> ''
    """

    cur.execute(sql, kdmat, kunnr)

    rows = []
    for row in cur.fetchall():
        rows.append({
            "kunnr": _texto(row.KUNNR),
            "kdmat": _texto(row.KDMAT),
            "matnr": _texto(row.MATNR),
            "vkorg": _texto(row.VKORG),
            "vtweg": _texto(row.VTWEG),
            "werks": None,
            "sistema": "SAP/PRA",
            "origens": ["CL_KNMT_PRA"],
        })

    return rows





def consultar_knmt(kdmat, kunnr=None):

    """Resolve KDMAT -> MATNR pela KNMT oficial do DCLO.



    Regras confirmadas em 29/09/2026:

    - fonte oficial: LO.CL_KNMT_PRA;

    - organização de vendas: BR10;

    - relação é por KUNNR + KDMAT;

    - a relação precisa estar cadastrada no SAP;

    - ausência da relação deve virar divergência funcional na Etapa 2;

    - MATNR Bosch esperado possui 10 caracteres;

    - histórico VBAK/VBAP serve apenas para investigação, nunca como substituto.

    """

    kdmat = _texto(kdmat)

    kunnr = _normalizar_kunnr(kunnr)



    if not kdmat:

        return {

            "status": "sem_kdmat",

            "kdmat": None,

            "kunnr": kunnr,

            "matnr": None,

            "fonte": "DCLO/CL_KNMT_PRA",

            "detalhes": [],

        }



    if not kunnr:

        return {

            "status": "sem_kunnr",

            "kdmat": kdmat,

            "kunnr": None,

            "matnr": None,

            "fonte": "DCLO/CL_KNMT_PRA",

            "detalhes": [],

        }



    rows = []

    with get_connection() as conn:

        cur = conn.cursor()

        try:

            cur.timeout = DCLO_TIMEOUT

        except Exception:

            pass



        try:

            rows = _executar_knmt_oficial(cur, kdmat, kunnr)

        except pyodbc.OperationalError as exc:

            if "HYT00" not in str(exc).upper():

                raise



            try:

                cur.timeout = DCLO_KNMT_RETRY_TIMEOUT

            except Exception:

                pass



            try:

                rows = _executar_knmt_oficial(cur, kdmat, kunnr)

            except pyodbc.OperationalError as retry_exc:

                if "HYT00" not in str(retry_exc).upper():

                    raise

                raise RuntimeError(

                    "Consulta KNMT/DCLO não concluída com segurança em "

                    "LO.CL_KNMT_PRA após nova tentativa "

                    f"({DCLO_KNMT_RETRY_TIMEOUT}s)."

                ) from retry_exc



    rows = _deduplicar(rows)

    if not rows:

        return {

            "status": "nao_encontrado",

            "kdmat": kdmat,

            "kunnr": kunnr,

            "matnr": None,

            "fonte": "DCLO/CL_KNMT_PRA",

            "detalhes": [],

        }



    validos = sorted({

        x.get("matnr")

        for x in rows

        if _matnr_bosch_valido(x.get("matnr"))

    })

    invalidos = sorted({

        x.get("matnr")

        for x in rows

        if x.get("matnr") and not _matnr_bosch_valido(x.get("matnr"))

    })



    if not validos:

        return {

            "status": "matnr_invalido",

            "kdmat": kdmat,

            "kunnr": kunnr,

            "matnr": None,

            "matnrs_invalidos": invalidos,

            "fonte": "DCLO/CL_KNMT_PRA",

            "detalhes": rows,

        }



    if len(validos) != 1:

        return {

            "status": "ambiguo",

            "kdmat": kdmat,

            "kunnr": kunnr,

            "matnr": None,

            "matnrs": validos,

            "matnrs_invalidos": invalidos,

            "fonte": "DCLO/CL_KNMT_PRA",

            "detalhes": rows,

        }



    return {

        "status": "ok",

        "kdmat": kdmat,

        "kunnr": kunnr,

        "matnr": validos[0],

        "fonte": "DCLO/CL_KNMT_PRA",

        "matnrs_invalidos": invalidos,

        "detalhes": rows,

    }







def consultar_historico_kdmat(kdmat, kunnr=None):

    """Fallback por histórico VBAK/VBAP sem JOIN pesado no Synapse.



    Regra funcional confirmada em 01/10/2026:

    - KNMT continua sendo a relação oficial;

    - se a KNMT não existir, o histórico pode sugerir MATNR;

    - se houver mais de um MATNR histórico, sugerimos o material do pedido

      mais recente (maior VBELN), sempre sujeito à confirmação humana;

    - VTWEG do VBAK também é devolvido para resolver o canal quando o cliente

      possui múltiplos canais na KNVV.



    A consulta foi separada em duas etapas (VBAP -> VBAK) para evitar o JOIN

    pesado que vinha causando timeout no DCLO.

    """

    kdmat = _texto(kdmat)

    kunnr = _normalizar_kunnr(kunnr)

    fonte = "DCLO/CL_VBAP_PRA+CL_VBAK_PRA"



    base = {

        "status": "nao_encontrado",

        "kdmat": kdmat,

        "kunnr": kunnr,

        "matnr": None,

        "matnrs": [],

        "matnrs_invalidos": [],

        "vtweg": None,

        "vtwegs": [],

        "ultimo_vbeln": None,

        "ultimo_vtweg": None,

        "fonte": fonte,

        "detalhes": [],

    }



    if not kdmat:

        base["status"] = "sem_kdmat"

        return base

    if not kunnr:

        base["status"] = "sem_kunnr"

        return base



    sql_vbap = f"""

        SELECT TOP 500

            VBELN,

            POSNR,

            MATNR,

            KDMAT

        FROM [{DCLO_SCHEMA}].[CL_VBAP_PRA]

        WHERE KDMAT = ?

          AND KDMAT <> ''

          AND MATNR IS NOT NULL

          AND MATNR <> ''

        ORDER BY VBELN DESC, POSNR DESC

    """



    with get_connection() as conn:

        cur = conn.cursor()

        try:

            cur.timeout = DCLO_TIMEOUT

        except Exception:

            pass



        vbap_rows = _executar_com_retry(cur, sql_vbap, (kdmat,), "VBAP", DCLO_MATERIAL_TIMEOUT)



        if not vbap_rows:

            return base



        vbelns = []

        for row in vbap_rows:

            vbeln = _texto(row.VBELN)

            if vbeln and vbeln not in vbelns:

                vbelns.append(vbeln)



        # Filtra os pedidos do cliente/organização comercial em lotes pequenos,

        # evitando um JOIN grande entre as views do Synapse.

        vbak_info = {}

        for inicio in range(0, len(vbelns), 80):

            lote = vbelns[inicio:inicio + 80]

            placeholders = ",".join("?" for _ in lote)

            sql_vbak = f"""

                SELECT VBELN, KUNNR, VKORG, VTWEG

                FROM [{DCLO_SCHEMA}].[CL_VBAK_PRA]

                WHERE VKORG = 'BR10'

                  AND KUNNR = ?

                  AND VBELN IN ({placeholders})

            """

            try:

                cur.timeout = DCLO_TIMEOUT

            except Exception:

                pass

            for row in _executar_com_retry(cur, sql_vbak, (kunnr, *lote), "VBAK", DCLO_MATERIAL_TIMEOUT):

                vbeln = _texto(row.VBELN)

                if vbeln:

                    vbak_info[vbeln] = _texto(row.VTWEG)



    detalhes = []

    for row in vbap_rows:

        vbeln = _texto(row.VBELN)

        if vbeln not in vbak_info:

            continue

        detalhes.append({

            "vbeln": vbeln,

            "kunnr": kunnr,

            "vtweg": vbak_info.get(vbeln),

            "posnr": _texto(row.POSNR),

            "matnr": _texto(row.MATNR),

            "kdmat": _texto(row.KDMAT),

            "origem": "CL_VBAP_PRA+CL_VBAK_PRA",

        })



    # VBELN possui tamanho fixo no SAP; ordenação textual descendente conserva

    # a sequência usada no diagnóstico do Luigi.

    detalhes.sort(

        key=lambda x: (

            str(x.get("vbeln") or ""),

            str(x.get("posnr") or ""),

        ),

        reverse=True,

    )



    base["detalhes"] = detalhes

    if not detalhes:

        return base



    vtwegs = []

    for x in detalhes:

        vtweg = _texto(x.get("vtweg"))

        if vtweg and vtweg not in vtwegs:

            vtwegs.append(vtweg)

    base["vtwegs"] = vtwegs

    if len(vtwegs) == 1:

        base["vtweg"] = vtwegs[0]



    validos = []

    invalidos = []

    for x in detalhes:

        matnr = _texto(x.get("matnr"))

        if not matnr:

            continue

        if _matnr_bosch_valido(matnr):

            if matnr not in validos:

                validos.append(matnr)

        elif matnr not in invalidos:

            invalidos.append(matnr)



    base["matnrs"] = validos

    base["matnrs_invalidos"] = invalidos



    if not validos:

        base["status"] = "matnr_invalido"

        return base



    # Material do pedido mais recente.

    ultimo = next(

        (x for x in detalhes if _matnr_bosch_valido(x.get("matnr"))),

        None,

    )

    if ultimo:

        base["matnr"] = _texto(ultimo.get("matnr"))

        base["ultimo_vbeln"] = _texto(ultimo.get("vbeln"))

        base["ultimo_vtweg"] = _texto(ultimo.get("vtweg"))



    if len(validos) == 1:

        base["status"] = "ok"

    else:

        base["status"] = "sugestao_ultimo"



    return base



def consultar_material_pra(matnr, vtweg=None):

    """Consulta material no PRA sem JOIN pesado no Synapse.



    Regra atual:

    - MARC continua sendo a base BR%;

    - MARA/MAKT/MVKE são consultadas separadamente por MATNR;

    - MVKE é filtrada por VKORG BR10 e, quando informado, pelo VTWEG do cliente;

    - MARC também retorna SOBSL (suprimento especial) e BESKZ (obtenção).



    O filtro de VTWEG evita misturar VMSTA/DWERK de canais 50/52/53.

    """

    matnr = _texto(matnr)

    vtweg = _texto(vtweg)



    vazio = {

        "status": "sem_matnr" if not matnr else "nao_encontrado",

        "matnr": matnr,

        "canal_solicitado": vtweg,

        "fonte": "DCLO/PRA - MARC+MARA+MAKT+MVKE",

        "prdha": None,

        "prdhas": [],

        "prodh1": None,

        "prodh1s": [],

        "prodh1_status": "nao_encontrado",

        "descricao": None,

        "centros": [],

        "mvke": [],

        "detalhes": [],

    }



    if not matnr:

        return vazio



    def _fetch(cur, sql, params, nome):

        try:

            cur.timeout = DCLO_MATERIAL_TIMEOUT

        except Exception:

            pass

        try:

            cur.execute(sql, *params)

            return cur.fetchall()

        except pyodbc.OperationalError as exc:

            if "HYT00" not in str(exc).upper():

                raise

            try:

                cur.timeout = DCLO_MATERIAL_RETRY_TIMEOUT

            except Exception:

                pass

            try:

                cur.execute(sql, *params)

                return cur.fetchall()

            except pyodbc.OperationalError as retry_exc:

                if "HYT00" not in str(retry_exc).upper():

                    raise

                raise RuntimeError(

                    f"Consulta {nome}/DCLO excedeu o tempo mesmo após nova tentativa "

                    f"({DCLO_MATERIAL_RETRY_TIMEOUT}s). MATNR {matnr}."

                ) from retry_exc



    sql_marc = f"""

        SELECT TOP 100

            MATNR,

            WERKS,

            MMSTA,

            MMSTD,

            PRCTR,

            LGPRO,

            LADGR,

            STEUC,

            SOBSL,

            BESKZ,

            BSTMI AS LoteMinimoMM,

            BSTRF AS LoteMultiploMM

        FROM [{DCLO_SCHEMA}].[CL_MARC_PRA]

        WHERE MATNR = ?

          AND WERKS LIKE 'BR%'

        ORDER BY WERKS

    """



    sql_mara = f"""

        SELECT TOP 20 MATNR, PRDHA

        FROM [{DCLO_SCHEMA}].[CL_MARA_PRA]

        WHERE MATNR = ?

    """



    sql_makt = f"""

        SELECT TOP 20 MATNR, MAKTX

        FROM [{DCLO_SCHEMA}].[CL_MAKT_PRA]

        WHERE MATNR = ?

          AND SPRAS = 'P'

    """



    filtro_vtweg = "\n          AND VTWEG = ?" if vtweg else ""

    sql_mvke = f"""

        SELECT TOP 100

            MATNR,

            VKORG,

            VTWEG,

            VMSTA,

            VMSTD,

            DWERK,

            AUMNG AS LoteMinimoSD,

            SCMNG AS LoteMultiploSD,

            SCHME AS LoteMultiploUnMedSD

        FROM [{DCLO_SCHEMA}].[CL_MVKE_PRA]

        WHERE MATNR = ?

          AND VKORG = 'BR10'{filtro_vtweg}

        ORDER BY VTWEG, DWERK

    """



    with get_connection() as conn:

        cur = conn.cursor()



        marc_rows = _fetch(cur, sql_marc, (matnr,), "MARC")

        if not marc_rows:

            return vazio



        mara_rows = _fetch(cur, sql_mara, (matnr,), "MARA")

        makt_rows = _fetch(cur, sql_makt, (matnr,), "MAKT")

        mvke_params = (matnr, vtweg) if vtweg else (matnr,)

        mvke_rows = _fetch(cur, sql_mvke, mvke_params, "MVKE")



    def txt(v):

        return _texto(v)



    prdhas = sorted({txt(row.PRDHA) for row in mara_rows if txt(row.PRDHA)})

    prodh1s = sorted({prdha[:3] for prdha in prdhas if len(prdha) >= 3})



    if len(prodh1s) == 1:

        prodh1 = prodh1s[0]

        prodh1_status = "ok"

    elif len(prodh1s) > 1:

        prodh1 = None

        prodh1_status = "ambiguo"

    else:

        prodh1 = None

        prodh1_status = "nao_encontrado"



    descricoes = []

    for row in makt_rows:

        descricao = txt(row.MAKTX)

        if descricao and descricao not in descricoes:

            descricoes.append(descricao)



    centros = []

    centros_seen = set()

    for row in marc_rows:

        item = {

            "werks": txt(row.WERKS),

            "mmsta": txt(row.MMSTA),

            "mmstd": txt(row.MMSTD),

            "prctr": txt(row.PRCTR),

            "lgpro": txt(row.LGPRO),

            "ladgr": txt(row.LADGR),

            "steuc": txt(row.STEUC),

            "sobsl": txt(row.SOBSL),

            "beskz": txt(row.BESKZ),

            "lote_minimo_mm": row.LoteMinimoMM,

            "lote_multiplo_mm": row.LoteMultiploMM,

        }

        key = tuple(str(item.get(k) or "") for k in (

            "werks", "mmsta", "mmstd", "prctr", "lgpro", "ladgr",

            "steuc", "sobsl", "beskz", "lote_minimo_mm", "lote_multiplo_mm"

        ))

        if key not in centros_seen:

            centros_seen.add(key)

            centros.append(item)



    mvke = []

    mvke_seen = set()

    for row in mvke_rows:

        item = {

            "vkorg": txt(row.VKORG),

            "vtweg": txt(row.VTWEG),

            "vmsta": txt(row.VMSTA),

            "vmstd": txt(row.VMSTD),

            "dwerk": txt(row.DWERK),

            "lote_minimo_sd": row.LoteMinimoSD,

            "lote_multiplo_sd": row.LoteMultiploSD,

            "lote_multiplo_un_med_sd": txt(row.LoteMultiploUnMedSD),

        }

        key = tuple(str(item.get(k) or "") for k in (

            "vkorg", "vtweg", "vmsta", "vmstd", "dwerk",

            "lote_minimo_sd", "lote_multiplo_sd", "lote_multiplo_un_med_sd"

        ))

        if key not in mvke_seen:

            mvke_seen.add(key)

            mvke.append(item)



    detalhes = []

    if mvke:

        for centro in centros:

            for venda in mvke:

                detalhes.append({

                    "matnr": matnr,

                    "prdha": prdhas[0] if len(prdhas) == 1 else None,

                    **centro,

                    "descricao": descricoes[0] if len(descricoes) == 1 else None,

                    **venda,

                })

    else:

        for centro in centros:

            detalhes.append({

                "matnr": matnr,

                "prdha": prdhas[0] if len(prdhas) == 1 else None,

                **centro,

                "descricao": descricoes[0] if len(descricoes) == 1 else None,

                "vkorg": None,

                "vtweg": vtweg,

                "vmsta": None,

                "vmstd": None,

                "dwerk": None,

                "lote_minimo_sd": None,

                "lote_multiplo_sd": None,

                "lote_multiplo_un_med_sd": None,

            })



    return {

        "status": "ok",

        "matnr": matnr,

        "canal_solicitado": vtweg,

        "fonte": "DCLO/PRA - MARC+MARA+MAKT+MVKE",

        "prdha": prdhas[0] if len(prdhas) == 1 else None,

        "prdhas": prdhas,

        "prodh1": prodh1,

        "prodh1s": prodh1s,

        "prodh1_status": prodh1_status,

        "descricao": descricoes[0] if len(descricoes) == 1 else None,

        "centros": centros,

        "mvke": mvke,

        "detalhes": detalhes,

    }



def consultar_knvv_pra(kunnr):



    """Consulta os dados comerciais essenciais do cliente na KNVV/PRA.







    Esta versão evita funções na coluna KUNNR e consulta apenas os campos



    necessários para as validações atuais da Etapa 2:



    - KDGRP: seleção ZNET/A813;

    - KONDA: seleção ZNET/A706 (YR_KONDS);



    - ZTERM: condição de pagamento;



    - AUFSD: bloqueio de ordem;



    - LIFSD: bloqueio de remessa;



    - INCO1/INCO2: condição de transporte;



    - VTWEG: canais encontrados.







    O diagnóstico real do pedido 4524677043 confirmou que esta consulta direta



    responde, enquanto a versão com LTRIM/RTRIM(KUNNR) expira por timeout.



    """



    kunnr = _normalizar_kunnr(kunnr)







    vazio = {



        "status": "sem_kunnr" if not kunnr else "nao_encontrado",



        "kunnr": kunnr,



        "fonte": "DCLO/KNVV_PRA",



        "kdgrps": [],



        "zterms": [],



        "aufsds": [],



        "lifsds": [],



        "vsbeds": [],



        "inco1s": [],



        "inco2s": [],



        "inco2_ls": [],



        "inco3_ls": [],



        "incovs": [],



        "kondas": [],



        "bzirks": [],



        "vtwegs": [],



        "detalhes": [],



    }







    if not kunnr:



        return vazio







    sql = f"""



        SELECT TOP 20



            KUNNR,



            VKORG,



            VTWEG,



            AUFSD,



            KDGRP,



            KONDA,



            LIFSD,



            ZTERM,



            INCO1,



            INCO2



        FROM [{DCLO_SCHEMA}].[CL_KNVV_PRA]



        WHERE KUNNR = ?



          AND VKORG = 'BR10'



          AND VTWEG IN ('50','52','53')



        ORDER BY VTWEG



    """







    detalhes = []







    with get_connection() as conn:



        cur = conn.cursor()



        try:



            cur.timeout = DCLO_TIMEOUT



        except Exception:



            pass







        for row in _executar_com_retry(cur, sql, (kunnr,), "KNVV"):



            detalhes.append({



                "kunnr": _texto(row.KUNNR),



                "vkorg": _texto(row.VKORG),



                "vtweg": _texto(row.VTWEG),



                "aufsd": _texto(row.AUFSD),



                "kdgrp": _texto(row.KDGRP),



                "bzirk": None,



                "konda": _texto(row.KONDA),



                "lifsd": _texto(row.LIFSD),



                "vsbed": None,



                "zterm": _texto(row.ZTERM),



                "inco1": _texto(row.INCO1),



                "inco2": _texto(row.INCO2),



                "inco2_l": None,



                "inco3_l": None,



                "incov": None,



            })







    if not detalhes:



        return vazio







    def valores(campo):



        return sorted({



            str(x.get(campo)).strip()



            for x in detalhes



            if x.get(campo) not in (None, "")



        })







    return {



        "status": "ok",



        "kunnr": kunnr,



        "fonte": "DCLO/KNVV_PRA",



        "kdgrps": valores("kdgrp"),



        "zterms": valores("zterm"),



        "aufsds": valores("aufsd"),



        "lifsds": valores("lifsd"),



        "vsbeds": [],



        "inco1s": valores("inco1"),



        "inco2s": valores("inco2"),



        "inco2_ls": [],



        "inco3_ls": [],



        "incovs": [],



        "kondas": valores("konda"),



        "bzirks": [],



        "vtwegs": valores("vtweg"),



        "detalhes": detalhes,



    }











if __name__ == "__main__":



    print("Servidor:", DCLO_SERVER)



    print("Database:", DCLO_DATABASE)



    print("Driver:", DCLO_DRIVER)



    with get_connection() as conn:



        cur = conn.cursor()



        cur.execute("SELECT 1")



        print("DCLO conectado:", cur.fetchone()[0])