# -*- coding: utf-8 -*-
#ORDER_FIELDS.PY (NAO SEI SE TA SENDO USADO)
"""
Extração dos campos ÚTEIS de um pedido coletado pela Automação Ariba.

A automação salva o JSON completo do SAP Business Network. Para a etapa de
validação (e para a visualização em tabela no Portal), o time de vendas só
precisa de um subconjunto — os campos grifados no documento de referência.

Este módulo:
  - percorre o JSON final e devolve apenas esses campos, já rotulados;
  - classifica o pedido como "Contrato" ou "Oferta" segundo a regra de negócio
    repassada pelo time (Higor / SO-OPM);
  - nunca inventa valor: quando a API não trouxe o campo, marca como ausente
    (coletado=False) para o front exibir "— não coletado".

Nenhum campo é descartado silenciosamente: os 6 campos que a API de Purchase
Orders não expõe (CNPJ do cliente, Inscrição Estadual, local de transporte,
telefone de entrega, endereço do fornecedor e utilização do material) são
retornados assim mesmo, com coletado=False, para não dar a falsa impressão de
que o pedido não os possui.
"""

from __future__ import annotations


# =============================================================================
# REGRA DE NEGÓCIO — CONTRATO x OFERTA
# =============================================================================
# Repassada pelo time (SO-OPM):
#   - ITA nunca recebe pedido de contrato -> sempre "Oferta".
#   - POP pode receber os dois. ~95% dos pedidos de contrato vêm em condição de
#     pagamento "fora mês" (35DFM / "fora mês"). Há ~5% de exceção (30DDL) que
#     não tem sinal distintivo no JSON — por isso a condição de pagamento fica
#     visível como coluna, para auditoria manual desse resíduo.
#
# A detecção é feita pela DESCRIÇÃO ("fora mês"), não pela lista de códigos,
# porque o código muda entre contas (POP=Y017, ITA=Z035) enquanto a expressão
# "fora mês" é o marcador estável de contrato.

_MARCADORES_CONTRATO = ("fora mes", "fora mês", "dfm", "35dfm")


def _texto(*valores) -> str:
    """Concatena valores não vazios em uma string minúscula para busca."""
    partes = [str(v).strip().lower() for v in valores if v not in (None, "")]
    return " ".join(partes)


def classificar_tipo(payload: dict) -> str:
    """
    Retorna "Contrato" ou "Oferta" para o pedido.

    ITA -> sempre Oferta.
    POP -> Contrato quando a condição de pagamento indica "fora mês"; senão Oferta.
    """
    conta = str((payload.get("account") or "")).strip().upper()
    if conta == "ITA":
        return "Oferta"

    comercial = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}
    alvo = _texto(
        comercial.get("payment_terms_detail"),
        comercial.get("payment_terms_description"),
        comercial.get("payment_terms_code"),
        comercial.get("payment_terms"),
    )
    if any(m in alvo for m in _MARCADORES_CONTRATO):
        return "Contrato"
    return "Oferta"


# =============================================================================
# ACESSO SEGURO A CAMPOS
# =============================================================================
def _get(payload: dict, *caminho):
    """Navega com segurança por dicionários aninhados; devolve None se faltar."""
    atual = payload
    for chave in caminho:
        if not isinstance(atual, dict):
            return None
        atual = atual.get(chave)
    return atual


def _limpo(valor):
    """Normaliza para valor "presente" ou None (strings vazias viram None)."""
    if valor is None:
        return None
    if isinstance(valor, str):
        valor = valor.strip()
        return valor or None
    return valor


def _campo(rotulo, valor, *, coletavel=True):
    """
    Constrói a estrutura de um campo útil.

    coletavel=False marca os campos que a API de Purchase Orders NÃO expõe.
    Nesses casos o valor sempre vem None e o front exibe "— não coletado".
    """
    return {
        "rotulo": rotulo,
        "valor": _limpo(valor),
        "coletavel": bool(coletavel),
    }


# =============================================================================
# STATUS AMIGÁVEL
# =============================================================================
_STATUS_LABEL = {
    "PO_NEW": "Novo",
    "PO_CHANGED": "Alterado",
    "PO_CONFIRMED": "Confirmado",
    "PO_SHIPPED": "Enviado",
    "PO_INVOICED": "Faturado",
}


def _status_texto(payload: dict):
    dash = _limpo(_get(payload, "order", "dashboard_status"))
    if dash and dash in _STATUS_LABEL:
        return _STATUS_LABEL[dash]
    # fallback: status textual da API (ex.: "Sent")
    return dash or _limpo(_get(payload, "order", "status"))


# =============================================================================
# EXTRAÇÃO DO CABEÇALHO
# =============================================================================
def _endereco_entrega(payload: dict):
    d = payload.get("delivery") if isinstance(payload.get("delivery"), dict) else {}
    linhas = [
        d.get("ship_to_name"),
        d.get("street"),
        " ".join(x for x in [d.get("postal_code"), d.get("city")] if x),
        " ".join(x for x in [d.get("state"), d.get("country")] if x),
    ]
    linhas = [str(x).strip() for x in linhas if x and str(x).strip()]
    return " · ".join(linhas) if linhas else None


def _condicao_transporte(payload: dict):
    c = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}
    termos = c.get("transport_terms") or c.get("incoterms")
    desc = c.get("delivery_terms")
    if termos and desc:
        return f"{termos} ({desc})"
    return termos or desc


def _condicao_pagamento(comercial: dict):
    """
    Monta a condição de pagamento a partir do comercial, tratando dois casos
    reais vistos na API:
      - detail no formato "CODIGO-Descrição" (ex.: "Y017-Vence em 35 dias...");
      - detail com a mesma frase repetida sem separador
        (ex.: "Fora quinzena 15 diasFora quinzena 15 dias").
    Prioriza detail; se ele estiver duplicado, colapsa para uma ocorrência.
    """
    detail = _limpo(comercial.get("payment_terms_detail"))
    desc = _limpo(comercial.get("payment_terms_description"))

    if detail:
        # Caso a descrição venha colada duas vezes: "XYZXYZ" -> "XYZ".
        n = len(detail)
        if n % 2 == 0 and detail[: n // 2] == detail[n // 2:]:
            detail = detail[: n // 2].strip()
        # Caso detail seja exatamente descrição repetida com separador conhecido.
        if desc and detail == f"{desc}{desc}":
            detail = desc
        return detail

    return desc


def _cabecalho(payload: dict):
    """
    Campos úteis de cabeçalho, na ordem em que aparecem no documento grifado.

    Campos com coletavel=False são os que a API não retorna (sempre None):
      - Local de transporte (transport_location vem null)
      - Endereço do fornecedor (supplier não traz endereço)
      - CNPJ do cliente (delivery.cnpj / customer.cnpj vêm null)
      - Inscrição Estadual (inexistente no JSON)
      - Telefone de entrega (inexistente no JSON)
      - Utilização do material (additional.material_usage vem null)
    """
    comercial = payload.get("commercial") if isinstance(payload.get("commercial"), dict) else {}

    return [
        _campo("Número do pedido", payload.get("order_number")),
        _campo("Status", _status_texto(payload)),
        _campo("Condição de pagamento", _condicao_pagamento(comercial)),
        _campo("Condições de transporte", _condicao_transporte(payload)),
        _campo("Endereço de entrega", _endereco_entrega(payload)),
        _campo("Data de envio",
               _get(payload, "order", "date") or _get(payload, "order", "created")),

        # ---- Campos grifados que a API de Purchase Orders NÃO expõe ----
        _campo("Local de transporte", _get(payload, "commercial", "transport_location"),
               coletavel=False),
        _campo("Endereço do fornecedor", None, coletavel=False),
        _campo("CNPJ do cliente",
               _get(payload, "delivery", "cnpj")
               or _get(payload, "delivery", "bill_to_cnpj")
               or _get(payload, "customer", "cnpj"),
               coletavel=False),
        _campo("Inscrição Estadual", None, coletavel=False),
        _campo("Telefone de entrega", None, coletavel=False),
        _campo("Utilização do material", _get(payload, "additional", "material_usage"),
               coletavel=False),
    ]


# =============================================================================
# EXTRAÇÃO DOS ITENS
# =============================================================================
def _itens(payload: dict):
    itens = payload.get("items")
    if not isinstance(itens, list):
        return []

    resultado = []
    for item in itens:
        if not isinstance(item, dict):
            continue
        resultado.append({
            "linha": _limpo(item.get("line_number")),
            "codigo_cliente": _limpo(item.get("customer_part_number")),
            "descricao": _limpo(item.get("description")),
            "quantidade": item.get("quantity"),
            "unidade": _limpo(item.get("uom")),
            "data_esperada": _limpo(
                item.get("need_by_date") or item.get("requested_delivery_date")
            ),
            "preco_unitario": item.get("unit_price"),
            "moeda": _limpo(item.get("currency")),
        })
    return resultado


# =============================================================================
# API PÚBLICA DO MÓDULO
# =============================================================================
def extrair_campos_uteis(payload: dict) -> dict:
    """
    Recebe o JSON final de um pedido e devolve apenas os campos úteis,
    já classificado como Contrato/Oferta e pronto para renderizar em tabela.
    """
    payload = payload if isinstance(payload, dict) else {}
    return {
        "order_number": payload.get("order_number"),
        "conta": payload.get("account"),
        "tipo": classificar_tipo(payload),
        "cabecalho": _cabecalho(payload),
        "itens": _itens(payload),
    }