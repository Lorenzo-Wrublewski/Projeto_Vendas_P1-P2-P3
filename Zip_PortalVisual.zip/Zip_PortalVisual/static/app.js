const $  = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const now = () => new Date().toLocaleTimeString("pt-BR", {hour12:false});
const brl = v => v == null ? "—" : Number(v).toLocaleString("pt-BR", {style:"currency", currency:"BRL"});
const money = (v, currency="BRL") => {
  if(v == null) return "—";
  const code = String(currency || "BRL").toUpperCase();
  try{
    return Number(v).toLocaleString("pt-BR", {style:"currency", currency:code});
  }catch{
    return `${code} ${Number(v).toLocaleString("pt-BR", {minimumFractionDigits:2, maximumFractionDigits:6})}`;
  }
};

let acct = "ITA";
let orders = [];
let evtSrc = null;
let processRunning = false;
let stage2Running = false;
let execTotal = 0;
let orderPage = 1;
let orderTypeFilter = "Todos";
const ORDER_PAGE_SIZE = 15;

// -----------------------------------------------------------------------------
// HELPERS VISUAIS
// -----------------------------------------------------------------------------
const DASH = `<span class="dash">—</span>`;

function chip(tone, label){
  return `<span class="chip chip-${tone}"><span class="chip-dot" aria-hidden="true"></span>${escapeHtml(label)}</span>`;
}

function paymentCell(value){
  if(!value) return DASH;
  const text = String(value).trim();
  const m = text.match(/^([A-Z0-9]{2,6})\s*-\s*(.+)$/);
  if(m){
    return `<div class="pay"><span class="pay-code">${escapeHtml(m[1])}</span><span class="pay-desc">${escapeHtml(m[2])}</span></div>`;
  }
  return `<div class="pay"><span class="pay-desc">${escapeHtml(text)}</span></div>`;
}

function visibleOrders(){
  if(orderTypeFilter === "Todos") return orders;
  return orders.filter(o => o.tipo === orderTypeFilter);
}

function ensureOrderTypeFilter(){
  if($("#orderTypeFilter")) return;

  const count = $("#ordCount");
  const head = count?.closest(".card-head");
  if(!head) return;

  const tools = document.createElement("div");
  tools.className = "order-filter";
  tools.innerHTML = `
    <label class="order-filter-label" for="orderTypeFilter">Mostrar</label>
    <select id="orderTypeFilter" class="order-type-filter" aria-label="Filtrar pedidos por tipo">
      <option value="Todos">Todos os pedidos</option>
      <option value="Contrato">Somente contratos</option>
      <option value="Oferta">Somente ofertas</option>
    </select>
    <button type="button"
            class="btn btn-secondary btn-sm"
            id="btnReanalisarTodos"
            data-icon="refresh"
            title="Reanalisar a Etapa 2 de todos os pedidos já coletados da conta">
      Reanalisar todos
    </button>
  `;

  head.insertBefore(tools, count);
  const select = $("#orderTypeFilter");
  select.value = orderTypeFilter;
  select.addEventListener("change", ()=>{
    orderTypeFilter = select.value;
    orderPage = 1;
    renderOrders();
  });

  const reanalisarTodos = $("#btnReanalisarTodos");
  if(reanalisarTodos){
    reanalisarTodos.addEventListener("click", reanalisarTodosEtapa2);
  }
  refreshStage2ActionButtons();
}


let schedules = [];
let selectedScheduleId = null;

let apiPending = 0;
let loaderShowTimer = null;
let loaderHideTimer = null;
let loaderVisibleAt = 0;

function setLoadingText(text){
  const el = $("#globalLoadingText");
  if(el) el.textContent = text || "Carregando dados…";
}

function showApiLoading(text="Carregando dados…"){
  apiPending += 1;
  setLoadingText(text);

  clearTimeout(loaderHideTimer);
  loaderHideTimer = null;

  const overlay = $("#globalLoading");
  if(!overlay || overlay.classList.contains("visible") || loaderShowTimer) return;

  loaderShowTimer = setTimeout(()=>{
    loaderShowTimer = null;
    if(apiPending <= 0) return;
    loaderVisibleAt = Date.now();
    overlay.classList.add("visible");
    overlay.setAttribute("aria-hidden","false");
  }, 90);
}

function hideApiLoading(){
  apiPending = Math.max(0, apiPending - 1);
  if(apiPending > 0) return;

  if(loaderShowTimer){
    clearTimeout(loaderShowTimer);
    loaderShowTimer = null;
  }

  const overlay = $("#globalLoading");
  if(!overlay || !overlay.classList.contains("visible")) return;

  const visibleFor = Date.now() - loaderVisibleAt;
  const wait = Math.max(0, 260 - visibleFor);

  clearTimeout(loaderHideTimer);
  loaderHideTimer = setTimeout(()=>{
    if(apiPending > 0) return;
    overlay.classList.remove("visible");
    overlay.setAttribute("aria-hidden","true");
    loaderHideTimer = null;
  }, wait);
}

async function apiRequest(url, options={}){
  const {
    loading = true,
    loadingText = "Carregando dados…",
    ...fetchOptions
  } = options;

  if(loading) showApiLoading(loadingText);

  try{
    const r = await fetch(url, fetchOptions);
    let data = null;
    try { data = await r.json(); } catch {}
    if(!r.ok) throw new Error((data && (data.erro || data.message)) || r.statusText);
    return data;
  }finally{
    if(loading) hideApiLoading();
  }
}

const apiGet = (url, options={}) => apiRequest(url, options);
const apiPost = (url, body, options={}) => apiRequest(url, {
  ...options,
  method:"POST",
  headers:{"Content-Type":"application/json", ...(options.headers || {})},
  body:JSON.stringify(body || {})
});
const apiPut = (url, body, options={}) => apiRequest(url, {
  ...options,
  method:"PUT",
  headers:{"Content-Type":"application/json", ...(options.headers || {})},
  body:JSON.stringify(body || {})
});
const apiDelete = (url, options={}) => apiRequest(url, {...options, method:"DELETE"});

function escapeHtml(v){
  return String(v ?? "").replace(/[&<>'"]/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;"
  }[c]));
}

function toast(msg, erro=false){
  const t = $("#toast");
  t.textContent = msg;
  t.classList.toggle("erro", erro);
  t.classList.add("show");
  clearTimeout(t._tm);
  t._tm = setTimeout(()=>t.classList.remove("show"), 3200);
}

function confirmAction({title="Confirmar ação", message="Tem certeza?", confirmText="Confirmar"}={}){
  return new Promise(resolve=>{
    const modal = $("#confirmModal");
    const ok = $("#confirmOk");
    const cancel = $("#confirmCancel");
    $("#confirmTitle").textContent = title;
    $("#confirmMessage").textContent = message;
    ok.textContent = confirmText;
    modal.classList.remove("hidden");
    setTimeout(()=>ok.focus(), 30);

    const finish = value=>{
      modal.classList.add("hidden");
      ok.removeEventListener("click", onOk);
      cancel.removeEventListener("click", onCancel);
      modal.removeEventListener("click", onBackdrop);
      document.removeEventListener("keydown", onKey);
      resolve(value);
    };
    const onOk = ()=>finish(true);
    const onCancel = ()=>finish(false);
    const onBackdrop = e=>{ if(e.target === modal) finish(false); };
    const onKey = e=>{ if(e.key === "Escape") finish(false); };

    ok.addEventListener("click", onOk);
    cancel.addEventListener("click", onCancel);
    modal.addEventListener("click", onBackdrop);
    document.addEventListener("keydown", onKey);
  });
}

function logLine(msg, nivel="info", hora){
  const box = $("#console");
  if(!box) return;
  const l = document.createElement("div");
  const normalized = ["err","warn","head","run","ok","info"].includes(nivel) ? nivel : "info";
  l.className = "l " + normalized;
  l.innerHTML = `<span class="t">${escapeHtml(hora || now())}</span><span class="m">${escapeHtml(msg)}</span>`;
  box.appendChild(l);
  box.scrollTop = box.scrollHeight;
}

function setStation(state, meta, pct){
  const st = $("#st1");
  if(!st) return;
  st.dataset.state = state;
  const labels = {idle:"Ocioso", run:"Em andamento", ok:"Concluído", err:"Erro"};
  st.querySelector(".lbl").textContent = labels[state] || state;
  $("#m1").textContent = meta || "";
  st.querySelector(".st-bar i").style.width = `${Math.max(0, Math.min(100, pct || 0))}%`;
}

function setStage2Station(state, meta, pct){
  const st = $("#st2");
  if(!st) return;
  st.dataset.state = state;
  const labels = {
    idle:"Aguardando",
    run:"Em análise",
    ok:"Concluída",
    warn:"Com divergência",
    dados:"Com pendência",
    pending:"Com pendência",
    na:"Não aplicável",
    err:"Erro"
  };
  st.querySelector(".lbl").textContent = labels[state] || state;
  const metaEl = $("#m2");
  if(metaEl) metaEl.textContent = meta || "";
  st.querySelector(".st-bar i").style.width = `${Math.max(0, Math.min(100, pct || 0))}%`;
}

function refreshRunButton(){
  const b = $("#btnRun");
  if(!b) return;
  const locked = processRunning || stage2Running;
  b.disabled = locked;
  b.textContent = processRunning
    ? "Automação em execução…"
    : stage2Running
      ? "Análise em execução…"
      : "Executar automação";
}

function setRunButton(running){
  processRunning = !!running;
  refreshRunButton();
  refreshStage2ActionButtons();
}

function setStage2Running(running){
  stage2Running = !!running;
  refreshRunButton();
  refreshStage2ActionButtons();
}

function setServer(on){
  $("#srvDot").classList.toggle("off", !on);
  $("#srvTxt").textContent = on ? "servidor online" : "servidor offline";
}

function refreshStage2ActionButtons(){
  const locked = processRunning || stage2Running;
  $$(".btn-reanalisar-etapa2").forEach(btn=>{ btn.disabled = locked; });

  const allBtn = $("#btnReanalisarTodos");
  if(allBtn){
    const hasEligible = orders.some(o=>o.etapa1 === "ok");
    allBtn.disabled = locked || !hasEligible;
    allBtn.textContent = stage2Running ? "Reanalisando…" : "Reanalisar todos";
  }
}

async function reanalisarTodosEtapa2(){
  if(processRunning || stage2Running) return;

  const elegiveis = orders.filter(o=>o.etapa1 === "ok");
  if(!elegiveis.length){
    toast(`Não há pedidos da conta ${acct} com a Etapa 1 concluída.`, true);
    return;
  }

  const ok = await confirmAction({
    title:"Reanalisar todos os pedidos",
    message:`Reanalisar a Etapa 2 dos ${elegiveis.length} pedido(s) já coletados da conta ${acct}? Nenhum pedido será baixado novamente do Ariba.`,
    confirmText:"Reanalisar todos"
  });
  if(!ok) return;

  const btn = $("#btnReanalisarTodos");
  if(btn) btn.disabled = true;

  try{
    const resp = await apiPost(
      `/api/ordens/${encodeURIComponent(acct)}/reanalisar-todos`,
      {},
      {loadingText:"Agendando reanálise de todos os pedidos…"}
    );

    uteisCache.clear();
    setStage2Running(true);
    const total = Number(resp?.total || elegiveis.length || 0);
    setStage2Station("run", total ? `0/${total} pedido(s) analisado(s)` : "iniciando reanálise…", total ? 3 : 0);
    toast(resp?.mensagem || `Reanálise em lote iniciada para a conta ${acct}.`);
  }catch(err){
    toast(err.message || "Não consegui iniciar a reanálise em lote", true);
    refreshStage2ActionButtons();
  }
}

function clientMeta(o){
  const name = o.cliente || "Cliente não identificado";
  return {name, initial:name.charAt(0).toUpperCase() || "?"};
}

function renderClients(){
  const wrap = $("#clientList");
  if(!wrap) return;
  const groups = new Map();
  for(const o of orders){
    const key = o.cliente || "Cliente não identificado";
    if(!groups.has(key)) groups.set(key, []);
    groups.get(key).push(o);
  }
  if(!groups.size){
    wrap.innerHTML = `<div class="empty-block">Nenhum cliente coletado ainda. Execute a automação para buscar pedidos.</div>`;
    return;
  }
  const chipByState = {
    ok:["success","Concluído"],
    run:["run","Coletando"],
    err:["error","Com erro"],
    idle:["neutral","Aguardando"]
  };
  wrap.innerHTML = [...groups.entries()].map(([name,list])=>{
    const ok = list.filter(o=>o.etapa1==="ok").length;
    const err = list.filter(o=>o.etapa1==="err").length;
    const run = list.some(o=>o.etapa1==="run");
    const state = run ? "run" : err ? "err" : ok===list.length ? "ok" : "idle";
    const pct = list.length ? Math.round(ok / list.length * 100) : 0;
    const [tone,label] = chipByState[state];
    return `<div class="client" data-state="${state}">
      <div class="client-avatar">${escapeHtml(name.charAt(0).toUpperCase())}</div>
      <div class="client-info"><strong title="${escapeHtml(name)}">${escapeHtml(name)}</strong><span>${list.length} pedido(s)</span></div>
      <div class="client-progress">
        <span>${ok} de ${list.length} baixados</span>
        <div class="mini-bar"><i style="width:${pct}%"></i></div>
      </div>
      ${chip(tone,label)}
    </div>`;
  }).join("");
}

function pill(state){
  const map = {
    idle:["neutral","Na fila"],
    run:["run","Coletando"],
    ok:["success","Coletado"],
    err:["error","Erro"]
  };
  const [tone,label] = map[state] || map.idle;
  return chip(tone,label);
}

function paginationPages(current, total){
  if(total <= 7) return Array.from({length:total}, (_,i)=>i+1);
  const pages = [1];
  if(current > 4) pages.push("…");
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  for(let p=start; p<=end; p++) pages.push(p);
  if(current < total - 3) pages.push("…");
  pages.push(total);
  return pages;
}

function renderOrderPagination(){
  const pager = $("#ordPagination");
  const info = $("#ordPageInfo");
  const buttons = $("#ordPageButtons");
  if(!pager || !info || !buttons) return;
  const total = visibleOrders().length;
  const totalPages = Math.max(1, Math.ceil(total / ORDER_PAGE_SIZE));
  if(orderPage > totalPages) orderPage = totalPages;
  if(total === 0){ pager.classList.add("hidden"); return; }
  pager.classList.remove("hidden");
  const first = (orderPage - 1) * ORDER_PAGE_SIZE + 1;
  const last = Math.min(orderPage * ORDER_PAGE_SIZE, total);
  info.textContent = `Mostrando ${first}–${last} de ${total} pedidos`;
  const pageButtons = paginationPages(orderPage, totalPages).map(p=>
    p === "…" ? `<span class="page-ellipsis">…</span>` :
    `<button type="button" class="page-btn ${p===orderPage?"active":""}" data-page="${p}" ${p===orderPage?'aria-current="page"':""}>${p}</button>`
  ).join("");
  buttons.innerHTML = `
    <button type="button" class="page-btn page-nav" data-action="prev" ${orderPage<=1?"disabled":""}>Anterior</button>
    ${pageButtons}
    <button type="button" class="page-btn page-nav" data-action="next" ${orderPage>=totalPages?"disabled":""}>Próxima</button>`;
}

// Pedidos cujo painel de detalhes está aberto (por número), e cache dos
// campos úteis já buscados para não repetir a chamada ao trocar de página.
const expandedOrders = new Set();
const uteisCache = new Map();

// Estado visual do detalhe por pedido.
// Contratos abrem direto na Análise comercial; ofertas permanecem em Dados do pedido.
const orderDetailTabs = new Map();
const orderAnalysisItems = new Map();

function tipoBadge(tipo){
  if(tipo === "Contrato") return `<span class="tag tag-contract">Contrato</span>`;
  if(tipo === "Oferta")   return `<span class="tag tag-offer">Oferta</span>`;
  return DASH;
}

function etapa2Badge(status){
  const map = {
    idle:["neutral","Aguardando"],
    run:["run","Analisando"],
    ok:["success","Concluído"],
    warn:["warning","Divergência"],
    dados:["info","Pendente"],
    pending:["info","Pendente"], // compatibilidade com análises antigas
    partial:["info","Pendente"],
    na:["neutral","Não aplicável"],
    err:["error","Erro"]
  };
  const [tone,label] = map[status] || map.idle;
  return chip(tone,label);
}

function etapa2ResultadoLabel(resultado){
  const map = {
    concluido:"Concluído tecnicamente",
    divergencia:"Divergência técnica",
    dados_insuficientes:"Pendente",
    pendente:"Pendente", // compatibilidade
    erro:"Erro técnico"
  };
  return map[resultado] || resultado || "—";
}

function etapa2ResultadoClass(resultado){
  if(resultado === "concluido") return "etapa2-status-good";
  if(resultado === "divergencia") return "etapa2-status-warn";
  if(resultado === "dados_insuficientes" || resultado === "pendente") return "etapa2-status-data";
  if(resultado === "erro") return "etapa2-status-err";
  return "etapa2-status-info";
}

const ORD_COLSPAN = 10;

function renderOrders(){
  ensureOrderTypeFilter();
  $("#ordAcct").textContent = acct;

  const list = visibleOrders();
  $("#ordCount").textContent = orderTypeFilter === "Todos"
    ? `${orders.length} pedido(s)`
    : `${list.length} de ${orders.length} pedido(s)`;

  const body = $("#ordBody");
  if(!list.length){
    body.innerHTML = `<tr><td colspan="${ORD_COLSPAN}" class="empty">Nenhum pedido coletado para este filtro.</td></tr>`;
    renderOrderPagination();
    refreshStage2ActionButtons();
    return;
  }
  const totalPages = Math.max(1, Math.ceil(list.length / ORDER_PAGE_SIZE));
  if(orderPage > totalPages) orderPage = totalPages;
  const start = (orderPage - 1) * ORDER_PAGE_SIZE;
  const pageOrders = list.slice(start, start + ORDER_PAGE_SIZE);

  body.innerHTML = pageOrders.map(o=>{
    const aberto = expandedOrders.has(o.numero);
    const mainRow = `<tr class="ord-main ${aberto?"aberto":""}" data-numero="${escapeHtml(o.numero)}">
      <td class="col-exp">
        <button type="button" class="exp-toggle" data-icon="chevron"
                aria-label="${aberto?"Recolher":"Expandir"} pedido ${escapeHtml(o.numero)}"
                aria-expanded="${aberto}"></button>
      </td>
      <td><span class="ord-num">${escapeHtml(o.numero)}</span></td>
      <td>${tipoBadge(o.tipo)}</td>
      <td class="cell-client">${escapeHtml(clientMeta(o).name)}</td>
      <td>${paymentCell(o.condicao_pagamento)}</td>
      <td class="num">${o.itens ?? "—"}</td>
      <td class="num">${o.valor != null ? brl(o.valor) : "—"}</td>
      <td>${pill(o.etapa1)}</td>
      <td>
        <div class="etapa2-cell" ${o.etapa2_msg ? `title="${escapeHtml(o.etapa2_msg)}"` : ""}>
          ${etapa2Badge(o.etapa2 || "idle")}
          <button type="button"
                  class="icon-btn btn-reanalisar-etapa2"
                  data-icon="refresh"
                  data-numero="${escapeHtml(o.numero)}"
                  title="Reanalisar Etapa 2"
                  aria-label="Reanalisar Etapa 2 do pedido ${escapeHtml(o.numero)}"></button>
        </div>
      </td>
      <td class="cell-date">${escapeHtml(o.etapa2_atualizado_em || o.atualizado_em || "—")}</td>
    </tr>`;
    const detailRow = `<tr class="ord-detail ${aberto?"":"hidden"}" data-detail="${escapeHtml(o.numero)}">
      <td colspan="${ORD_COLSPAN}">${aberto ? renderDetail(o.numero) : ""}</td>
    </tr>`;
    return mainRow + detailRow;
  }).join("");
  renderOrderPagination();
  refreshStage2ActionButtons();
}

function etapa2StatusLabel(status){
  const map = {
    compativel_candidato:"Preço encontrado em ZNET",
    compativel_exato:"Preço validado",
    divergente_exato:"Preço divergente",
    sem_correspondencia_candidata:"ZNET encontrada · preço diferente",
    sem_mesma_moeda:"ZNET encontrada · outra moeda",
    nao_encontrado:"ZNET não encontrada",
    pendente_a706_seletor:"A706 · regra YR_KONDS pendente",
    pendente_material:"Material sem identificação",
    erro:"Erro"
  };
  return map[status] || status || "—";
}

function etapa2StatusClass(status){
  if(["compativel_candidato","compativel_exato"].includes(status)) return "etapa2-status-good";
  if(["sem_correspondencia_candidata","divergente_exato","sem_mesma_moeda"].includes(status)) return "etapa2-status-warn";
  if(status === "erro") return "etapa2-status-err";
  return "etapa2-status-info";
}

function znetOrigemLabel(origem){
  const map = {
    A813_KDGRP:"A813 – grupo do cliente",
    A706_YR_KONDS:"A706 – grupo de preço",
    A005_KUNNR:"A005 – cliente"
  };
  return map[origem] || origem || "—";
}

function renderZnetDetalhes(a){
  const detalhes = Array.isArray(a.znet_detalhes) ? a.znet_detalhes : [];
  if(!detalhes.length) return "";

  const visiveis = detalhes.slice(0,20);
  const rows = visiveis.map(z=>{
    const preco = z.preco != null
      ? money(z.preco, z.moeda || a.moeda_ariba || "BRL")
      : "—";
    const validade = z.conv_datbi
      ? String(z.conv_datbi).slice(0,10).split("-").reverse().join("/")
      : "—";

    return `<tr>
      <td>${escapeHtml(znetOrigemLabel(z.origem))}</td>
      <td><span class="code">${escapeHtml(z.chave || "—")}</span></td>
      <td class="num">${preco}</td>
      <td>${escapeHtml(validade)}</td>
    </tr>`;
  }).join("");

  return `
    <details class="analysis-tech">
      <summary>Condições ZNET consultadas (${detalhes.length})</summary>
      <div class="table-wrap">
        <table class="data-table analysis-tech-table">
          <thead>
            <tr>
              <th>Origem</th>
              <th>Chave</th>
              <th class="num">Preço líquido</th>
              <th>Válida até</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      ${detalhes.length > visiveis.length
        ? `<div class="analysis-tech-more">Mostrando 20 de ${detalhes.length} condições.</div>`
        : ""}
    </details>`;
}


// Pendências que se resolvem cadastrando algo em Parâmetros no Portal.
const ETAPA2_CODIGOS_EXTERNOS = new Set([
  "kunnr",
  "canal",
  "pagamento",
  "vmsta",
  "condicao_transporte",
  "destino_mercadoria"
]);

// Pendências de cadastro mestre no SAP.
const ETAPA2_CODIGOS_DADO_MESTRE = new Set([
  "matnr",
  "material_dclo",
  "knmt_relacao",
  "centro",
  "ziad",
  "transportadora",
  "redespacho",
  "representante"
]);

const ETAPA2_CODIGOS_DEPENDENCIA = new Set([
  "znet",
  "lote"
]);

function tipoPendenciaEtapa2(codigo){
  const c = String(codigo || "");
  if(ETAPA2_CODIGOS_EXTERNOS.has(c)) return "externa";
  if(ETAPA2_CODIGOS_DADO_MESTRE.has(c)) return "mestre";
  if(ETAPA2_CODIGOS_DEPENDENCIA.has(c)) return "dependencia";
  return "dados";
}

function criterioStatusLabel(status, codigo){
  if(status === "ok" && ["bloqueio_ordem","bloqueio_remessa"].includes(String(codigo || ""))){
    return "Consulta concluída";
  }
  if(status === "funcional") return "Aguardando decisão";
  if(status === "dados"){
    const tipo = tipoPendenciaEtapa2(codigo);
    if(tipo === "externa") return "Parametrizar no Portal";
    if(tipo === "mestre") return "Cadastro SAP pendente";
    return "Pendente";
  }
  const map = {
    ok:"Concluído",
    divergencia:"Divergência",
    info:"Informativo",
    erro:"Erro"
  };
  return map[status] || "Informativo";
}

function formatCriterioValue(c){
  let value = String(c?.valor ?? "—");

  // Valores técnicos persistidos vêm como "BRL 145821.5", "USD 1499.32", etc.
  // A formatação acontece somente na apresentação; o valor persistido não é alterado.
  if(["preco_ariba","znet"].includes(String(c?.codigo || ""))){
    value = value.replace(/\b(BRL|USD|EUR)\s+(-?\d+(?:\.\d+)?)/g, (_, code, num)=>{
      const n = Number(num);
      if(!Number.isFinite(n)) return `${code} ${num}`;
      return money(n, code);
    });
  }

  return value;
}

function criterioStatusClass(status, codigo){
  if(status === "ok") return "validation-ok";
  if(status === "divergencia") return "validation-warn";
  if(status === "dados"){
    const tipo = tipoPendenciaEtapa2(codigo);
    if(tipo === "externa") return "validation-external";
    if(tipo === "mestre") return "validation-master";
    return "validation-data";
  }
  if(status === "erro") return "validation-err";
  return "validation-info";
}

// Mantida por compatibilidade (não utilizada na visualização atual).
function renderCriteriosGrupo(titulo, criterios){
  const lista = Array.isArray(criterios) ? criterios : [];
  if(!lista.length) return "";
  return `
    <div class="check-group">
      <h4>${escapeHtml(titulo)}<span>${lista.length}</span></h4>
      <ul class="checks">${lista.map(renderCriterioCompacto).join("")}</ul>
    </div>`;
}

function renderMotivoTecnico(a){
  const temMotivo = !!a.motivo;
  const temZnet = Array.isArray(a.znet_detalhes) && a.znet_detalhes.length > 0;
  if(!temMotivo && !temZnet) return "";

  return `
    <div class="analysis-technical-block">
      ${temMotivo ? `
        <details class="analysis-tech analysis-observations">
          <summary>Observações técnicas da análise</summary>
          <div class="analysis-observations-body">${escapeHtml(a.motivo)}</div>
        </details>` : ""}
      ${renderZnetDetalhes(a)}
    </div>`;
}

// Mantida por compatibilidade (não utilizada na visualização atual).
function renderEtapa2Fallback(a){
  const precoAriba = a.preco_ariba != null
    ? money(a.preco_ariba, a.moeda_ariba || "BRL")
    : "—";

  const znetResumo = (a.znet_condicoes ?? 0) > 0
    ? `${a.znet_condicoes} condição(ões) vigente(s)`
    : "Nenhuma condição vigente";

  return `
    <div class="analysis-legacy-note">
      Este resultado foi salvo antes do novo detalhamento por critérios. Reanalise o pedido para atualizar a visualização.
    </div>
    <table class="detail-kv-table">
      <tbody>
        <tr><th>Material / MATNR</th><td>${escapeHtml(a.matnr || "Não identificado")}</td></tr>
        <tr><th>Preço recebido do Ariba</th><td>${precoAriba}</td></tr>
        <tr><th>ZNET</th><td>${escapeHtml(znetResumo)}</td></tr>
        <tr><th>KUNNR</th><td>${a.kunnr ? escapeHtml(a.kunnr) : "Não identificado"}</td></tr>
        <tr><th>ZIAD</th><td>${escapeHtml(a.ziad_status || "—")}</td></tr>
        <tr>
          <th>Resultado técnico</th>
          <td><strong class="${etapa2ResultadoClass(a.resultado)}">${escapeHtml(etapa2ResultadoLabel(a.resultado))}</strong></td>
        </tr>
        <tr><th>Atualizado</th><td>${escapeHtml(a.atualizado_em || "—")}</td></tr>
      </tbody>
    </table>`;
}

// Mantida por compatibilidade (não utilizada na visualização atual).
function renderSapGate(analises){
  const lista = Array.isArray(analises) ? analises : [];
  if(!lista.length) return "";
  const concluido = lista.every(a=>
    a?.detalhes_validacao?.status_final_etapa2?.status === "concluido"
  );
  return `
    <section class="ca-summary ${concluido ? "ca-summary-ok" : "ca-summary-err"}">
      <div class="ca-summary-status">
        <span class="ca-summary-label">Resultado da Etapa 2</span>
        <strong>${concluido ? "Concluído tecnicamente" : "Bloqueado"}</strong>
      </div>
    </section>`;
}


function etapa2AreaDoCriterio(codigo){
  const c = String(codigo || "");
  if([
    "kunnr","canal","pagamento","bloqueio_credito","bloqueio_ordem","bloqueio_remessa",
    "transportadora","redespacho","representante","comissao","beneficio_fiscal"
  ].includes(c)) return "cliente";

  if(["matnr","knmt_relacao","material_dclo","vmsta","obtencao","lote"].includes(c)) return "material";
  if(["preco_ariba","znet","ziad"].includes(c)) return "preco";
  if(["centro","condicao_transporte","destino_mercadoria"].includes(c)) return "logistica";
  return "outros";
}

function etapa2AreaLabel(area){
  const labels = {
    cliente:"Cliente e condições comerciais",
    material:"Material",
    preco:"Preço e descontos",
    logistica:"Logística",
    outros:"Outros"
  };
  return labels[area] || "Outros";
}

function etapa2StatusTone(status, codigo){
  if(status === "ok") return "ok";
  if(status === "divergencia") return "warn";
  if(status === "erro") return "err";
  if(status === "funcional") return "decision";
  if(status === "dados"){
    const tipo = tipoPendenciaEtapa2(codigo);
    if(tipo === "mestre") return "master";
    if(tipo === "externa") return "external";
    return "data";
  }
  return "info";
}

function etapa2CriteriosDaAnalise(analises){
  const saida = [];
  (Array.isArray(analises) ? analises : []).forEach(a=>{
    const d = a?.detalhes_validacao && typeof a.detalhes_validacao === "object"
      ? a.detalhes_validacao
      : {};
    ["cliente","item"].forEach(origem=>{
      (Array.isArray(d[origem]) ? d[origem] : []).forEach(c=>{
        if(c && typeof c === "object"){
          saida.push({...c, _linha:a?.linha, _origem:origem});
        }
      });
    });
  });
  return saida;
}

function renderEtapa2Resumo(analises, detailStatus){
  const criterios = etapa2CriteriosDaAnalise(analises);
  const counts = {
    ok: criterios.filter(c=>c.status === "ok").length,
    divergencia: criterios.filter(c=>c.status === "divergencia").length,
    dados: criterios.filter(c=>c.status === "dados" || c.status === "funcional").length,
    erro: criterios.filter(c=>c.status === "erro").length
  };

  const bloqueadores = [];
  const seen = new Set();

  criterios.forEach(c=>{
    const status = String(c?.status || "info");
    const bloqueante = !!c?.bloqueante;
    if(!(status === "divergencia" || status === "erro" || (bloqueante && status !== "ok"))) return;

    const label = String(c?.label || c?.codigo || "Validação");
    const valor = String(c?.valor || "").trim();
    const key = `${c?.codigo || label}|${valor}|${status}`;
    if(seen.has(key)) return;
    seen.add(key);

    bloqueadores.push({
      label,
      valor,
      detalhe:String(c?.detalhe || ""),
      status,
      codigo:c?.codigo,
      tipo:status === "divergencia"
        ? "Divergência"
        : status === "erro"
          ? "Erro técnico"
          : status === "funcional"
            ? "Decisão humana"
            : ({
                externa:"Parâmetro no Portal",
                mestre:"Cadastro SAP",
                dependencia:"Pendência",
                dados:"Pendência"
              }[tipoPendenciaEtapa2(c?.codigo)] || "Pendência")
    });
  });

  const statusText = detailStatus === "ok"
    ? "Concluído tecnicamente"
    : detailStatus === "warn"
      ? "Divergência técnica"
      : detailStatus === "err"
        ? "Erro técnico"
        : "Bloqueado";

  const statusCopy = detailStatus === "ok"
    ? "Todas as validações obrigatórias foram concluídas."
    : detailStatus === "warn"
      ? "Há divergência confirmada em pelo menos uma validação."
      : detailStatus === "err"
        ? "Há falha técnica que precisa ser corrigida antes da conclusão."
        : "Há informações, regras ou decisões obrigatórias ainda pendentes.";

  const counter = (n, label, cls)=>`
    <div class="counter ${n > 0 ? cls : ""}">
      <strong>${n}</strong>
      <span>${label}</span>
    </div>`;

  const blockerRows = bloqueadores.length
    ? `<ul class="blockers">${bloqueadores.map(b=>`
        <li class="blocker tone-${etapa2StatusTone(b.status,b.codigo)}">
          <span class="tone-dot" aria-hidden="true"></span>
          <div class="blocker-text">
            <strong>${escapeHtml(b.label)}</strong>
            ${b.valor ? `<span class="blocker-value">${escapeHtml(b.valor)}</span>` : ""}
            ${b.detalhe ? `<span class="blocker-detail">${escapeHtml(b.detalhe)}</span>` : ""}
          </div>
          <span class="kind-tag">${escapeHtml(b.tipo)}</span>
        </li>`).join("")}</ul>`
    : `<div class="panel-empty is-ok" data-icon="check">Nenhuma pendência bloqueante.</div>`;

  return `
    <section class="ca-summary ca-summary-${detailStatus}">
      <div class="ca-summary-status">
        <span class="ca-summary-label">Resultado da Etapa 2</span>
        <strong>${statusText}</strong>
        <p>${statusCopy}</p>
      </div>
      <div class="ca-counters">
        ${counter(counts.ok, "Concluídas", "has-ok")}
        ${counter(counts.divergencia, "Divergências", "has-warn")}
        ${counter(counts.dados, "Pendências", "has-data")}
        ${counter(counts.erro, "Erros", "has-err")}
      </div>
    </section>

    <section class="panel">
      <header class="panel-head">
        <div>
          <h3>O que impede a conclusão</h3>
          <p>Itens que precisam ser resolvidos antes de liberar o pedido.</p>
        </div>
        <span class="panel-count">${bloqueadores.length}</span>
      </header>
      ${blockerRows}
    </section>`;
}

function renderQuebraPedidoCompacta(analises){
  const grupos = new Map();

  (Array.isArray(analises) ? analises : []).forEach(a=>{
    const moeda = String(a?.moeda_ariba || "SEM_MOEDA").trim() || "SEM_MOEDA";
    const detalhes = a?.detalhes_validacao && typeof a.detalhes_validacao === "object"
      ? a.detalhes_validacao
      : {};
    const criteriosItem = Array.isArray(detalhes.item) ? detalhes.item : [];
    const centroCrit = criteriosItem.find(c=>String(c?.codigo || "") === "centro");
    let centro = String(centroCrit?.valor || "").trim();

    if(!centro || /não determinado/i.test(centro) || centroCrit?.status !== "ok"){
      centro = "CENTRO_PENDENTE";
    }

    const chave = `${moeda}|${centro}`;
    if(!grupos.has(chave)) grupos.set(chave, []);
    grupos.get(chave).push(String(a?.linha || "—"));
  });

  if(grupos.size <= 1) return "";

  return `
    <section class="panel">
      <header class="panel-head">
        <div>
          <h3>Quebra do pedido por moeda e centro</h3>
          <p>Itens com moeda ou centro diferentes geram ordens separadas.</p>
        </div>
        <span class="panel-count">${grupos.size}</span>
      </header>
      <div class="split-groups">
        ${[...grupos.entries()].map(([chave,linhas])=>{
          const [moeda,centro] = chave.split("|");
          const pendente = centro === "CENTRO_PENDENTE";
          return `
            <div class="split-card ${pendente ? "pending" : ""}">
              <strong>${escapeHtml(moeda)} – ${pendente ? "centro pendente" : `centro ${escapeHtml(centro)}`}</strong>
              <span>Item${linhas.length > 1 ? "s" : ""} ${escapeHtml(linhas.join(", "))}</span>
            </div>`;
        }).join("")}
      </div>
    </section>`;
}

function renderCriterioCompacto(c){
  const status = c?.status || "info";
  const tone = etapa2StatusTone(status,c?.codigo);
  const detalhe = c?.detalhe
    ? `<span class="check-detail">${escapeHtml(c.detalhe)}</span>`
    : "";
  const obrigatorio = c?.bloqueante && status !== "ok"
    ? `<span class="req-tag">Obrigatório</span>`
    : "";

  return `
    <li class="check tone-${tone}">
      <span class="check-icon" aria-hidden="true"></span>
      <div class="check-main">
        <span class="check-name">${escapeHtml(c?.label || c?.codigo || "Validação")}${obrigatorio}</span>
        <span class="check-value">${escapeHtml(formatCriterioValue(c))}</span>
        ${detalhe}
      </div>
      <span class="check-status">${escapeHtml(criterioStatusLabel(status,c?.codigo))}</span>
    </li>`;
}

function renderAreaComercial(area, criterios){
  const lista = Array.isArray(criterios) ? criterios : [];
  if(!lista.length) return "";
  const okCount = lista.filter(c=>c?.status === "ok").length;
  return `
    <div class="check-group">
      <h4>${escapeHtml(etapa2AreaLabel(area))}<span>${okCount} de ${lista.length} concluídas</span></h4>
      <ul class="checks">
        ${lista.map(renderCriterioCompacto).join("")}
      </ul>
    </div>`;
}

function renderItemComercial(a){
  const detalhes = a?.detalhes_validacao && typeof a.detalhes_validacao === "object"
    ? a.detalhes_validacao
    : {};
  const criterios = [
    ...(Array.isArray(detalhes.cliente) ? detalhes.cliente : []),
    ...(Array.isArray(detalhes.item) ? detalhes.item : [])
  ];

  const areas = {
    cliente:[],
    material:[],
    preco:[],
    logistica:[],
    outros:[]
  };

  criterios.forEach(c=>{
    const area = etapa2AreaDoCriterio(c?.codigo);
    (areas[area] || areas.outros).push(c);
  });

  const resumo = detalhes.resumo || {};
  const descricao = resumo.descricao || (
    a?.resultado === "concluido"
      ? "As validações técnicas implementadas foram concluídas."
      : a?.resultado === "divergencia"
        ? "A análise encontrou uma divergência técnica."
        : a?.resultado === "erro"
          ? "Ocorreu uma falha técnica durante a análise."
          : "Faltam dados ou regras para concluir todas as validações."
  );

  return `
    <section class="panel">
      <header class="item-head">
        <div class="item-id">
          <span class="item-line">Item ${escapeHtml(a?.linha || "—")}</span>
          <strong class="item-matnr">${escapeHtml(a?.matnr || "MATNR não identificado")}</strong>
        </div>
        <span class="result-tag ${etapa2ResultadoClass(a?.resultado)}">
          ${escapeHtml(etapa2ResultadoLabel(a?.resultado))}
        </span>
      </header>

      <div class="check-groups">
        ${renderAreaComercial("cliente",areas.cliente)}
        ${renderAreaComercial("material",areas.material)}
        ${renderAreaComercial("preco",areas.preco)}
        ${renderAreaComercial("logistica",areas.logistica)}
        ${renderAreaComercial("outros",areas.outros)}
      </div>

      <div class="item-result ${etapa2ResultadoClass(a?.resultado)}">
        <div>
          <span>Resultado do item</span>
          <strong>${escapeHtml(resumo.titulo || etapa2ResultadoLabel(a?.resultado))}</strong>
        </div>
        <p>${escapeHtml(descricao)}</p>
      </div>

      ${renderMotivoTecnico(a)}
    </section>`;
}


function validacaoFuncionalStatusLabel(status){
  const s = String(status || "pendente").toLowerCase();
  if(s === "confirmado") return "Confirmado";
  if(s === "rejeitado") return "Rejeitado";
  return "Aguardando decisão";
}

function validacaoFuncionalChip(status){
  const s = String(status || "pendente").toLowerCase();
  if(s === "confirmado") return chip("success","Confirmado");
  if(s === "rejeitado") return chip("error","Rejeitado");
  return chip("warning","Aguardando decisão");
}

function renderValidacoesFuncionais(data){
  const validacoes = Array.isArray(data.validacoes_funcionais)
    ? data.validacoes_funcionais
    : [];

  if(!validacoes.length) return "";

  const pendentes = validacoes.filter(v=>String(v.status || "pendente").toLowerCase() === "pendente").length;

  const cards = validacoes.map(v=>{
    const status = String(v.status || "pendente").toLowerCase();
    const isHistorico = String(v.codigo || "") === "sugestao_historica_matnr";
    const confirmLabel = isHistorico ? "Confirmar sugestão" : "Confirmar";
    const rejectLabel = isHistorico ? "Rejeitar sugestão" : "Rejeitar";

    const decisoes = status === "pendente"
      ? `
        <div class="decision-actions">
          <button type="button"
                  class="btn btn-secondary functional-validation-btn reject"
                  data-icon="close"
                  data-functional-validation="${Number(v.id)}"
                  data-functional-decision="rejeitado"
                  data-functional-code="${escapeHtml(v.codigo || "")}"
                  data-order-number="${escapeHtml(data.order_number || "")}">
            ${rejectLabel}
          </button>
          <button type="button"
                  class="btn btn-primary functional-validation-btn confirm"
                  data-icon="check"
                  data-functional-validation="${Number(v.id)}"
                  data-functional-decision="confirmado"
                  data-functional-code="${escapeHtml(v.codigo || "")}"
                  data-order-number="${escapeHtml(data.order_number || "")}">
            ${confirmLabel}
          </button>
        </div>`
      : `
        <div class="decision-audit">
          ${escapeHtml(validacaoFuncionalStatusLabel(status))}
          ${v.decisao_por ? ` por <strong>${escapeHtml(v.decisao_por)}</strong>` : ""}
          ${v.decisao_em ? `<div>${escapeHtml(v.decisao_em)}</div>` : ""}
          ${v.motivo_rejeicao ? `<div>Motivo: ${escapeHtml(v.motivo_rejeicao)}</div>` : ""}
        </div>`;

    return `
      <div class="decision-card is-${escapeHtml(status)}">
        <div class="decision-main">
          <div class="decision-title">
            <strong>${escapeHtml(v.titulo || "Validação funcional")}</strong>
            ${validacaoFuncionalChip(status)}
          </div>
          <p>${escapeHtml(v.descricao || "")}</p>
          ${v.valor_detectado
            ? `<span class="decision-value">${escapeHtml(v.valor_detectado)}</span>`
            : ""}
        </div>
        ${decisoes}
      </div>`;
  }).join("");

  return `
    <section class="decision-panel">
      <header class="decision-head" data-icon="person">
        <div>
          <h3>${pendentes ? `Decisão necessária (${pendentes})` : "Decisões registradas"}</h3>
          <p>Confirme ou rejeite as condições abaixo antes de liberar o pedido para a próxima etapa. A decisão fica registrada com seu usuário.</p>
        </div>
      </header>
      <div class="decision-list">${cards}</div>
    </section>`;
}

function renderEtapa2(data){
  const analises = data.analise_etapa2 || [];
  const numero = data.order_number || "";

  if(data.tipo !== "Contrato"){
    return `
      <div class="ca">
        <div class="ca-head">
          <div>
            <h3>Análise comercial</h3>
            <p>Etapa 2 da automação.</p>
          </div>
          ${etapa2Badge("na")}
        </div>
        <div class="empty-note">
          Este pedido é uma <strong>${escapeHtml(data.tipo || "Oferta")}</strong>. A análise comercial se aplica somente a pedidos de contrato.
        </div>
      </div>`;
  }

  if(!analises.length){
    return `
      <div class="ca">
        <div class="ca-head">
          <div>
            <h3>Análise comercial</h3>
            <p>Etapa 2 da automação.</p>
          </div>
          <div class="ca-head-actions">
            ${etapa2Badge("idle")}
            <button type="button"
                    class="btn btn-secondary btn-sm btn-reanalisar-etapa2"
                    data-icon="refresh"
                    data-numero="${escapeHtml(numero)}">
              Analisar agora
            </button>
          </div>
        </div>
        <div class="empty-note">A análise ainda não foi executada para este pedido. Clique em <strong>Analisar agora</strong> para rodar a Etapa 2 sem baixar o pedido novamente.</div>
      </div>`;
  }

  const detailStatus = analises.some(a=>a.resultado === "erro")
    ? "err"
    : analises.some(a=>a.resultado === "dados_insuficientes" || a.resultado === "pendente")
      ? "dados"
      : analises.some(a=>a.resultado === "divergencia")
        ? "warn"
        : "ok";

  let linhaSelecionada = orderAnalysisItems.get(numero);
  if(!linhaSelecionada || !analises.some(a=>String(a?.linha || "") === String(linhaSelecionada))){
    linhaSelecionada = String(analises[0]?.linha || "");
    orderAnalysisItems.set(numero, linhaSelecionada);
  }

  const selecionado = analises.find(a=>String(a?.linha || "") === String(linhaSelecionada)) || analises[0];

  const itemTabs = analises.length > 1
    ? `
      <div class="item-tabs" role="tablist" aria-label="Itens do pedido">
        ${analises.map(a=>{
          const linha = String(a?.linha || "");
          const active = linha === String(linhaSelecionada);
          return `
            <button type="button"
                    role="tab"
                    aria-selected="${active}"
                    class="item-tab ${active ? "active" : ""}"
                    data-analysis-item="${escapeHtml(linha)}"
                    data-numero="${escapeHtml(numero)}">
              <span>Item ${escapeHtml(linha || "—")}</span>
              <small>${escapeHtml(a?.matnr || "MATNR pendente")}</small>
            </button>`;
        }).join("")}
      </div>`
    : "";

  return `
    <div class="ca">
      <div class="ca-head">
        <div>
          <h3>Análise comercial</h3>
          <p>Cliente, material, preço e logística validados contra SAP, DCLO e DALI.</p>
        </div>
        <div class="ca-head-actions">
          ${etapa2Badge(detailStatus)}
          <button type="button"
                  class="btn btn-secondary btn-sm btn-reanalisar-etapa2"
                  data-icon="refresh"
                  data-numero="${escapeHtml(numero)}">
            Reanalisar
          </button>
        </div>
      </div>

      ${renderValidacoesFuncionais(data)}
      ${renderEtapa2Resumo(analises,detailStatus)}
      ${renderQuebraPedidoCompacta(analises)}
      ${itemTabs}
      ${renderItemComercial(selecionado)}
    </div>`;
}

function renderDetail(numero){
  const data = uteisCache.get(numero);

  if(data === "loading" || data === undefined){
    return `<div class="uteis-loading">Carregando informações do pedido…</div>`;
  }

  if(data === "error"){
    return `<div class="uteis-error">Não foi possível carregar as informações deste pedido. Feche e abra a linha para tentar de novo.</div>`;
  }

  const campoVal = c => c.valor != null && c.valor !== ""
    ? escapeHtml(c.valor)
    : (c.coletavel
        ? DASH
        : `<span class="muted-tag">Não fornecido pela API</span>`);

  const headerRows = (data.cabecalho || []).map(c=>`
    <div class="kv-row">
      <dt>${escapeHtml(c.rotulo)}</dt>
      <dd>${campoVal(c)}</dd>
    </div>
  `).join("");

  const itens = data.itens || [];
  const itensBody = itens.length
    ? itens.map(it=>`<tr>
        <td>${escapeHtml(it.linha ?? "—")}</td>
        <td>${it.codigo_cliente ? `<span class="code">${escapeHtml(it.codigo_cliente)}</span>` : DASH}</td>
        <td>${it.descricao ? escapeHtml(it.descricao) : DASH}</td>
        <td class="num">${it.quantidade != null ? escapeHtml(it.quantidade) : "—"}${it.unidade ? " " + escapeHtml(it.unidade) : ""}</td>
        <td>${it.data_esperada ? escapeHtml(it.data_esperada) : DASH}</td>
        <td class="num">${it.preco_unitario != null ? money(it.preco_unitario, it.moeda || "BRL") : "—"}</td>
      </tr>`).join("")
    : `<tr><td colspan="6" class="empty">Nenhum item.</td></tr>`;

  let aba = orderDetailTabs.get(numero);
  if(!aba){
    aba = data.tipo === "Contrato" ? "comercial" : "pedido";
    orderDetailTabs.set(numero, aba);
  }

  const pedidoPanel = `
    <div class="order-data">
      <section class="panel">
        <header class="panel-head">
          <div>
            <h3>Cabeçalho do pedido</h3>
            <p>Recebido do SAP Business Network / Ariba.</p>
          </div>
          ${chip("success","Coletado")}
        </header>
        <dl class="kv">${headerRows}</dl>
      </section>

      <section class="panel">
        <header class="panel-head">
          <div><h3>Itens coletados</h3></div>
          <span class="panel-count">${itens.length}</span>
        </header>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Linha</th>
                <th>Código do cliente</th>
                <th>Descrição</th>
                <th class="num">Qtd.</th>
                <th>Data esperada</th>
                <th class="num">Preço unitário</th>
              </tr>
            </thead>
            <tbody>${itensBody}</tbody>
          </table>
        </div>
      </section>
    </div>`;

  return `
    <div class="detail">
      <div class="detail-tabs" role="tablist" aria-label="Detalhes do pedido ${escapeHtml(numero)}">
        <button type="button"
                role="tab"
                aria-selected="${aba === "pedido"}"
                class="detail-tab ${aba === "pedido" ? "active" : ""}"
                data-order-detail-tab="pedido"
                data-numero="${escapeHtml(numero)}">
          Dados do pedido
        </button>
        <button type="button"
                role="tab"
                aria-selected="${aba === "comercial"}"
                class="detail-tab ${aba === "comercial" ? "active" : ""}"
                data-order-detail-tab="comercial"
                data-numero="${escapeHtml(numero)}">
          Análise comercial
          ${data.tipo === "Contrato" ? `<span class="count-badge" title="Itens analisados">${(data.analise_etapa2 || []).length}</span>` : ""}
        </button>
      </div>

      <div class="detail-body">
        ${aba === "comercial" ? renderEtapa2(data) : pedidoPanel}
      </div>
    </div>`;
}

async function toggleOrderDetail(numero){
  if(expandedOrders.has(numero)){
    expandedOrders.delete(numero);
    renderOrders();
    return;
  }
  expandedOrders.add(numero);
  if(!uteisCache.has(numero) || uteisCache.get(numero) === "error"){
    uteisCache.set(numero, "loading");
    renderOrders();
    try{
      const data = await apiGet(
        `/api/ordens/${encodeURIComponent(acct)}/${encodeURIComponent(numero)}/uteis`,
        {loading:false}
      );
      uteisCache.set(numero, data);
    }catch(e){
      uteisCache.set(numero, "error");
      toast(`Não consegui carregar o pedido ${numero}: ${e.message}`, true);
    }
  }
  renderOrders();
}

function renderKPIs(k){
  if(!k){
    const s = orders.map(o=>o.etapa1 || "idle");
    k = {
      fila:s.filter(x=>x==="idle" || x==="run").length,
      ok:s.filter(x=>x==="ok").length,
      run:s.filter(x=>x==="run").length,
      err:s.filter(x=>x==="err").length
    };
  }
  $("#kFila").textContent = k.fila || 0;
  $("#kOk").textContent = k.ok || 0;
  $("#kRun").textContent = k.run || 0;
  $("#kErr").textContent = k.err || 0;
}

function renderAll(){ renderClients(); renderOrders(); renderKPIs(); }

function applyExecState(ex, proc){
  setRunButton(proc && proc.running);
  if(!ex){
    $("#execTitle").textContent = "Aguardando execução";
    setStation(proc && proc.running ? "run" : "idle", proc && proc.running ? "iniciando coletor…" : "aguardando execução", proc && proc.running ? 3 : 0);
    return;
  }
  execTotal = Number(ex.total || 0);
  if(ex.status === "run"){
    const agendada = String(ex.iniciado_por || "").startsWith("agendamento:");
    $("#execTitle").textContent = `${agendada ? "Execução agendada" : "Em execução"} desde ${ex.iniciado_em || ""}`;
    const done = Number(ex.sucesso || 0) + Number(ex.erros || 0);
    const pct = execTotal ? Math.min(98, Math.round(done / execTotal * 100)) : 8;
    setStation("run", execTotal ? `${done}/${execTotal} processados` : "descobrindo New Orders…", pct);
  }else if(ex.status === "err"){
    $("#execTitle").textContent = `Finalizada com erro em ${ex.finalizado_em || ""}`;
    setStation("err", `${ex.sucesso} baixado(s) · ${ex.erros} erro(s)`, 100);
  }else if(ex.status === "interrompida"){
    $("#execTitle").textContent = "Execução interrompida";
    setStation("idle", `interrompida · ${ex.iniciado_em || ""}`, 0);
  }else{
    $("#execTitle").textContent = `Concluída em ${ex.finalizado_em || ""}`;
    setStation("ok", `${ex.sucesso} baixado(s) · ${ex.erros} erro(s)`, 100);
  }
}

function applyStage2State(e2){
  setStage2Running(!!(e2 && e2.running));
  if(!e2){
    setStage2Station("idle", "aguardando conclusão da Etapa 1", 0);
    return;
  }
  if(e2.running){
    const total = Number(e2.total_execucao || 0);
    const done = Number(e2.concluido_execucao || 0);
    const pct = total ? Math.round(done / total * 100) : 5;
    setStage2Station("run", total ? `${done}/${total} pedido(s) analisado(s)` : "iniciando análise…", pct);
    return;
  }

  const err = Number(e2.err || 0);
  const dados = Number(e2.dados_insuficientes || 0);
  const pend = Number(e2.pendente || 0); // legado
  const div = Number(e2.divergencia || 0);
  const ok = Number(e2.analisado || 0);
  const na = Number(e2.nao_aplicavel || 0);
  const aguard = Number(e2.aguardando || 0);

  if(err > 0){
    setStage2Station(
      "err",
      `${err} erro(s) · ${dados + pend} pendente(s) · ${div} divergência(s) · ${ok} concluído(s) · ${na} não aplicável(is)`,
      100
    );
    return;
  }
  if(dados > 0 || pend > 0){
    setStage2Station(
      "dados",
      `${dados + pend} contrato(s) pendente(s) · ${div} divergência(s) · ${ok} concluído(s) · ${na} não aplicável(is)`,
      100
    );
    return;
  }
  if(div > 0){
    setStage2Station("warn", `${div} contrato(s) com divergência · ${ok} concluído(s) · ${na} não aplicável(is)`, 100);
    return;
  }
  if(ok > 0){
    setStage2Station("ok", `${ok} contrato(s) concluído(s) · ${na} não aplicável(is)`, 100);
    return;
  }
  if(na > 0 && aguard === 0){
    setStage2Station("na", `${na} oferta(s) · Etapa 2 não aplicável`, 100);
    return;
  }
  setStage2Station("idle", `${aguard} pedido(s) aguardando análise`, 0);
}

async function loadAccount(){
  $("#runAcct").textContent = acct;
  $("#ordAcct").textContent = acct;
  $("#paramAcct").textContent = acct;

  showApiLoading(`Carregando dados da conta ${acct}…`);
  try{
    orders = await apiGet(`/api/ordens?conta=${acct}`, {loading:false});
    setServer(true);

    const logs = await apiGet(`/api/logs?conta=${acct}`, {loading:false});
    $("#console").innerHTML = "";
    if(logs.length) logs.forEach(l=>logLine(l.mensagem,l.nivel,l.hora));
    else logLine(`Nenhum log registrado para ${acct}.`, "info");

    const res = await apiGet(`/api/resumo?conta=${acct}`, {loading:false});
    renderKPIs(res.kpi);
    applyExecState(res.execucao, res.processo);
    applyStage2State(res.etapa2);
    renderClients();
    renderOrders();

    await loadParametros({loading:false});
  }catch(e){
    setServer(false);
    toast(e.message || "Backend indisponível", true);
  }finally{
    hideApiLoading();
  }
}

function connectStream(){
  if(evtSrc) evtSrc.close();
  evtSrc = new EventSource(`/api/stream?conta=${acct}`);
  evtSrc.onopen = ()=> $("#liveTag").classList.add("on");
  evtSrc.onerror = ()=> $("#liveTag").classList.remove("on");
  evtSrc.onmessage = ev=>{
    let d;
    try{ d = JSON.parse(ev.data); }catch{ return; }
    if(d.conta && d.conta !== acct) return;

    if(d.tipo === "log"){
      logLine(d.mensagem,d.nivel,d.hora);
    }else if(d.tipo === "processo_inicio"){
      setRunButton(true);
      $("#console").innerHTML = "";
      const agendada = String(d.iniciado_por || "").startsWith("agendamento:");
      $("#execTitle").textContent = agendada ? "Execução agendada em andamento" : "Execução em andamento";
      logLine(agendada ? `Execução agendada iniciada para ${acct}.` : `Processo iniciado para ${acct}.`, "head");
      setStation("run", "iniciando coletor…", 3);
      setStage2Station("idle", "aguardando conclusão da Etapa 1", 0);
    }else if(d.tipo === "agendamento_disparado"){
      setRunButton(true);
      $("#execTitle").textContent = "Execução agendada em andamento";
      setStation("run", "iniciando coletor agendado…", 3);
    }else if(d.tipo === "execucao_abrir"){
      execTotal = Number(d.total || 0);
      setStation("run", execTotal ? `lote: ${execTotal} pedido(s)` : "autenticando e descobrindo pedidos…", execTotal ? 8 : 5);
    }else if(d.tipo === "execucao_atualizar"){
      execTotal = Number(d.total || 0);
      setStation("run", `${execTotal} New Order(s) para processar`, 10);
    }else if(d.tipo === "ordem"){
      const i = orders.findIndex(o=>o.numero === d.ordem.numero);
      if(i >= 0) orders[i] = {...orders[i], ...d.ordem};
      else orders.unshift(d.ordem);
      // Dados do pedido mudaram: descarta os campos úteis em cache.
      uteisCache.delete(d.ordem.numero);
      const done = orders.filter(o=>o.etapa1 === "ok" || o.etapa1 === "err").length;
      const total = execTotal || orders.length || 1;
      setStation("run", `processando ${d.ordem.numero} · ${Math.min(done,total)}/${total}`, 10 + Math.round(Math.min(done,total)/total*88));
      renderAll();
    }else if(d.tipo === "execucao_fechar"){
      setRunButton(false);
      setStation(d.status === "err" ? "err" : "ok", `${d.sucesso} baixado(s) · ${d.erros} erro(s)`, 100);
      setStage2Station("run", "Etapa 1 concluída · preparando análise…", 2);
      loadAccount();
    }else if(d.tipo === "etapa2_inicio"){
      setStage2Running(true);
      const total = Number(d.total || 0);
      setStage2Station("run", total ? `0/${total} pedido(s) analisado(s)` : "nenhum pedido elegível para análise", total ? 3 : 100);
      logLine(`Etapa 2 iniciada para ${total} pedido(s).`, "head");
    }else if(d.tipo === "etapa2_ordem"){
      const i = orders.findIndex(o=>o.numero === d.numero);
      if(i >= 0){
        orders[i] = {...orders[i], etapa2:d.status || orders[i].etapa2, etapa2_msg:d.resumo || orders[i].etapa2_msg};
      }
      uteisCache.delete(d.numero);
      const total = Number(d.total || 0);
      const done = Number(d.concluido || 0);
      const pct = total ? Math.round(done / total * 100) : 10;
      setStage2Station("run", total ? `${done}/${total} pedido(s) analisado(s)` : `analisando ${d.numero}`, pct);
      renderOrders();
    }else if(d.tipo === "etapa2_fim"){
      setStage2Running(false);
      if(d.status === "err"){
        setStage2Station("err", d.erro || `${d.erros || 0} erro(s) na análise`, 100);
        logLine(`Etapa 2 finalizada com erro: ${d.erro || "verifique os pedidos"}`, "err");
      }else{
        setStage2Station("ok", `${d.concluido || 0}/${d.total || 0} pedido(s) processado(s) · atualizando resultados…`, 100);
        logLine(`Etapa 2 concluída: ${d.concluido || 0} pedido(s) processado(s).`, "ok");
      }
      loadAccount();
    }else if(d.tipo === "processo_fim"){
      setRunButton(false);
      if(Number(d.exit_code) !== 0) logLine(`Processo encerrou com código ${d.exit_code}.`, "err");
    }else if(d.tipo === "limpar"){
      orders = [];
      execTotal = 0;
      orderPage = 1;
      expandedOrders.clear();
      uteisCache.clear();
      $("#console").innerHTML = "";
      $("#execTitle").textContent = "Aguardando execução";
      setStation("idle", "aguardando execução", 0);
      setStage2Running(false);
      setStage2Station("idle", "aguardando conclusão da Etapa 1", 0);
      renderAll();
    }
  };
}

// -----------------------------------------------------------------------------
// CREDENCIAIS
// -----------------------------------------------------------------------------
const MASKED_CREDENTIAL = "••••••••••••••••••••••••";

function setEyeState(buttonSelector, showing, enabled=true){
  const button = $(buttonSelector);
  button.disabled = !enabled;
  button.innerHTML = "";
  button.dataset.icon = showing ? "eye-off" : "eye";
  const action = showing ? "Ocultar" : "Mostrar";
  const fieldName = buttonSelector === "#btnEyeSecret" ? "OAuth Secret" : "Application Key";
  button.setAttribute("aria-label", `${action} ${fieldName}`);
  button.title = `${action} ${fieldName}`;
}

function resetCredentialField(fieldSelector, buttonSelector, configured){
  const field = $(fieldSelector);
  field.type = "password";
  field.dataset.revealed = "0";
  if(configured){ field.value = MASKED_CREDENTIAL; field.dataset.masked = "1"; }
  else{ field.value = ""; field.dataset.masked = "0"; }
  setEyeState(buttonSelector, false, configured);
}

async function toggleCredentialVisibility({fieldSelector,buttonSelector,apiField,label}){
  const field = $(fieldSelector);
  const button = $(buttonSelector);
  if(button.disabled) return;
  const showing = field.dataset.revealed === "1";
  if(showing){
    field.type = "password";
    field.dataset.revealed = "0";
    if(field.dataset.masked === "1") field.value = MASKED_CREDENTIAL;
    setEyeState(buttonSelector,false,true);
    return;
  }
  if(field.dataset.masked !== "1"){
    if(!field.value.trim()) return;
    field.type = "text";
    field.dataset.revealed = "1";
    setEyeState(buttonSelector,true,true);
    return;
  }
  button.disabled = true;
  try{
    const response = await apiPost("/api/parametros/revelar", {conta:acct,campo:apiField}, {loadingText:"Carregando credencial…"});
    field.value = response.valor || "";
    field.type = "text";
    field.dataset.masked = "1";
    field.dataset.revealed = "1";
    setEyeState(buttonSelector,true,true);
  }catch(e){
    setEyeState(buttonSelector,false,true);
    toast(`Não consegui revelar ${label}: ${e.message}`,true);
  }
}

// -----------------------------------------------------------------------------
// CARTÕES DE REGRAS (Parâmetros)
// -----------------------------------------------------------------------------
function ruleCardShell({id, title, desc, formClass, formHtml, help, headCols, bodyId}){
  return {
    id,
    html:`
      <div class="card-head">
        <div class="card-title">
          <h2>${title}</h2>
          <p class="card-desc">${desc}</p>
        </div>
      </div>
      <div class="card-body">
        <div class="rule-form ${formClass}">${formHtml}</div>
        <p class="help">${help}</p>
        <div class="table-wrap rule-table-wrap">
          <table class="data-table">
            <thead><tr>${headCols}</tr></thead>
            <tbody id="${bodyId}"></tbody>
          </table>
        </div>
      </div>`
  };
}

const removeBtn = (attr, id) =>
  `<button type="button" class="btn btn-tertiary btn-sm" data-icon="trash" ${attr}="${Number(id)}">Remover</button>`;

let paymentMappings = [];

function ensurePaymentMappingPanel(){
  if($("#paymentMappingCard")) return;
  const view = document.querySelector('.view[data-view="parametros"]');
  if(!view) return;

  const card = document.createElement("div");
  card.id = "paymentMappingCard";
  card.className = "card rule-card payment-map-card";
  card.innerHTML = ruleCardShell({
    title:"Condição de pagamento (Ariba → ZTERM SAP)",
    desc:"A regra específica do KUNNR tem prioridade. Deixe o KUNNR vazio somente para uma equivalência global oficialmente validada.",
    formClass:"rule-form-payment",
    formHtml:`
      <div class="field mono">
        <input type="text" id="paymentKunnr" placeholder=" " maxlength="30">
        <label for="paymentKunnr">KUNNR <span>(vazio = global)</span></label>
      </div>
      <div class="field mono">
        <input type="text" id="paymentAribaCode" placeholder=" " maxlength="50">
        <label for="paymentAribaCode">Código Ariba</label>
      </div>
      <div class="field mono">
        <input type="text" id="paymentSapZterm" placeholder=" " maxlength="50">
        <label for="paymentSapZterm">ZTERM SAP</label>
      </div>
      <div class="field">
        <input type="text" id="paymentMapDescription" placeholder=" " maxlength="250">
        <label for="paymentMapDescription">Descrição <span>(opcional)</span></label>
      </div>
      <button type="button" class="btn btn-primary" id="btnSavePaymentMap" data-icon="plus">Adicionar</button>`,
    help:"Ordem de busca: KUNNR específico + código Ariba; se não houver, a regra global do código Ariba.",
    headCols:`<th>Escopo</th><th>KUNNR</th><th>Ariba</th><th>ZTERM SAP</th><th>Descrição</th><th>Atualizado</th><th></th>`,
    bodyId:"paymentMappingRows"
  }).html;

  view.appendChild(card);

  $("#btnSavePaymentMap").onclick = savePaymentMapping;
  $("#paymentMappingRows").onclick = async e=>{
    const btn = e.target.closest("[data-remove-payment-map]");
    if(!btn) return;
    const id = Number(btn.dataset.removePaymentMap || 0);
    if(!id) return;
    const ok = await confirmAction({title:"Remover equivalência",message:"Remover este mapeamento de condição de pagamento? Pedidos reanalisados deixarão de usá-lo.",confirmText:"Remover"});
    if(!ok) return;
    try{
      await apiDelete(`/api/mapeamentos/pagamento/${id}`, {loadingText:"Removendo equivalência…"});
      toast("Equivalência removida");
      await loadPaymentMappings({loading:false});
    }catch(err){ toast(err.message || "Não consegui remover o mapeamento", true); }
  };
}

function renderPaymentMappings(){
  ensurePaymentMappingPanel();
  const body = $("#paymentMappingRows");
  if(!body) return;
  if(!paymentMappings.length){
    body.innerHTML = `<tr><td colspan="7" class="empty">Nenhuma equivalência cadastrada.</td></tr>`;
    return;
  }
  body.innerHTML = paymentMappings.map(m=>{
    const specific = !!m.kunnr;
    return `<tr>
      <td><span class="tag ${specific ? "tag-client" : "tag-global"}">${specific ? "Cliente" : "Global"}</span></td>
      <td><span class="code">${escapeHtml(m.kunnr || "—")}</span></td>
      <td><span class="code">${escapeHtml(m.ariba_codigo || "—")}</span></td>
      <td><span class="code">${escapeHtml(m.sap_zterm || "—")}</span></td>
      <td>${escapeHtml(m.descricao || "—")}</td>
      <td class="cell-date">${escapeHtml(m.atualizado_em || "—")}</td>
      <td class="row-actions">${removeBtn("data-remove-payment-map", m.id)}</td>
    </tr>`;
  }).join("");
}

async function loadPaymentMappings(options={}){
  ensurePaymentMappingPanel();
  try{
    paymentMappings = await apiGet("/api/mapeamentos/pagamento", options);
    if(!Array.isArray(paymentMappings)) paymentMappings = [];
    renderPaymentMappings();
  }catch(e){
    paymentMappings = [];
    renderPaymentMappings();
    toast(`Não consegui carregar mapeamentos de pagamento: ${e.message}`, true);
  }
}

async function savePaymentMapping(){
  const kunnr = $("#paymentKunnr")?.value.trim() || "";
  const ariba = $("#paymentAribaCode")?.value.trim().toUpperCase();
  const sap = $("#paymentSapZterm")?.value.trim().toUpperCase();
  const descricao = $("#paymentMapDescription")?.value.trim() || "";
  if(!ariba || !sap){
    toast("Informe o código Ariba e o ZTERM SAP", true);
    return;
  }
  try{
    const saved = await apiPost("/api/mapeamentos/pagamento", {kunnr, ariba_codigo:ariba, sap_zterm:sap, descricao}, {loadingText:"Salvando equivalência…"});
    $("#paymentKunnr").value = "";
    $("#paymentAribaCode").value = "";
    $("#paymentSapZterm").value = "";
    $("#paymentMapDescription").value = "";
    const scope = saved.kunnr ? `KUNNR ${saved.kunnr}` : "regra global";
    toast(`Equivalência ${scope}: ${ariba} → ${sap} salva`);
    await loadPaymentMappings({loading:false});
  }catch(e){ toast(e.message || "Não consegui salvar o mapeamento", true); }
}



let shipToMappings = [];

function ensureShipToMappingPanel(){
  if($("#shipToMappingCard")) return;
  const view = document.querySelector('.view[data-view="parametros"]');
  if(!view) return;

  const card = document.createElement("div");
  card.id = "shipToMappingCard";
  card.className = "card rule-card shipto-map-card";
  card.innerHTML = ruleCardShell({
    title:"Local de entrega Ariba → KUNNR SAP",
    desc:"Resolve o cliente SAP pelo código Ship-to do Ariba, sem depender de nome ou endereço.",
    formClass:"rule-form-shipto",
    formHtml:`
      <div class="field mono">
        <input type="text" id="shipToCode" placeholder=" " maxlength="50">
        <label for="shipToCode">Código Ship-to</label>
      </div>
      <div class="field mono">
        <input type="text" id="shipToKunnr" placeholder=" " maxlength="30">
        <label for="shipToKunnr">KUNNR SAP</label>
      </div>
      <div class="field">
        <input type="text" id="shipToDescription" placeholder=" " maxlength="250">
        <label for="shipToDescription">Descrição ou evidência <span>(opcional)</span></label>
      </div>
      <button type="button" class="btn btn-primary" id="btnSaveShipToMap" data-icon="plus">Adicionar</button>`,
    help:"Tem prioridade sobre o reconhecimento aproximado por nome/endereço. Cadastre somente com evidência oficial.",
    headCols:`<th>Ship-to</th><th>KUNNR</th><th>Descrição / evidência</th><th>Atualizado</th><th></th>`,
    bodyId:"shipToMappingRows"
  }).html;

  view.appendChild(card);
  $("#btnSaveShipToMap").onclick = saveShipToMapping;

  $("#shipToMappingRows").onclick = async e=>{
    const btn = e.target.closest("[data-remove-shipto]");
    if(!btn) return;
    const id = Number(btn.dataset.removeShipto || 0);
    if(!id) return;
    const ok = await confirmAction({
      title:"Remover mapeamento Ship-to",
      message:"Remover este mapeamento? Pedidos reanalisados voltarão a identificar o cliente por nome/endereço.",
      confirmText:"Remover"
    });
    if(!ok) return;
    try{
      await apiDelete(`/api/mapeamentos/shipto/${id}`, {loadingText:"Removendo mapeamento…"});
      await loadShipToMappings({loading:false});
      toast("Mapeamento Ship-to removido");
    }catch(err){ toast(err.message || "Não consegui remover o mapeamento", true); }
  };
}

function renderShipToMappings(){
  ensureShipToMappingPanel();
  const body = $("#shipToMappingRows");
  if(!body) return;
  if(!shipToMappings.length){
    body.innerHTML = `<tr><td colspan="5" class="empty">Nenhum Ship-to cadastrado.</td></tr>`;
    return;
  }

  body.innerHTML = shipToMappings.map(m=>`
    <tr>
      <td><span class="code">${escapeHtml(m.ship_to_code || "—")}</span></td>
      <td><span class="code">${escapeHtml(m.kunnr || "—")}</span></td>
      <td>${escapeHtml(m.descricao || "—")}</td>
      <td class="cell-date">${escapeHtml(m.atualizado_em || "—")}</td>
      <td class="row-actions">${removeBtn("data-remove-shipto", m.id)}</td>
    </tr>`).join("");
}

async function loadShipToMappings(options={}){
  ensureShipToMappingPanel();
  try{
    shipToMappings = await apiGet("/api/mapeamentos/shipto", options);
    if(!Array.isArray(shipToMappings)) shipToMappings = [];
    renderShipToMappings();
  }catch(e){
    shipToMappings = [];
    renderShipToMappings();
    toast(`Não consegui carregar mapeamentos Ship-to: ${e.message}`, true);
  }
}

async function saveShipToMapping(){
  const shipToCode = $("#shipToCode")?.value.trim().toUpperCase() || "";
  const kunnr = $("#shipToKunnr")?.value.trim() || "";
  const descricao = $("#shipToDescription")?.value.trim() || "";

  if(!shipToCode || !kunnr){
    toast("Informe o código Ship-to e o KUNNR SAP", true);
    return;
  }

  try{
    await apiPost("/api/mapeamentos/shipto", {
      ship_to_code: shipToCode,
      kunnr,
      descricao
    }, {loadingText:"Salvando mapeamento Ship-to…"});

    $("#shipToCode").value = "";
    $("#shipToKunnr").value = "";
    $("#shipToDescription").value = "";

    toast(`Ship-to ${shipToCode} → KUNNR ${kunnr} salvo`);
    await loadShipToMappings({loading:false});
  }catch(e){
    toast(e.message || "Não consegui salvar o mapeamento Ship-to", true);
  }
}


let mvkeMappings = [];

function ensureMvkeMappingPanel(){
  if($("#mvkeMappingCard")) return;
  const view = document.querySelector('.view[data-view="parametros"]');
  if(!view) return;

  const card = document.createElement("div");
  card.id = "mvkeMappingCard";
  card.className = "card rule-card mvke-map-card";
  card.innerHTML = ruleCardShell({
    title:"Status de venda do material (MVKE / VMSTA)",
    desc:"Define como cada código VMSTA é tratado na análise. Cadastre somente com regra oficial validada.",
    formClass:"rule-form-mvke",
    formHtml:`
      <div class="field mono">
        <input type="text" id="mvkeCode" placeholder=" " maxlength="20">
        <label for="mvkeCode">Código VMSTA</label>
      </div>
      <div class="field">
        <select id="mvkeClassification">
          <option value="compativel">Compatível</option>
          <option value="divergencia">Divergência</option>
          <option value="informativo">Informativo</option>
        </select>
        <label for="mvkeClassification">Tratamento</label>
      </div>
      <div class="field">
        <input type="text" id="mvkeDescription" placeholder=" " maxlength="250">
        <label for="mvkeDescription">Descrição <span>(opcional)</span></label>
      </div>
      <button type="button" class="btn btn-primary" id="btnSaveMvkeMap" data-icon="plus">Adicionar</button>`,
    help:"Compatível valida o critério. Divergência marca divergência técnica. Informativo apenas exibe o significado.",
    headCols:`<th>VMSTA</th><th>Tratamento</th><th>Descrição</th><th>Atualizado</th><th></th>`,
    bodyId:"mvkeMappingRows"
  }).html;

  view.appendChild(card);
  $("#btnSaveMvkeMap").onclick = saveMvkeMapping;

  $("#mvkeMappingRows").onclick = async e=>{
    const btn = e.target.closest("[data-remove-mvke]");
    if(!btn) return;
    const id = Number(btn.dataset.removeMvke || 0);
    if(!id) return;
    const ok = await confirmAction({
      title:"Remover status MVKE",
      message:"Remover esta parametrização?",
      confirmText:"Remover"
    });
    if(!ok) return;
    try{
      await apiDelete(`/api/mapeamentos/mvke/${id}`, {loadingText:"Removendo status…"});
      await loadMvkeMappings({loading:false});
      toast("Status MVKE removido");
    }catch(err){ toast(err.message, true); }
  };
}

function renderMvkeMappings(){
  ensureMvkeMappingPanel();
  const body = $("#mvkeMappingRows");
  if(!body) return;

  if(!mvkeMappings.length){
    body.innerHTML = `<tr><td colspan="5" class="empty">Nenhum status MVKE cadastrado.</td></tr>`;
    return;
  }

  const labels = {
    compativel:["success","Compatível"],
    divergencia:["warning","Divergência"],
    informativo:["neutral","Informativo"]
  };
  body.innerHTML = mvkeMappings.map(m=>{
    const [tone,label] = labels[m.classificacao] || ["neutral", m.classificacao || "—"];
    return `
    <tr>
      <td><span class="code">${escapeHtml(m.codigo_vmsta || "—")}</span></td>
      <td>${chip(tone,label)}</td>
      <td>${escapeHtml(m.descricao || "—")}</td>
      <td class="cell-date">${escapeHtml(m.atualizado_em || "—")}</td>
      <td class="row-actions">${removeBtn("data-remove-mvke", m.id)}</td>
    </tr>`;
  }).join("");
}

async function loadMvkeMappings(options={}){
  ensureMvkeMappingPanel();
  try{
    mvkeMappings = await apiGet("/api/mapeamentos/mvke", options);
    if(!Array.isArray(mvkeMappings)) mvkeMappings = [];
    renderMvkeMappings();
  }catch(e){
    mvkeMappings = [];
    renderMvkeMappings();
    toast(`Não consegui carregar status MVKE: ${e.message}`, true);
  }
}

async function saveMvkeMapping(){
  const codigo = $("#mvkeCode").value.trim().toUpperCase();
  const classificacao = $("#mvkeClassification").value;
  const descricao = $("#mvkeDescription").value.trim();
  if(!codigo){ toast("Informe o código VMSTA", true); return; }

  try{
    await apiPost("/api/mapeamentos/mvke", {
      codigo_vmsta: codigo,
      classificacao,
      descricao
    }, {loadingText:"Salvando status MVKE…"});
    $("#mvkeCode").value = "";
    $("#mvkeDescription").value = "";
    await loadMvkeMappings({loading:false});
    toast(`Status ${codigo} salvo`);
  }catch(e){ toast(e.message, true); }
}


let clientCommercialParams = [];

const DESTINOS_MERCADORIA = ["Consumo/Imobilização","Revenda","Industrialização"];

function ensureClientCommercialPanel(){
  if($("#clientCommercialCard")) return;
  const view = document.querySelector('.view[data-view="parametros"]');
  if(!view) return;

  const card = document.createElement("div");
  card.id = "clientCommercialCard";
  card.className = "card rule-card client-commercial-card";
  card.innerHTML = ruleCardShell({
    title:"Parâmetros por cliente",
    desc:"Canal de distribuição (VTWEG) e destino padrão da mercadoria por KUNNR. Transportadora, redespacho e representante vêm automaticamente do DALI.",
    formClass:"rule-form-client",
    formHtml:`
      <div class="field mono">
        <input type="text" id="clientParamKunnr" placeholder=" " maxlength="30">
        <label for="clientParamKunnr">KUNNR</label>
      </div>
      <div class="field">
        <select id="clientParamVtweg">
          <option value="">Automático (canal único na KNVV)</option>
          <option value="50">50</option>
          <option value="52">52</option>
          <option value="53">53</option>
        </select>
        <label for="clientParamVtweg">Canal de distribuição (VTWEG)</label>
      </div>
      <div class="field">
        <select id="clientParamDestino">
          <option value="">Sem padrão</option>
          ${DESTINOS_MERCADORIA.map(d=>`<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join("")}
        </select>
        <label for="clientParamDestino">Destino padrão da mercadoria</label>
      </div>
      <button type="button" class="btn btn-primary" id="btnSaveClientParam" data-icon="save">Salvar</button>`,
    help:"O canal filtra a MVKE em BR10 (VMSTA, centro e lote) e a KNVV (pagamento, Incoterm e grupos ZNET). Deixe automático quando o cliente tiver um único canal em BR10. O destino padrão só é usado quando o item, o cabeçalho e o contrato não informam o destino. Salvar um KUNNR existente substitui os valores dele.",
    headCols:`<th>KUNNR</th><th>Canal</th><th>Destino padrão</th><th>Atualizado</th><th></th>`,
    bodyId:"clientCommercialRows"
  }).html;

  view.appendChild(card);
  $("#btnSaveClientParam").onclick = saveClientCommercialParam;

  $("#clientCommercialRows").onclick = async e=>{
    const edit = e.target.closest("[data-edit-client-param]");
    if(edit){
      const p = clientCommercialParams.find(x=>Number(x.id) === Number(edit.dataset.editClientParam));
      if(p){
        $("#clientParamKunnr").value = p.kunnr || "";
        $("#clientParamVtweg").value = p.vtweg || "";
        $("#clientParamDestino").value = p.destino_mercadoria || "";
        $("#clientParamKunnr").focus();
      }
      return;
    }

    const btn = e.target.closest("[data-remove-client-param]");
    if(!btn) return;
    const id = Number(btn.dataset.removeClientParam || 0);
    if(!id) return;

    const ok = await confirmAction({
      title:"Remover parâmetros do cliente",
      message:"Remover o canal e o destino padrão deste cliente? Pedidos reanalisados voltarão a usar a KNVV para o canal.",
      confirmText:"Remover"
    });
    if(!ok) return;

    try{
      await apiDelete(`/api/parametros/clientes/${id}`, {loadingText:"Removendo parâmetros…"});
      await loadClientCommercialParams({loading:false});
      toast("Parâmetros removidos");
    }catch(err){ toast(err.message || "Não consegui remover os parâmetros", true); }
  };
}

function renderClientCommercialParams(){
  ensureClientCommercialPanel();
  const body = $("#clientCommercialRows");
  if(!body) return;

  if(!clientCommercialParams.length){
    body.innerHTML = `<tr><td colspan="5" class="empty">Nenhum cliente parametrizado.</td></tr>`;
    return;
  }

  body.innerHTML = clientCommercialParams.map(p=>`
    <tr>
      <td><span class="code">${escapeHtml(p.kunnr || "—")}</span></td>
      <td>${p.vtweg ? `<span class="code">${escapeHtml(p.vtweg)}</span>` : `<span class="muted-tag">Automático</span>`}</td>
      <td>${p.destino_mercadoria ? escapeHtml(p.destino_mercadoria) : `<span class="muted-tag">Sem padrão</span>`}</td>
      <td class="cell-date">${escapeHtml(p.atualizado_em || "—")}</td>
      <td class="row-actions">
        <button type="button" class="btn btn-tertiary btn-sm" data-edit-client-param="${Number(p.id)}">Editar</button>
        ${removeBtn("data-remove-client-param", p.id)}
      </td>
    </tr>`).join("");
}

async function loadClientCommercialParams(options={}){
  ensureClientCommercialPanel();
  try{
    clientCommercialParams = await apiGet("/api/parametros/clientes", options);
    if(!Array.isArray(clientCommercialParams)) clientCommercialParams = [];
    renderClientCommercialParams();
  }catch(e){
    clientCommercialParams = [];
    renderClientCommercialParams();
    toast(`Não consegui carregar parâmetros por cliente: ${e.message}`, true);
  }
}

async function saveClientCommercialParam(){
  const kunnr = $("#clientParamKunnr").value.trim();
  const vtweg = $("#clientParamVtweg").value.trim();
  const destino_mercadoria = $("#clientParamDestino").value.trim();

  if(!kunnr){
    toast("Informe o KUNNR", true);
    return;
  }
  if(!vtweg && !destino_mercadoria){
    toast("Informe o canal, o destino padrão ou ambos", true);
    return;
  }

  try{
    await apiPost("/api/parametros/clientes", {
      kunnr,
      vtweg,
      destino_mercadoria
    }, {loadingText:"Salvando parâmetros do cliente…"});

    $("#clientParamKunnr").value = "";
    $("#clientParamVtweg").value = "";
    $("#clientParamDestino").value = "";

    await loadClientCommercialParams({loading:false});
    toast(`Cliente ${kunnr} salvo. Reanalise os pedidos dele para aplicar.`);
  }catch(e){ toast(e.message || "Não consegui salvar os parâmetros", true); }
}

async function loadParametros(options={}){
  try{
    const p = await apiGet(`/api/parametros?conta=${acct}`, options);
    $("#pAnid").value = p.anid || "";
    $("#pClientId").value = p.client_id || "";
    $("#secretState").textContent = p.tem_client_secret ? "configurado" : "não configurado";
    $("#apiKeyState").textContent = p.tem_api_key ? "configurada" : "não configurada";
    resetCredentialField("#pSecret","#btnEyeSecret",!!p.tem_client_secret);
    resetCredentialField("#pApiKey","#btnEyeApiKey",!!p.tem_api_key);
  }catch(e){ toast(`Não consegui carregar parâmetros: ${e.message}`,true); }

  await loadPaymentMappings({loading:false});
  await loadShipToMappings({loading:false});
  await loadMvkeMappings({loading:false});
  await loadClientCommercialParams({loading:false});
}

function prepararCampoSecreto(selector,buttonSelector,stateSelector,configuredText){
  const campo = $(selector);
  campo.addEventListener("focus",()=>{
    if(campo.dataset.masked === "1"){
      campo.value = "";
      campo.type = "password";
      campo.dataset.masked = "0";
      campo.dataset.revealed = "0";
      setEyeState(buttonSelector,false,false);
    }
  });
  campo.addEventListener("input",()=>{
    const temValor = !!campo.value.trim();
    campo.dataset.masked = "0";
    campo.dataset.revealed = campo.type === "text" ? "1" : "0";
    setEyeState(buttonSelector,campo.type === "text",temValor);
  });
  campo.addEventListener("blur",()=>{
    const configurado = $(stateSelector).textContent === configuredText;
    if(!campo.value.trim() && configurado){
      campo.type = "password";
      campo.value = MASKED_CREDENTIAL;
      campo.dataset.masked = "1";
      campo.dataset.revealed = "0";
      setEyeState(buttonSelector,false,true);
    }
  });
}

// -----------------------------------------------------------------------------
// AGENDAMENTOS
// -----------------------------------------------------------------------------
function scheduleLabel(s){
  const freq = s.frequencia === "DAILY" ? "Todos os dias" : `Uma vez em ${s.data_execucao || "data não definida"}`;
  const period = s.periodo === "24h" ? "últimas 24h" : "últimos 365 dias";
  return `${freq} às ${s.horario}, consultando ${period}`;
}

function renderScheduleList(){
  const wrap = $("#scheduleList");
  if(!schedules.length){
    wrap.innerHTML = `<div class="empty-block">Nenhum agendamento criado. Clique em <b>Novo</b> para criar o primeiro.</div>`;
    return;
  }
  wrap.innerHTML = schedules.map(s=>`
    <button type="button" class="config-row ${s.id===selectedScheduleId?"active":""}" data-schedule-id="${s.id}">
      <div class="config-row-title">
        <strong>${escapeHtml(s.conta)} às ${escapeHtml(s.horario)}</strong>
        ${s.ativo ? chip("success","Ativo") : chip("neutral","Inativo")}
      </div>
      <div class="config-row-meta">
        ${escapeHtml(scheduleLabel(s))}<br>
        ${s.ultima_execucao ? `Última execução: ${escapeHtml(s.ultima_execucao)}` : "Ainda não executado"}
      </div>
    </button>`).join("");
}

function updateScheduleDateVisibility(){
  $("#scheduleDateWrap").classList.toggle("hidden", $("#scheduleFrequency").value !== "ONCE");
}

function resetScheduleForm(){
  $("#scheduleId").value = "";
  $("#scheduleFormTitle").textContent = "Novo agendamento";
  $("#scheduleAccount").value = "ITA";
  $("#schedulePeriod").value = "24h";
  $("#scheduleFrequency").value = "DAILY";
  $("#scheduleTime").value = "07:00";
  $("#scheduleDate").value = "";
  $("#scheduleActive").checked = true;
  $("#btnDeleteSchedule").classList.add("hidden");
  updateScheduleDateVisibility();
}

function closeScheduleForm(){
  selectedScheduleId = null;
  resetScheduleForm();
  $("#scheduleFormCard").classList.add("hidden");
  $("#scheduleFormEmpty").classList.remove("hidden");
  renderScheduleList();
}

function showScheduleForm(){
  $("#scheduleFormEmpty").classList.add("hidden");
  $("#scheduleFormCard").classList.remove("hidden");
}

function openScheduleForm(s=null){
  selectedScheduleId = s ? s.id : null;
  showScheduleForm();
  $("#scheduleId").value = s ? s.id : "";
  $("#scheduleFormTitle").textContent = s ? `Agendamento ${s.conta} às ${s.horario}` : "Novo agendamento";
  $("#scheduleAccount").value = s?.conta || "ITA";
  $("#schedulePeriod").value = s?.periodo || "24h";
  $("#scheduleFrequency").value = s?.frequencia || "DAILY";
  $("#scheduleTime").value = s?.horario || "07:00";
  $("#scheduleDate").value = s?.data_execucao || "";
  $("#scheduleActive").checked = s ? !!s.ativo : true;
  $("#btnDeleteSchedule").classList.toggle("hidden", !s);
  updateScheduleDateVisibility();
  renderScheduleList();
}

async function loadSchedules(){
  try{
    schedules = await apiGet("/api/agendamentos", {loadingText:"Carregando agendamentos…"});
    renderScheduleList();
    if(selectedScheduleId){
      const current = schedules.find(s=>s.id===selectedScheduleId) || null;
      if(current) openScheduleForm(current);
      else closeScheduleForm();
    }else{
      closeScheduleForm();
    }
  }catch(e){ toast(`Não consegui carregar agendamentos: ${e.message}`,true); }
}

// -----------------------------------------------------------------------------
// EVENTOS
// -----------------------------------------------------------------------------
prepararCampoSecreto("#pSecret","#btnEyeSecret","#secretState","configurado");
prepararCampoSecreto("#pApiKey","#btnEyeApiKey","#apiKeyState","configurada");

$("#btnEyeSecret").onclick = ()=>toggleCredentialVisibility({fieldSelector:"#pSecret",buttonSelector:"#btnEyeSecret",apiField:"client_secret",label:"OAuth Secret"});
$("#btnEyeApiKey").onclick = ()=>toggleCredentialVisibility({fieldSelector:"#pApiKey",buttonSelector:"#btnEyeApiKey",apiField:"api_key",label:"Application Key"});

$("#btnRun").onclick = async ()=>{
  if(processRunning) return;
  const periodo = $("#runPeriod").value;
  const ok = await confirmAction({
    title:"Executar automação",
    message:`Executar a coleta da conta ${acct} considerando os pedidos ${periodo === "24h" ? "das últimas 24 horas" : "dos últimos 365 dias"}? A análise comercial roda automaticamente ao final.`,
    confirmText:"Executar"
  });
  if(!ok) return;
  try{
    setRunButton(true);
    $("#console").innerHTML = "";
    logLine(`Solicitando início da automação ${acct}…`,"head");
    await apiPost("/api/automacao/iniciar",{conta:acct,periodo},{loadingText:`Iniciando automação ${acct}…`});
    toast(`Automação ${acct} iniciada`);
  }catch(e){
    setRunButton(false);
    logLine(e.message,"err");
    toast(e.message,true);
  }
};

$("#btnRefresh").onclick = loadAccount;
$("#btnClearLog").onclick = ()=> $("#console").innerHTML = "";

$("#btnLimpar").onclick = async ()=>{
  const ok = await confirmAction({
    title:"Limpar painel",
    message:`Limpar o histórico exibido da conta ${acct}? Pedidos, análises e logs saem do painel. Os arquivos JSON no servidor não são apagados.`,
    confirmText:"Limpar"
  });
  if(!ok) return;
  try{ await apiPost("/api/limpar",{conta:acct},{loadingText:"Limpando painel…"}); toast("Painel limpo"); }
  catch(e){ toast(e.message,true); }
};

$("#acctSwitch").onclick = async e=>{
  const b = e.target.closest("button");
  if(!b || b.dataset.acct === acct) return;

  $$("#acctSwitch button").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");

  acct = b.dataset.acct;
  orderTypeFilter = acct === "POP" ? "Contrato" : "Todos";
  const typeSelect = $("#orderTypeFilter");
  if(typeSelect) typeSelect.value = orderTypeFilter;
  orderPage = 1;

  await loadAccount();
  connectStream();
};

$("#ordBody").onclick = async e=>{
  const validacaoBtn = e.target.closest("[data-functional-validation]");
  if(validacaoBtn){
    e.stopPropagation();

    const id = Number(validacaoBtn.dataset.functionalValidation || 0);
    const decisao = String(validacaoBtn.dataset.functionalDecision || "");
    const codigo = String(validacaoBtn.dataset.functionalCode || "");
    const numero = String(validacaoBtn.dataset.orderNumber || "");

    if(!id || !numero || !["confirmado","rejeitado"].includes(decisao)) return;

    const historico = codigo === "sugestao_historica_matnr";
    let motivo = "";

    if(decisao === "confirmado"){
      const ok = await confirmAction({
        title: historico ? "Confirmar sugestão histórica" : "Confirmar condição",
        message: historico
          ? "Confirmar o MATNR sugerido pelo histórico para este pedido? A decisão ficará registrada e permitirá que essa relação seja considerada válida neste pedido."
          : "Confirmar esta condição para o pedido? A decisão ficará registrada.",
        confirmText: "Confirmar"
      });
      if(!ok) return;
    }else{
      const ok = await confirmAction({
        title: historico ? "Rejeitar sugestão histórica" : "Rejeitar condição",
        message: historico
          ? "Rejeitar esta sugestão? O item ficará em erro e será necessário solicitar o cadastro/correção da relação no SAP."
          : "Confirmar a rejeição desta condição? O pedido continuará bloqueado.",
        confirmText: "Rejeitar"
      });
      if(!ok) return;
      motivo = window.prompt("Motivo da rejeição (opcional):", "") || "";
    }

    try{
      validacaoBtn.disabled = true;
      await apiPost(
        `/api/ordens/${encodeURIComponent(acct)}/${encodeURIComponent(numero)}/validacoes-funcionais/${id}/decidir`,
        {decisao, motivo},
        {loadingText: decisao === "confirmado" ? "Confirmando sugestão…" : "Registrando rejeição…"}
      );

      const data = await apiGet(
        `/api/ordens/${encodeURIComponent(acct)}/${encodeURIComponent(numero)}/uteis`,
        {loading:false}
      );
      uteisCache.set(numero, data);
      orderDetailTabs.set(numero, "comercial");

      // Atualiza também o badge da lista do pedido.
      try{
        const novasOrdens = await apiGet(`/api/ordens?conta=${encodeURIComponent(acct)}`, {loading:false});
        if(Array.isArray(novasOrdens)) orders = novasOrdens;
      }catch{}

      renderOrders();
      toast(
        decisao === "confirmado"
          ? (historico ? "Sugestão histórica confirmada" : "Condição confirmada")
          : (historico ? "Sugestão histórica rejeitada — solicitar cadastro no SAP" : "Condição rejeitada")
      );
    }catch(err){
      validacaoBtn.disabled = false;
      toast(err.message || "Não foi possível registrar a decisão", true);
    }
    return;
  }

  const detalheTab = e.target.closest("[data-order-detail-tab]");
  if(detalheTab){
    e.stopPropagation();
    const numero = detalheTab.dataset.numero;
    const aba = detalheTab.dataset.orderDetailTab;
    if(numero && ["pedido","comercial"].includes(aba)){
      orderDetailTabs.set(numero, aba);
      renderOrders();
    }
    return;
  }

  const itemTab = e.target.closest("[data-analysis-item]");
  if(itemTab){
    e.stopPropagation();
    const numero = itemTab.dataset.numero;
    const linha = itemTab.dataset.analysisItem;
    if(numero){
      orderAnalysisItems.set(numero, linha);
      orderDetailTabs.set(numero, "comercial");
      renderOrders();
    }
    return;
  }

  const reanalisar = e.target.closest(".btn-reanalisar-etapa2");
  if(reanalisar){
    e.stopPropagation();
    if(processRunning || stage2Running) return;
    const numero = reanalisar.dataset.numero;
    if(!numero) return;
    try{
      reanalisar.disabled = true;
      await apiPost(`/api/ordens/${encodeURIComponent(acct)}/${encodeURIComponent(numero)}/reanalisar`, {}, {loadingText:"Agendando nova análise…"});
      uteisCache.delete(numero);
      orderDetailTabs.set(numero, "comercial");
      toast(`Etapa 2 do pedido ${numero} enviada para reanálise`);
    }catch(err){
      toast(err.message || "Não consegui reanalisar a Etapa 2", true);
      reanalisar.disabled = false;
    }
    return;
  }

  const row = e.target.closest(".ord-main");
  if(!row) return;
  const numero = row.dataset.numero;
  if(numero) toggleOrderDetail(numero);
};

$("#ordPagination").onclick = e=>{
  const button = e.target.closest("button");
  if(!button || button.disabled) return;
  const totalPages = Math.max(1,Math.ceil(visibleOrders().length/ORDER_PAGE_SIZE));
  if(button.dataset.page) orderPage = Number(button.dataset.page);
  else if(button.dataset.action === "prev") orderPage = Math.max(1,orderPage-1);
  else if(button.dataset.action === "next") orderPage = Math.min(totalPages,orderPage+1);
  renderOrders();
};

const TITLES = {
  painel:["Painel de execução","Acompanhe a coleta via API e a análise comercial do início ao fim"],
  ordens:["Pedidos coletados","Dados de cada pedido e o resultado da análise comercial"],
  parametros:["Parâmetros","Credenciais da API Ariba e regras usadas na análise comercial"],
  agendamentos:["Agendamentos","Programe execuções únicas ou diárias da automação"]
};

$$(".menu-item").forEach(a=>{
  a.onclick = ()=>{
    $$(".menu-item").forEach(x=>x.classList.remove("active"));
    a.classList.add("active");
    const v = a.dataset.view;
    $$(".view").forEach(x=>x.classList.toggle("active",x.dataset.view===v));
    $("#viewTitle").textContent = TITLES[v][0];
    $("#viewSub").textContent = TITLES[v][1];
    $("#acctSwitch").classList.toggle("hidden", v === "agendamentos");
    if(v === "parametros") loadParametros();
    if(v === "agendamentos") loadSchedules();
  };
});

$("#btnSaveParams").onclick = async ()=>{
  const body = {conta:acct,anid:$("#pAnid").value.trim(),client_id:$("#pClientId").value.trim()};
  if($("#pSecret").dataset.masked !== "1" && $("#pSecret").value.trim()) body.client_secret = $("#pSecret").value.trim();
  if($("#pApiKey").dataset.masked !== "1" && $("#pApiKey").value.trim()) body.api_key = $("#pApiKey").value.trim();
  try{
    await apiPost("/api/parametros",body,{loadingText:"Salvando credenciais…"});
    $("#pSecret").value = "";
    $("#pApiKey").value = "";
    toast(`Credenciais ${acct} salvas`);
    await loadParametros();
  }catch(e){ toast(e.message,true); }
};

$("#scheduleFrequency").onchange = updateScheduleDateVisibility;
$("#btnNewSchedule").onclick = ()=>openScheduleForm(null);
$("#btnCancelSchedule").onclick = closeScheduleForm;
$("#btnCancelScheduleBottom").onclick = closeScheduleForm;
$("#scheduleList").onclick = e=>{
  const row = e.target.closest("[data-schedule-id]");
  if(!row) return;
  const s = schedules.find(x=>x.id===Number(row.dataset.scheduleId));
  if(s) openScheduleForm(s);
};

$("#btnSaveSchedule").onclick = async ()=>{
  const id = Number($("#scheduleId").value || 0);
  const body = {
    conta:$("#scheduleAccount").value,
    periodo:$("#schedulePeriod").value,
    frequencia:$("#scheduleFrequency").value,
    horario:$("#scheduleTime").value,
    data_execucao:$("#scheduleDate").value,
    ativo:$("#scheduleActive").checked
  };
  try{
    if(id) await apiPut(`/api/agendamentos/${id}`,body,{loadingText:"Salvando agendamento…"});
    else{
      const res = await apiPost("/api/agendamentos",body,{loadingText:"Salvando agendamento…"});
      selectedScheduleId = res.id;
    }
    toast("Agendamento salvo");
    await loadSchedules();
  }catch(e){ toast(e.message,true); }
};

$("#btnDeleteSchedule").onclick = async ()=>{
  const id = Number($("#scheduleId").value || 0);
  if(!id) return;
  const ok = await confirmAction({title:"Excluir agendamento",message:"Excluir este agendamento? As próximas execuções dele não acontecerão.",confirmText:"Excluir"});
  if(!ok) return;
  try{
    await apiDelete(`/api/agendamentos/${id}`,{loadingText:"Excluindo agendamento…"});
    selectedScheduleId = null;
    toast("Agendamento excluído");
    await loadSchedules();
  }catch(e){ toast(e.message,true); }
};

(async function boot(){
  await loadAccount();
  connectStream();
})();