# -*- coding: utf-8 -*-
"""Diagnóstico da Etapa 2 para um pedido, direto no terminal do servidor.

Uso (na pasta do Portal, com o mesmo usuário Windows que roda o serviço):

    python diagnostico_etapa2.py POP 4524350067
    python diagnostico_etapa2.py POP 4524350067 --gravar
    python diagnostico_etapa2.py --json "C:\\caminho\\pedido.json"

Mostra:
  - tempo e resultado de cada consulta externa (DCLO, Oracle, DALI);
  - todos os critérios de cada item, com status e motivo;
  - a exceção completa de qualquer consulta que falhar.

--gravar persiste o resultado no Portal, igual ao botão "Reanalisar".
"""

import argparse
import functools
import json
import sys
import time
import traceback

import etapa2_validacao as e2

CONSULTAS = [
    "consultar_knmt", "consultar_historico_kdmat", "consultar_material_pra", "consultar_knvv_pra",
    "consultar_clientes_kna1", "consultar_knvv_multiplos", "consultar_ziad", "tem_ziad_cliente",
    "consultar_znet", "consultar_znet_material", "consultar_parceiros_dali",
]
LOG = []


def _instrumentar():
    for nome in CONSULTAS:
        original = getattr(e2, nome, None)
        if original is None:
            continue

        @functools.wraps(original)
        def wrapper(*args, __fn=original, __nome=nome, **kwargs):
            t0 = time.perf_counter()
            try:
                res = __fn(*args, **kwargs)
                st = res.get("status") if isinstance(res, dict) else (
                    f"{len(res)} registro(s)" if isinstance(res, list) else res)
                LOG.append((__nome, args, time.perf_counter() - t0, "OK", st, None))
                return res
            except Exception:
                LOG.append((__nome, args, time.perf_counter() - t0, "FALHA", None, traceback.format_exc()))
                raise

        setattr(e2, nome, wrapper)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("conta", nargs="?")
    ap.add_argument("numero", nargs="?")
    ap.add_argument("--json", help="Caminho de um JSON de pedido")
    ap.add_argument("--gravar", action="store_true", help="Grava o resultado no Portal")
    args = ap.parse_args()

    import app as portal  # reaproveita conexões e parâmetros do Portal

    if args.json:
        with open(args.json, encoding="utf-8-sig") as fh:
            payload = json.load(fh)
        conta = (payload.get("account") or "").upper()
        numero = str(payload.get("order_number") or "")
    else:
        if not (args.conta and args.numero):
            ap.error("Informe CONTA e NÚMERO, ou --json.")
        conta, numero = args.conta.upper(), args.numero
        payload = portal._ler_payload_etapa2(conta, numero)

    params = dict(
        mapeamentos_pagamento=portal._carregar_mapeamentos_pagamento(),
        mapeamentos_mvke=portal._carregar_mapeamentos_mvke(),
        parametros_clientes=portal._carregar_parametros_clientes(),
        mapeamentos_shipto=portal._carregar_mapeamentos_shipto(),
    )

    _instrumentar()
    t0 = time.perf_counter()
    analise = e2.analisar_pedido(payload, **params)
    total = time.perf_counter() - t0

    print(f"\n=== Pedido {conta}/{numero} — {analise.get('tipo')} — {total:.1f}s ===")
    print("Status:", analise.get("status"), "|", analise.get("resumo"))

    print("\n--- Consultas externas ---")
    for nome, a, dt, ok, st, tb in LOG:
        arg = ", ".join(str(x) for x in a)[:60]
        print(f"{ok:5} {dt:6.2f}s  {nome}({arg}) -> {st}")
        if tb:
            print("      " + tb.strip().replace("\n", "\n      "))

    for it in analise.get("itens") or []:
        print(f"\n--- Item {it['linha']}  MATNR {it.get('matnr') or '—'}  ({it.get('matnr_origem') or '—'})"
              f"  =>  {it['resultado'].upper()}")
        det = it.get("detalhes_validacao") or {}
        for c in (det.get("cliente") or []) + (det.get("item") or []):
            marca = "BLOQ" if c.get("bloqueante") and c.get("status") != "ok" else "    "
            print(f"  {c['status']:11} {marca} {c['label'][:32]:32} {str(c.get('valor'))[:45]:45}")
            if c.get("status") not in ("ok",) and c.get("detalhe"):
                print(f"{'':19}{c['detalhe']}")

    if args.gravar:
        portal._persistir_analise_etapa2(conta, numero, analise)
        print("\nResultado gravado no Portal.")
    return 0


if __name__ == "__main__":
    sys.exit(main())