# -*- coding: utf-8 -*-
"""
Força a reanálise da Etapa 2 de TODOS os pedidos já coletados da conta escolhida.

Coloque este arquivo na mesma pasta do app.py e rode:
    python forcar_reanalise_todos.py --conta POP

Opcional:
    python forcar_reanalise_todos.py --conta ITA
"""

import argparse
import BACKUP.app as portal


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--conta", required=True, choices=["POP", "ITA", "pop", "ita"])
    args = parser.parse_args()

    conta = args.conta.upper()

    if portal.analisar_pedido is None:
        raise RuntimeError(
            "Etapa 2 não carregou: "
            + str(portal.ETAPA2_IMPORT_ERROR or "erro não informado")
        )

    with portal.get_conn() as cn:
        rows = cn.cursor().execute(
            """
            SELECT numero, json_path
            FROM dbo.VEND_Ordem
            WHERE conta = ?
              AND etapa1_status = 'ok'
            ORDER BY numero
            """,
            conta,
        ).fetchall()

    total = len(rows)
    print(f"\n{total} pedido(s) encontrados para {conta}.\n")

    mapas_pagamento = portal._carregar_mapeamentos_pagamento()
    mapas_mvke = portal._carregar_mapeamentos_mvke()
    parametros_clientes = portal._carregar_parametros_clientes()
    mapas_shipto = portal._carregar_mapeamentos_shipto()

    ok = 0
    erros = 0

    for i, row in enumerate(rows, start=1):
        numero = str(row.numero)

        try:
            print(f"[{i}/{total}] Reanalisando {numero}...", flush=True)

            payload = portal._ler_payload_etapa2(conta, numero, row.json_path)

            analise = portal.analisar_pedido(
                payload,
                mapeamentos_pagamento=mapas_pagamento,
                mapeamentos_mvke=mapas_mvke,
                parametros_clientes=parametros_clientes,
                mapeamentos_shipto=mapas_shipto,
            )

            portal._persistir_analise_etapa2(conta, numero, analise)

            print(
                f"    -> {analise.get('status')} | "
                f"{analise.get('resumo') or ''}",
                flush=True,
            )
            ok += 1

        except Exception as exc:
            erros += 1
            print(
                f"    -> ERRO: {type(exc).__name__}: {exc}",
                flush=True,
            )

    print("\n" + "=" * 80)
    print("REANÁLISE FINALIZADA")
    print(f"Conta: {conta}")
    print(f"Total: {total}")
    print(f"Processados: {ok}")
    print(f"Erros: {erros}")
    print("=" * 80)


if __name__ == "__main__":
    main()
