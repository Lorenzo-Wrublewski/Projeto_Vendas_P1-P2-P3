# -*- coding: utf-8 -*-
"""
Lista exemplos reais da KNMT no DCLO usando a MESMA conexão do dclo.py.

Pré-requisito:
- executar no VS Code / sessão Windows do Luigi, onde o acesso ao DCLO funciona.
- manter este arquivo na mesma pasta do dclo.py.
"""

import json
from BACKUP.dclo import get_connection


SQL = """
SELECT TOP 20
       [VKORG],
       [VTWEG],
       [KUNNR],
       [MATNR],
       [KDMAT]
FROM [LO].[CL_KNMT_PRA]
WHERE [VKORG] = 'BR10'
  AND [KUNNR] IS NOT NULL
  AND [KDMAT] IS NOT NULL
  AND [KDMAT] <> ''
  AND [MATNR] IS NOT NULL
  AND [MATNR] <> ''
ORDER BY [KUNNR], [KDMAT];
"""


def main():
    print("=" * 90)
    print("DCLO — EXEMPLOS REAIS KNMT")
    print("=" * 90)

    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(SQL)
        rows = cur.fetchall()

    if not rows:
        print("Nenhum registro encontrado.")
        return

    dados = []
    for r in rows:
        dados.append({
            "vkorg": str(r.VKORG).strip() if r.VKORG is not None else None,
            "vtweg": str(r.VTWEG).strip() if r.VTWEG is not None else None,
            "kunnr": str(r.KUNNR).strip() if r.KUNNR is not None else None,
            "matnr": str(r.MATNR).strip() if r.MATNR is not None else None,
            "kdmat": str(r.KDMAT).strip() if r.KDMAT is not None else None,
        })

    print(json.dumps(dados, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
