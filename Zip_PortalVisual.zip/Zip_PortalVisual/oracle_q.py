# -*- coding: utf-8 -*-

#ORACLE_Q.PY (NAO SEI SE TA SENDO USADO)

"""Acesso Oracle comercial da Etapa 2.



Compatível com o portal_config.json atual (bloco ``oracle``) e preparado para

alternar entre Q/P sem duplicar o código. Em P, KNA1/KNVV usam Q como fallback

técnico porque essas views não estão liberadas para o usuário de produção.



Principais consultas:

- ZNET A813 / A706 / A005 + KONP

- ZIAD A733 + KONP

- KNA1 (candidatos de cliente)

- KNVV (KDGRP / ZTERM)

- DALI KNVP/LFA1 (SP = Transportadora; ZR = Redespacho) em conexão dedicada

- PRODH1 temporário via QMEL para validação técnica



IMPORTANTE: QMEL é usado apenas como fallback técnico para obter PRDHA/PRODH1.

A fonte definitiva deve ser MARA/DCLO quando o acesso estiver disponível.

"""



from __future__ import annotations



import json

import os

import re

import unicodedata

from pathlib import Path



import oracledb





BASE_DIR = Path(__file__).resolve().parent



_CONFIG_CANDIDATES = []

if os.environ.get("PORTAL_CONFIG"):

    _CONFIG_CANDIDATES.append(Path(os.environ["PORTAL_CONFIG"]).expanduser())

_CONFIG_CANDIDATES.extend([

    BASE_DIR / "portal_config.json",

    BASE_DIR / "portal_configs.json",

    BASE_DIR / "portal_config.js",

    BASE_DIR / "portal_configs.js",

])





def _load_portal_config():

    ultimo_erro = None

    for path in _CONFIG_CANDIDATES:

        try:

            path = path.resolve()

            if not path.exists() or not path.is_file():

                continue

            texto = path.read_text(encoding="utf-8-sig").replace("\u00a0", " ")

            data = json.loads(texto)

            if isinstance(data, dict):

                return data, path, None

            ultimo_erro = f"{path}: conteúdo não é um objeto JSON."

        except Exception as exc:

            ultimo_erro = f"{path}: {type(exc).__name__}: {exc}"

    return {}, None, ultimo_erro





_PORTAL_CONFIG, PORTAL_CONFIG_FILE, PORTAL_CONFIG_ERROR = _load_portal_config()

if PORTAL_CONFIG_FILE is None:

    PORTAL_CONFIG_FILE = BASE_DIR / "portal_config.json"



_ORACLE_ROOT = (

    _PORTAL_CONFIG.get("oracle")

    or _PORTAL_CONFIG.get("oracle_q")

    or {}

)



ORACLE_ENV = str(

    os.environ.get("ORACLE_ENV")

    or _ORACLE_ROOT.get("environment")

    or "Q"

).strip().upper()

if ORACLE_ENV not in ("Q", "P"):

    ORACLE_ENV = "Q"





def _merge_env_config(root, env):

    cfg = dict(root or {})

    envs = root.get("environments") if isinstance(root, dict) else None

    if isinstance(envs, dict):

        bloco = envs.get(env) or envs.get(env.lower()) or {}

        if isinstance(bloco, dict):

            cfg.update(bloco)

    return cfg



# =============================================================================
# DALI — CONEXÃO SEPARADA DO ORACLE COMERCIAL
# =============================================================================
#
# O DALI usado para KNVP/LFA1 NÃO é a mesma conexão Oracle de ZNET/ZIAD.
# A conexão validada no SQL Developer usa outro alias TNS (OpsDevSup CI).
# Por isso nunca fazemos fallback silencioso para get_connection(): se o bloco
# ``dali`` não estiver configurado, a consulta deve falhar com mensagem clara.

_DALI_ROOT = _PORTAL_CONFIG.get("dali") if isinstance(_PORTAL_CONFIG.get("dali"), dict) else {}

DALI_USER = str(
    os.environ.get("DALI_USER")
    or _DALI_ROOT.get("user")
    or ""
).strip()

DALI_PASSWORD = str(
    os.environ.get("DALI_PASSWORD")
    or _DALI_ROOT.get("password")
    or ""
)

DALI_DSN = str(
    os.environ.get("DALI_DSN")
    or _DALI_ROOT.get("dsn")
    or _DALI_ROOT.get("tns_alias")
    or ""
).strip()

DALI_CALL_TIMEOUT_MS = int(
    os.environ.get("DALI_CALL_TIMEOUT_MS")
    or _DALI_ROOT.get("call_timeout_ms")
    or _ORACLE_ROOT.get("call_timeout_ms")
    or 60000
)


def get_connection_dali():
    """Abre a conexão Oracle específica do DALI (OpsDevSup CI).

    Importante: Transportadora/Redespacho estão em MARD_DALI_DC e não devem
    usar a conexão Consumer/Common de ZNET/ZIAD.
    """
    if not DALI_USER or not DALI_PASSWORD or not DALI_DSN:
        faltando = []
        if not DALI_USER:
            faltando.append("user")
        if not DALI_PASSWORD:
            faltando.append("password")
        if not DALI_DSN:
            faltando.append("dsn")
        raise RuntimeError(
            "Conexão DALI não configurada. Preencha o bloco 'dali' no "
            "portal_config.json (faltando: " + ", ".join(faltando) + ")."
        )

    conn = oracledb.connect(
        user=DALI_USER,
        password=DALI_PASSWORD,
        dsn=DALI_DSN,
    )
    conn.call_timeout = DALI_CALL_TIMEOUT_MS
    return conn





_ORACLE_CFG = _merge_env_config(_ORACLE_ROOT, ORACLE_ENV)





def _env(name, default=None):

    return (

        os.environ.get(f"ORACLE_{ORACLE_ENV}_{name}")

        or os.environ.get(f"ORACLE_{name}")

        or default

    )





ORACLE_USER = _env("USER", _ORACLE_CFG.get("user") or "")

ORACLE_PASSWORD = _env("PASSWORD", _ORACLE_CFG.get("password") or "")

ORACLE_DSN = _env("DSN", _ORACLE_CFG.get("dsn") or _ORACLE_CFG.get("tns_alias") or "")



_hosts_env = _env("HOSTS", None)

if _hosts_env:

    ORACLE_HOSTS = [x.strip() for x in str(_hosts_env).split(",") if x.strip()]

else:

    _hosts_cfg = _ORACLE_CFG.get("hosts")

    if isinstance(_hosts_cfg, list) and _hosts_cfg:

        ORACLE_HOSTS = [str(h).strip() for h in _hosts_cfg if str(h).strip()]

    else:

        _single = _ORACLE_CFG.get("host") or ""

        ORACLE_HOSTS = [str(_single).strip()] if str(_single).strip() else []



ORACLE_PORT = int(_env("PORT", _ORACLE_CFG.get("port") or 38000))

ORACLE_SERVICE = _env(

    "SERVICE",

    _ORACLE_CFG.get("service_name")

    or ("RLDP01_CON_4.BOSCH.COM" if ORACLE_ENV == "P" else "RLDQ01_CON_4.BOSCH.COM"),

)

ORACLE_CALL_TIMEOUT_MS = int(

    _env("CALL_TIMEOUT_MS", _ORACLE_CFG.get("call_timeout_ms") or 60000)

)

ORACLE_CLIENT_LIB = (

    _env("CLIENT_LIB", None)

    or _ORACLE_CFG.get("oracle_client_lib_dir")

    or _ORACLE_CFG.get("client_lib_dir")

    or r"C:\Oracle\Client64\bin"

)

TNS_ADMIN = (

    os.environ.get("TNS_ADMIN")

    or _ORACLE_CFG.get("tns_admin")

    or ""

)

if TNS_ADMIN:

    os.environ["TNS_ADMIN"] = str(TNS_ADMIN)



if oracledb.is_thin_mode():

    oracledb.init_oracle_client(lib_dir=str(ORACLE_CLIENT_LIB))





def _check_credentials():

    if not ORACLE_USER or not ORACLE_PASSWORD:

        raise RuntimeError(

            f"Credenciais Oracle {ORACLE_ENV} não configuradas. "

            "Configure user/password no bloco oracle ou via variáveis de ambiente."

        )

    if not ORACLE_DSN and not ORACLE_HOSTS:

        raise RuntimeError(

            f"Oracle {ORACLE_ENV} sem DSN/hosts configurados. "

            "Informe dsn/tns_alias ou hosts no portal_config.json."

        )





def get_connection():

    _check_credentials()



    if ORACLE_DSN:

        conn = oracledb.connect(

            user=ORACLE_USER,

            password=ORACLE_PASSWORD,

            dsn=ORACLE_DSN,

        )

        conn.call_timeout = ORACLE_CALL_TIMEOUT_MS

        return conn



    ultimo_erro = None

    for host in ORACLE_HOSTS:

        try:

            params = oracledb.ConnectParams(

                host=host,

                port=ORACLE_PORT,

                service_name=ORACLE_SERVICE,

                server_type="dedicated",

                tcp_connect_timeout=5,

                retry_count=0,

            )

            conn = oracledb.connect(

                user=ORACLE_USER,

                password=ORACLE_PASSWORD,

                params=params,

            )

            conn.call_timeout = ORACLE_CALL_TIMEOUT_MS

            return conn

        except Exception as exc:

            ultimo_erro = exc



    raise RuntimeError(

        f"Não foi possível conectar ao Oracle {ORACLE_ENV}. Último erro: {ultimo_erro}"

    )





def _config_ambiente(env):

    """Monta a configuração Oracle de um ambiente específico sem alterar ORACLE_ENV."""

    env = str(env or "").strip().upper()

    if env not in ("Q", "P"):

        raise ValueError("Ambiente Oracle inválido.")



    cfg = _merge_env_config(_ORACLE_ROOT, env)



    user = (

        os.environ.get(f"ORACLE_{env}_USER")

        or cfg.get("user")

        or _ORACLE_ROOT.get("user")

        or ""

    )

    password = (

        os.environ.get(f"ORACLE_{env}_PASSWORD")

        or cfg.get("password")

        or _ORACLE_ROOT.get("password")

        or ""

    )

    dsn = (

        os.environ.get(f"ORACLE_{env}_DSN")

        or cfg.get("dsn")

        or cfg.get("tns_alias")

        or ""

    )

    service = (

        os.environ.get(f"ORACLE_{env}_SERVICE")

        or cfg.get("service_name")

        or ("RLDP01_CON_4.BOSCH.COM" if env == "P" else "RLDQ01_CON_4.BOSCH.COM")

    )

    port = int(

        os.environ.get(f"ORACLE_{env}_PORT")

        or cfg.get("port")

        or _ORACLE_ROOT.get("port")

        or 38000

    )

    timeout = int(

        os.environ.get(f"ORACLE_{env}_CALL_TIMEOUT_MS")

        or cfg.get("call_timeout_ms")

        or _ORACLE_ROOT.get("call_timeout_ms")

        or 60000

    )



    hosts_cfg = cfg.get("hosts")

    if isinstance(hosts_cfg, list):

        hosts = [str(x).strip() for x in hosts_cfg if str(x).strip()]

    else:

        host = str(cfg.get("host") or "").strip()

        hosts = [host] if host else []



    return {

        "env": env,

        "user": user,

        "password": password,

        "dsn": dsn,

        "service": service,

        "port": port,

        "timeout": timeout,

        "hosts": hosts,

    }





def get_connection_env(env):

    """Abre uma conexão em Q ou P usando o bloco environments do portal_config."""

    cfg = _config_ambiente(env)



    if not cfg["user"] or not cfg["password"]:

        raise RuntimeError(f"Credenciais Oracle {cfg['env']} não configuradas.")



    if cfg["dsn"]:

        conn = oracledb.connect(

            user=cfg["user"],

            password=cfg["password"],

            dsn=cfg["dsn"],

        )

        conn.call_timeout = cfg["timeout"]

        return conn



    if not cfg["hosts"]:

        raise RuntimeError(f"Oracle {cfg['env']} sem DSN/hosts configurados.")



    ultimo_erro = None

    for host in cfg["hosts"]:

        try:

            params = oracledb.ConnectParams(

                host=host,

                port=cfg["port"],

                service_name=cfg["service"],

                server_type="dedicated",

                tcp_connect_timeout=5,

                retry_count=0,

            )

            conn = oracledb.connect(

                user=cfg["user"],

                password=cfg["password"],

                params=params,

            )

            conn.call_timeout = cfg["timeout"]

            return conn

        except Exception as exc:

            ultimo_erro = exc



    raise RuntimeError(

        f"Não foi possível conectar ao Oracle {cfg['env']}. Último erro: {ultimo_erro}"

    )





def _get_connection_cadastro_cliente():

    """

    KNA1/KNVV:

    - em Q: consulta Q normalmente;

    - em P: usa Q como fallback técnico porque o usuário de P não possui

      SELECT em RAWO_B5.V_CUSN_KNA1 / V_CUSN_KNVV (ORA-00942).



    Preço ZNET, ZIAD, KONP e PRODH1 continuam usando o ambiente selecionado.

    """

    return get_connection_env("Q") if ORACLE_ENV == "P" else get_connection()





ZIAD_PREFIXOS = (

    "BRL13", "BRL64", "BRL66",

    "USD13", "USD64", "USD66",

    "EUR13", "EUR64", "EUR66",

)





def _buscar_konp_por_knumh(cur, knumh):

    cur.execute(

        """

        SELECT KONP.KONWA, KONP.KBETR

        FROM RAWB_MS.V_CUSN_KONP_B5 KONP

        WHERE KONP.KNUMH = :knumh

          AND ROWNUM = 1

        """,

        knumh=str(knumh),

    )

    row = cur.fetchone()

    return (row[0], row[1]) if row else (None, None)





def _kunnr_sem_zeros(kunnr):

    texto = str(kunnr or "").strip()

    if texto.isdigit():

        try:

            return str(int(texto))

        except Exception:

            pass

    return texto.lstrip("0") or texto





def _normalizar_texto(value):

    value = str(value or "").strip().upper()

    value = unicodedata.normalize("NFKD", value)

    value = "".join(ch for ch in value if not unicodedata.combining(ch))

    value = re.sub(r"[^A-Z0-9]+", " ", value)

    return " ".join(value.split())





# =============================================================================

# CLIENTE SAP — KNA1 / KNVV

# =============================================================================



def consultar_clientes_kna1(termo, limite=80):

    """Busca candidatos de cliente por nome em KNA1.



    Retorna dados suficientes para o motor da Etapa 2 pontuar endereço/CNPJ.

    """

    termo = _normalizar_texto(termo)

    if not termo:

        return []



    palavras_ignoradas = {

        "COMPANHIA", "EMPRESA", "EMPRESAS", "GRUPO", "USINAS", "SIDERURGICA",

        "SIDERURGICAS", "CORPORATION", "INTERNATIONAL", "LTDA", "SA", "S", "A",

        "DO", "DA", "DE", "DOS", "DAS", "THE", "LLC",

    }

    palavras = [p for p in termo.split() if len(p) >= 3 and p not in palavras_ignoradas]

    if not palavras:

        palavras = [p for p in termo.split() if len(p) >= 3]

    if not palavras:

        return []



    # Prioriza a palavra mais informativa/longa para reduzir o volume.

    token = sorted(palavras, key=lambda x: (-len(x), x))[0]

    limite = max(1, min(int(limite or 80), 200))



    sql = f"""

        SELECT

            KUNNR, NAME1, NAME2, STCD1, STCD2, STRAS,

            ORT01, PSTLZ, REGIO, LAND1

        FROM RAWO_B5.V_CUSN_KNA1

        WHERE (

            UPPER(NAME1) LIKE :termo

            OR UPPER(NAME2) LIKE :termo

        )

          AND ROWNUM <= {limite}

    """



    with _get_connection_cadastro_cliente() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, termo=f"%{token}%")

            rows = cur.fetchall()



    return [

        {

            "kunnr": r[0], "name1": r[1], "name2": r[2], "stcd1": r[3],

            "stcd2": r[4], "stras": r[5], "ort01": r[6], "pstlz": r[7],

            "regio": r[8], "land1": r[9],

        }

        for r in rows

    ]





def consultar_knvv_multiplos(kunnrs):

    valores = []

    vistos = set()

    for k in list(kunnrs or []):

        t = str(k or "").strip()

        if t and t not in vistos:

            vistos.add(t)

            valores.append(t)

    if not valores:

        return {}

    valores = valores[:80]



    binds = {f"k{i}": v for i, v in enumerate(valores)}

    placeholders = ",".join(f":k{i}" for i in range(len(valores)))

    sql = f"""

        SELECT KUNNR, VKORG, VTWEG, SPART, KDGRP, ZTERM

        FROM RAWO_B5.V_CUSN_KNVV

        WHERE KUNNR IN ({placeholders})

    """



    with _get_connection_cadastro_cliente() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, binds)

            rows = cur.fetchall()



    result = {v: [] for v in valores}

    for r in rows:

        result.setdefault(str(r[0]), []).append({

            "kunnr": r[0], "vkorg": r[1], "vtweg": r[2], "spart": r[3],

            "kdgrp": r[4], "zterm": r[5],

        })

    return result





def consultar_knvv(kunnr):

    return consultar_knvv_multiplos([kunnr]).get(str(kunnr), [])





# =============================================================================
# DALI — PARCEIROS (TRANSPORTADORA / REDESPACHO / REPRESENTANTE)
# =============================================================================


def _normalizar_kunnr_dali(kunnr):
    texto = str(kunnr or "").strip()
    if not texto:
        return None
    return texto.zfill(10) if texto.isdigit() else texto.upper()


def _deduplicar_parceiros_dali(rows):
    unicos = {}
    for item in rows:
        chave = (
            str(item.get("parvw") or "").strip().upper(),
            str(item.get("lifnr") or "").strip(),
            str(item.get("name1") or "").strip().upper(),
            str(item.get("knref") or "").strip().upper(),
        )
        unicos.setdefault(chave, item)
    return list(unicos.values())


def _resumir_tipo_parceiro(rows, parvw, referencia_preferida=None):
    itens = [x for x in rows if str(x.get("parvw") or "").strip().upper() == parvw]
    if not itens:
        return {
            "status": "nao_encontrado",
            "registro": None,
            "registros": [],
            "criterio_selecao": None,
        }

    # Quando existe somente um parceiro, não há ambiguidade.
    if len(itens) == 1:
        return {
            "status": "ok",
            "registro": itens[0],
            "registros": itens,
            "criterio_selecao": "unico_registro",
        }

    # O DALI pode ter parceiros diferentes para BR10 e BR20 no mesmo KUNNR.
    # Luigi informou que KNREF pode vir vazio; por isso ele é usado apenas para
    # desempatar quando há múltiplos registros, nunca como filtro obrigatório.
    referencia = str(referencia_preferida or "").strip().upper()
    if referencia:
        padrao = re.compile(rf"(?<![A-Z0-9]){re.escape(referencia)}(?![A-Z0-9])")
        correspondentes = [
            x for x in itens
            if padrao.search(str(x.get("knref") or "").strip().upper())
        ]

        if len(correspondentes) == 1:
            return {
                "status": "ok",
                "registro": correspondentes[0],
                "registros": itens,
                "criterio_selecao": f"KNREF/{referencia}",
            }

        if len(correspondentes) > 1:
            return {
                "status": "ambiguo",
                "registro": None,
                "registros": correspondentes,
                "criterio_selecao": f"KNREF/{referencia}",
            }

    return {
        "status": "ambiguo",
        "registro": None,
        "registros": itens,
        "criterio_selecao": None,
    }


def consultar_parceiros_dali(kunnr, referencia_preferida="BR10"):
    """Consulta parceiros comerciais/logísticos pela fonte DALI validada.

    Regras confirmadas em 29/09/2026:
    - KNVP.PARVW = SP -> Transportadora;
    - KNVP.PARVW = ZR -> Redespacho;
    - para BR10, KNVP.PARVW = YV -> Customer Responsible / Representante;
      o parceiro vem em KNVP.KUNN2 e o nome é resolvido na KNA1_PRA.

    SP/ZR são relacionados funcionalmente pelo KUNNR. Quando há múltiplos
    parceiros logísticos, KNREF é usado somente como critério de desempate
    para a organização preferida (BR10 por padrão).

    Para YV, a consulta é limitada a VKORG=BR10. Registros repetidos nos
    canais são deduplicados por KUNN2. Se houver mais de um KUNN2 distinto,
    o representante permanece ambíguo e nenhum é escolhido automaticamente.
    """
    kunnr = _normalizar_kunnr_dali(kunnr)
    if not kunnr:
        return {
            "status": "sem_kunnr",
            "kunnr": None,
            "fonte": "DALI/MARD_DALI_DC.KNVP_PRA+LFA1_PRA",
            "transportadora_status": "sem_kunnr",
            "transportadora": None,
            "transportadoras": [],
            "redespacho_status": "sem_kunnr",
            "redespacho": None,
            "redespachos": [],
            "representante_status": "sem_kunnr",
            "representante": None,
            "representante_registro": None,
            "representantes": [],
            "representante_fonte": "DALI/MARD_DALI_DC.KNVP_PRA+KNA1_PRA (PARVW=YV, VKORG=BR10)",
            "detalhes": [],
        }

    sql = """
        SELECT KNVP.KUNNR,
               CAST(NULL AS VARCHAR2(4)) AS VKORG,
               CAST(NULL AS VARCHAR2(2)) AS VTWEG,
               KNA1.NAME1 AS CLIENTE_NAME1,
               KNVP.PARVW,
               LFA1.LIFNR,
               LFA1.NAME1 AS PARCEIRO_NAME1,
               LFA1.STCD1,
               LFA1.STCD2,
               KNVP.KNREF
          FROM MARD_DALI_DC.KNVP_PRA KNVP
          LEFT JOIN MARD_DALI_DC.KNA1_PRA KNA1
                 ON KNA1.KUNNR = KNVP.KUNNR
          LEFT JOIN MARD_DALI_DC.LFA1_PRA LFA1
                 ON LFA1.LIFNR = KNVP.LIFNR
         WHERE KNVP.KUNNR = :kunnr
           AND KNVP.PARVW IN ('SP', 'ZR')
         ORDER BY KNVP.PARVW, LFA1.NAME1, LFA1.LIFNR
    """

    detalhes = []
    with get_connection_dali() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, kunnr=kunnr)
            for row in cur.fetchall():
                detalhes.append({
                    "kunnr": row[0],
                    "vkorg": row[1],
                    "vtweg": row[2],
                    "cliente": row[3],
                    "parvw": row[4],
                    "lifnr": row[5],
                    "name1": row[6],
                    "stcd1": row[7],
                    "stcd2": row[8],
                    "knref": row[9],
                })

    detalhes = _deduplicar_parceiros_dali(detalhes)
    sp = _resumir_tipo_parceiro(detalhes, "SP", referencia_preferida)
    zr = _resumir_tipo_parceiro(detalhes, "ZR", referencia_preferida)

    # BR10 usa YV (Customer Responsible) como representante.
    # O vínculo vem em KNVP.KUNN2 e o nome do parceiro é resolvido na KNA1_PRA.
    sql_representante = """
        SELECT KNVP.KUNNR,
               KNVP.VKORG,
               KNVP.VTWEG,
               KNVP.SPART,
               KNVP.PARVW,
               KNVP.PARZA,
               KNVP.KUNN2,
               REP.NAME1,
               REP.NAME2,
               REP.ORT01,
               REP.LAND1,
               KNVP.KNREF
          FROM MARD_DALI_DC.KNVP_PRA KNVP
          LEFT JOIN MARD_DALI_DC.KNA1_PRA REP
                 ON REP.KUNNR = KNVP.KUNN2
         WHERE KNVP.KUNNR = :kunnr
           AND KNVP.VKORG = 'BR10'
           AND KNVP.PARVW = 'YV'
         ORDER BY KNVP.VTWEG, KNVP.SPART, KNVP.PARZA
    """

    representantes_por_kunn2 = {}
    with get_connection_dali() as conn:
        with conn.cursor() as cur:
            cur.execute(sql_representante, kunnr=kunnr)
            for row in cur.fetchall():
                kunnr2 = str(row[6] or "").strip()
                if not kunnr2:
                    continue

                nome1 = str(row[7] or "").strip()
                nome2 = str(row[8] or "").strip()
                nome_completo = " ".join(x for x in (nome1, nome2) if x).strip() or kunnr2

                if kunnr2 not in representantes_por_kunn2:
                    representantes_por_kunn2[kunnr2] = {
                        "kunnr": row[0],
                        "vkorg": row[1],
                        "vtwegs": [],
                        "sparts": [],
                        "parvw": row[4],
                        "parza": row[5],
                        "kunnr2": kunnr2,
                        "name1": nome_completo,
                        "name1_kna1": nome1 or None,
                        "name2_kna1": nome2 or None,
                        "ort01": str(row[9] or "").strip() or None,
                        "land1": str(row[10] or "").strip() or None,
                        "knref": str(row[11] or "").strip() or None,
                    }

                reg = representantes_por_kunn2[kunnr2]
                vtweg = str(row[2] or "").strip()
                spart = str(row[3] or "").strip()
                if vtweg and vtweg not in reg["vtwegs"]:
                    reg["vtwegs"].append(vtweg)
                if spart and spart not in reg["sparts"]:
                    reg["sparts"].append(spart)

    representantes = list(representantes_por_kunn2.values())

    if len(representantes) == 1:
        representante_status = "ok"
        representante_registro = representantes[0]
        representante = representante_registro.get("name1")
    elif len(representantes) > 1:
        representante_status = "ambiguo"
        representante_registro = None
        representante = None
    else:
        representante_status = "nao_encontrado"
        representante_registro = None
        representante = None

    def valor(registro):
        if not registro:
            return None
        return (
            str(registro.get("name1") or "").strip()
            or str(registro.get("lifnr") or "").strip()
            or None
        )

    return {
        "status": "ok",
        "kunnr": kunnr,
        "fonte": "DALI/MARD_DALI_DC.KNVP_PRA+LFA1_PRA",
        "transportadora_status": sp["status"],
        "transportadora": valor(sp["registro"]),
        "transportadora_registro": sp["registro"],
        "transportadoras": sp["registros"],
        "transportadora_criterio_selecao": sp.get("criterio_selecao"),
        "redespacho_status": zr["status"],
        "redespacho": valor(zr["registro"]),
        "redespacho_registro": zr["registro"],
        "redespachos": zr["registros"],
        "redespacho_criterio_selecao": zr.get("criterio_selecao"),
        "representante_status": representante_status,
        "representante": representante,
        "representante_registro": representante_registro,
        "representantes": representantes,
        "representante_fonte": "DALI/MARD_DALI_DC.KNVP_PRA+KNA1_PRA (PARVW=YV, VKORG=BR10)",
        "detalhes": detalhes,
    }


# =============================================================================

# ZNET

# =============================================================================



def consultar_znet(matnr, kunnr):

    sql = """

        SELECT A005.KNUMH, A005.KUNNR, A005.MATNR,

               A005.CONV_DATAB, A005.CONV_DATBI

        FROM RAWB_GEN.V_CUSN_A005_B5 A005

        WHERE A005.KSCHL = 'ZNET'

          AND A005.MATNR = :matnr

          AND A005.KUNNR = LPAD(:kunnr, 10, '0')

          AND A005.CONV_DATAB <= SYSDATE

          AND A005.CONV_DATBI >= SYSDATE

    """

    with get_connection() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, matnr=str(matnr), kunnr=str(kunnr))

            registro = cur.fetchone()

            if not registro:

                return None

            knumh, kunnr_db, matnr_db, datab, datbi = registro

            moeda, preco = _buscar_konp_por_knumh(cur, knumh)

            seletor = _kunnr_sem_zeros(kunnr_db)

            return {

                "origem": "A005_KUNNR",

                "tipo_chave": "KUNNR",

                "seletor": seletor,

                "chave": f"{moeda or ''}{seletor}",

                "knumh": knumh,

                "kunnr": kunnr_db,

                "matnr": matnr_db,

                "conv_datab": datab,

                "conv_datbi": datbi,

                "moeda": moeda,

                "preco": preco,

            }





def consultar_znet_material(matnr, limite_por_fonte=80):

    limite = max(1, min(int(limite_por_fonte or 80), 250))

    fontes = [

        (

            "A813_KDGRP", "KDGRP",

            f"""

            SELECT A813.KNUMH, A813.KDGRP, A813.MATNR,

                   A813.CONV_DATAB, A813.CONV_DATBI

            FROM RAWB_GEN.V_CUSN_A813_B5 A813

            WHERE A813.KSCHL = 'ZNET'

              AND A813.MATNR = :matnr

              AND A813.CONV_DATAB <= SYSDATE

              AND A813.CONV_DATBI >= SYSDATE

              AND ROWNUM <= {limite}

            """,

        ),

        (

            "A706_YR_KONDS", "YR_KONDS",

            f"""

            SELECT A706.KNUMH, A706.YR_KONDS, A706.MATNR,

                   A706.CONV_DATAB, A706.CONV_DATBI

            FROM RAWB_MS.V_CUSN_A706_B5 A706

            WHERE A706.KSCHL = 'ZNET'

              AND A706.MATNR = :matnr

              AND A706.CONV_DATAB <= SYSDATE

              AND A706.CONV_DATBI >= SYSDATE

              AND ROWNUM <= {limite}

            """,

        ),

        (

            "A005_KUNNR", "KUNNR",

            f"""

            SELECT A005.KNUMH, A005.KUNNR, A005.MATNR,

                   A005.CONV_DATAB, A005.CONV_DATBI

            FROM RAWB_GEN.V_CUSN_A005_B5 A005

            WHERE A005.KSCHL = 'ZNET'

              AND A005.MATNR = :matnr

              AND A005.CONV_DATAB <= SYSDATE

              AND A005.CONV_DATBI >= SYSDATE

              AND ROWNUM <= {limite}

            """,

        ),

    ]



    resultados, erros_fontes = [], []

    with get_connection() as conn:

        with conn.cursor() as cur:

            for origem, tipo_chave, sql in fontes:

                try:

                    cur.execute(sql, matnr=str(matnr))

                    registros = cur.fetchall()

                except Exception as exc:

                    erros_fontes.append({"origem": origem, "erro": f"{type(exc).__name__}: {exc}"})

                    continue



                for knumh, seletor_raw, matnr_db, datab, datbi in registros:

                    try:

                        moeda, preco = _buscar_konp_por_knumh(cur, knumh)

                    except Exception as exc:

                        erros_fontes.append({

                            "origem": origem, "knumh": str(knumh),

                            "erro": f"KONP: {type(exc).__name__}: {exc}",

                        })

                        continue



                    seletor = (

                        _kunnr_sem_zeros(seletor_raw)

                        if tipo_chave == "KUNNR"

                        else str(seletor_raw or "").strip()

                    )

                    resultados.append({

                        "origem": origem,

                        "tipo_chave": tipo_chave,

                        "seletor": seletor,

                        "chave": f"{moeda or ''}{seletor}",

                        "knumh": knumh,

                        "kunnr": seletor_raw if tipo_chave == "KUNNR" else None,

                        "matnr": matnr_db,

                        "conv_datab": datab,

                        "conv_datbi": datbi,

                        "moeda": moeda,

                        "preco": preco,

                    })



    unicos = {}

    for r in resultados:

        chave = (

            r.get("origem"), r.get("chave"), str(r.get("matnr")),

            str(r.get("preco")), str(r.get("conv_datab")), str(r.get("conv_datbi")),

        )

        unicos.setdefault(chave, r)

    return {"condicoes": list(unicos.values()), "erros_fontes": erros_fontes}





# =============================================================================

# PRODH1 — TEMPORÁRIO VIA QMEL

# =============================================================================



def consultar_prodh1_material(matnr):

    """Obtém PRODH1 de forma temporária via QMEL.



    Se houver mais de um PRDHA/PRODH1 diferente, retorna status ambiguo e não

    escolhe silenciosamente. Quando MARA/DCLO estiver disponível, esta função

    deve ser substituída pela fonte mestre.

    """

    sql = """

        SELECT DISTINCT MATNR, PRDHA

        FROM RAWO_B5.V_CUSN_QMEL

        WHERE MATNR = :matnr

          AND PRDHA IS NOT NULL

          AND ROWNUM <= 50

    """

    with get_connection() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, matnr=str(matnr))

            rows = cur.fetchall()



    encontrados = []

    for matnr_db, prdha in rows:

        prdha_txt = str(prdha or "").strip()

        if not prdha_txt:

            continue

        encontrados.append({

            "matnr": matnr_db,

            "prdha": prdha_txt,

            "prodh1": prdha_txt[:3] if len(prdha_txt) >= 3 else prdha_txt,

            "fonte": "QMEL_TEMP",

        })



    unicos = {}

    for item in encontrados:

        unicos.setdefault((item["prdha"], item["prodh1"]), item)

    itens = list(unicos.values())

    prodh1s = sorted({x["prodh1"] for x in itens if x.get("prodh1")})



    if not itens:

        return {"status": "nao_encontrado", "prodh1": None, "fonte": "QMEL_TEMP", "detalhes": []}

    if len(prodh1s) != 1:

        return {"status": "ambiguo", "prodh1": None, "fonte": "QMEL_TEMP", "detalhes": itens}

    return {

        "status": "ok",

        "prodh1": prodh1s[0],

        "fonte": "QMEL_TEMP",

        "detalhes": itens,

    }





# =============================================================================

# ZIAD

# =============================================================================



def tem_ziad_cliente(kunnr):

    """Retorna True se existir ao menos uma ZIAD vigente para o cliente."""

    sql = """

        SELECT 1

        FROM RAWB_GEN.V_CUSN_A733_B5 A733

        WHERE A733.KSCHL = 'ZIAD'

          AND A733.KUNNR = LPAD(:kunnr, 10, '0')

          AND A733.CONV_DATAB <= SYSDATE

          AND A733.CONV_DATBI >= SYSDATE

          AND ROWNUM = 1

    """

    with get_connection() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, kunnr=str(kunnr))

            return cur.fetchone() is not None





def consultar_ziad(kunnr, prodh1=None, limite=500):

    limite = max(1, min(int(limite or 500), 1000))

    filtro_prodh1 = " AND A733.PRODH1 = :prodh1" if prodh1 else ""

    sql = f"""

        SELECT A733.KNUMH, A733.KUNNR, A733.PRODH1,

               A733.CONV_DATAB, A733.CONV_DATBI

        FROM RAWB_GEN.V_CUSN_A733_B5 A733

        WHERE A733.KSCHL = 'ZIAD'

          AND A733.KUNNR = LPAD(:kunnr, 10, '0')

          AND A733.CONV_DATAB <= SYSDATE

          AND A733.CONV_DATBI >= SYSDATE

          {filtro_prodh1}

          AND ROWNUM <= {limite}

    """

    sql_desconto = """

        SELECT KONP.KBETR

        FROM RAWB_MS.V_CUSN_KONP_B5 KONP

        WHERE KONP.KNUMH = :knumh

          AND ROWNUM = 1

    """



    binds = {"kunnr": str(kunnr)}

    if prodh1:

        binds["prodh1"] = str(prodh1)



    resultados = []

    with get_connection() as conn:

        with conn.cursor() as cur:

            cur.execute(sql, binds)

            registros = cur.fetchall()

            for knumh, kunnr_db, prodh1_db, datab, datbi in registros:

                cur.execute(sql_desconto, knumh=knumh)

                row = cur.fetchone()

                desconto = None

                if row and row[0] is not None:

                    desconto = (float(row[0]) * -1) / 10

                resultados.append({

                    "knumh": knumh,

                    "kunnr": kunnr_db,

                    "prodh1": prodh1_db,

                    "desconto": desconto,

                    "prefixos": list(ZIAD_PREFIXOS),

                    "conv_datab": datab,

                    "conv_datbi": datbi,

                })



    unicos = {}

    for resultado in resultados:

        chave = (resultado["prodh1"], resultado["desconto"])

        unicos.setdefault(chave, resultado)

    return list(unicos.values())





if __name__ == "__main__":

    print("Config:", PORTAL_CONFIG_FILE)

    if PORTAL_CONFIG_ERROR:

        print("Aviso ao ler config:", PORTAL_CONFIG_ERROR)

    print("Ambiente:", ORACLE_ENV)

    print("Oracle Thick mode:", not oracledb.is_thin_mode())

    print("DSN:", ORACLE_DSN or "—")

    print("Hosts:", ORACLE_HOSTS)

    print("Service:", ORACLE_SERVICE)

    with get_connection() as conn:

        with conn.cursor() as cur:

            cur.execute("SELECT SYS_CONTEXT('USERENV','DB_NAME'), SYS_CONTEXT('USERENV','SERVICE_NAME') FROM DUAL")

            print("Conexão OK:", cur.fetchone())
