#ACHAR_PEDIDO_KNMT.PY (NAO SEI SE TA SENDO USADO)
import json
from pathlib import Path

from BACKUP.order_fields import classificar_tipo
from BACKUP.etapa2_validacao import (
    _resolver_kunnr,
    _kdmat_item,
    _matnr_item,
)
from BACKUP.dclo import consultar_knmt


PEDIDOS = Path(
    r"C:\Users\pel9atb\Documents\ariba_automation_v2 - api\Pedidos Baixados\POP"
)

arquivos = sorted(
    PEDIDOS.rglob("*.json"),
    key=lambda p: p.stat().st_mtime,
    reverse=True
)

print(f"Pedidos encontrados: {len(arquivos)}")
print("Procurando um caso positivo KNMT...\n")


for arquivo in arquivos:

    try:
        payload = json.loads(
            arquivo.read_text(encoding="utf-8-sig")
        )
    except Exception:
        continue

    if classificar_tipo(payload) != "Contrato":
        continue

    numero = payload.get("order_number")

    itens = payload.get("items") or []

    # Só interessa pedido que tenha item SEM MATNR
    itens_sem_matnr = []

    for item in itens:

        if not isinstance(item, dict):
            continue

        matnr = _matnr_item(item)
        kdmat = _kdmat_item(item)

        if not matnr and kdmat:
            itens_sem_matnr.append((item, kdmat))

    if not itens_sem_matnr:
        continue

    print(f"Testando pedido {numero}...")

    # Resolve cliente da mesma forma que a Etapa 2
    try:
        cliente = _resolver_kunnr(payload, [])
    except Exception as exc:
        print(f"  Erro ao identificar cliente: {exc}")
        continue

    kunnr = cliente.get("kunnr")

    if not kunnr:
        print("  KUNNR não identificado.")
        continue

    print(f"  KUNNR: {kunnr}")

    for item, kdmat in itens_sem_matnr:

        print(f"  Testando KDMAT {kdmat}...")

        try:
            knmt = consultar_knmt(
                kdmat,
                kunnr=kunnr
            )
        except Exception as exc:
            print(f"  Erro KNMT: {exc}")
            continue

        if knmt.get("status") == "ok":

            print("\n===================================")
            print("CASO POSITIVO ENCONTRADO!")
            print("===================================")
            print(f"Pedido : {numero}")
            print(f"KUNNR  : {kunnr}")
            print(f"KDMAT  : {kdmat}")
            print(f"MATNR  : {knmt.get('matnr')}")
            print(f"Arquivo: {arquivo}")
            print("===================================")

            raise SystemExit(0)

        print("  Sem correspondência.")


print("\nNenhum caso positivo encontrado.")