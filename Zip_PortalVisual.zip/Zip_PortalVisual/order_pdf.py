# -*- coding: utf-8 -*-
#ORDER_PDF.PY (NAO SEI SE TA SENDO USADO)
"""PDF visual completo dos pedidos coletados pela Automação Ariba."""

from datetime import datetime
from html import escape
from io import BytesIO
from pathlib import Path
import json
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

BLUE = colors.HexColor("#005691")
TEXT = colors.HexColor("#2B2D30")
MUTED = colors.HexColor("#71767C")
BORDER = colors.HexColor("#D0D2D4")
BG = colors.HexColor("#F7F8F9")
WHITE = colors.white

SECTION_LABELS = {
    "order": "Pedido",
    "network": "Rede / SAP Business Network",
    "customer": "Cliente",
    "supplier": "Fornecedor",
    "delivery": "Entrega",
    "commercial": "Comercial",
    "organization": "Organização",
    "additional": "Outras informações",
    "items": "Itens",
    "analysis": "Análise da coleta",
    "source": "Origem / auditoria",
    "raw_api": "Resposta bruta da API",
}

FIELD_LABELS = {
    "order_number": "Número do pedido",
    "schema_version": "Versão do schema",
    "collector_version": "Versão do coletor",
    "account": "Conta",
    "order_key": "Chave do pedido",
    "status": "Status",
    "dashboard_status": "Status no dashboard",
    "document_status": "Status do documento",
    "routing_status": "Status de roteamento",
    "revision": "Revisão",
    "date": "Data",
    "created": "Criado em",
    "amount": "Valor",
    "currency": "Moeda",
    "name": "Nome",
    "cnpj": "CNPJ",
    "anid": "ANID",
    "vendor_id": "Vendor ID",
    "street": "Endereço",
    "city": "Cidade",
    "state": "Estado",
    "postal_code": "CEP",
    "country": "País",
    "quantity": "Quantidade",
    "uom": "Unidade",
    "description": "Descrição",
    "unit_price": "Preço unitário",
    "need_by_date": "Data necessária",
    "requested_delivery_date": "Data solicitada de entrega",
    "requested_shipment_date": "Data solicitada de envio",
    "customer_part_number": "Código / material do cliente",
    "supplier_part_number": "Código do fornecedor",
    "rexroth_part_number": "Código Rexroth",
    "line_number": "Linha",
    "payment_terms": "Condição de pagamento",
    "payment_terms_code": "Código da condição de pagamento",
    "payment_terms_description": "Descrição da condição de pagamento",
    "payment_terms_detail": "Condição de pagamento completa",
    "transport_terms": "Condição de transporte",
    "delivery_terms": "Condição de entrega",
    "incoterms": "Incoterms",
    "purchase_group": "Grupo de compras",
    "purchase_organization": "Organização de compras",
    "company_code": "Company Code",
}


def _p(text, style):
    return Paragraph(escape(str(text), quote=False), style)


def _label_for(path):
    leaf = re.sub(r"\[\d+\]$", "", str(path).split(".")[-1])
    if leaf in FIELD_LABELS:
        return FIELD_LABELS[leaf]
    human = leaf.replace("_", " ")
    human = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", human)
    human = re.sub(r"\s+", " ", human).strip()
    return human[:1].upper() + human[1:] if human else str(path)


def _value_text(value):
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "Sim" if value else "Não"
    if isinstance(value, float):
        return f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, default=str)
    text = str(value).strip()
    return text if text else "-"


def _flatten_all(value, prefix=""):
    """Converte qualquer estrutura JSON em folhas sem descartar chaves/valores."""
    rows = []
    if isinstance(value, dict):
        if not value:
            return [(prefix, {})]
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            rows.extend(_flatten_all(child, path))
        return rows
    if isinstance(value, list):
        if not value:
            return [(prefix, [])]
        for idx, child in enumerate(value, start=1):
            path = f"{prefix}[{idx}]" if prefix else f"[{idx}]"
            rows.extend(_flatten_all(child, path))
        return rows
    return [(prefix, value)]


def build_order_pdf(payload, *, logo_path=None, account=None):
    """
    Retorna bytes de um PDF com TODO o conteúdo presente no JSON final.

    Não existe filtragem por cliente. O documento percorre dinamicamente todas
    as chaves, inclusive campos novos que a SAP/API passe a retornar no futuro.
    """
    payload = payload if isinstance(payload, dict) else {}
    buffer = BytesIO()
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "OrderTitle", parent=styles["Heading1"], fontName="Helvetica-Bold",
        fontSize=18, leading=22, textColor=TEXT, spaceAfter=4,
    )
    subtitle_style = ParagraphStyle(
        "Subtitle", parent=styles["Normal"], fontName="Helvetica",
        fontSize=8.5, leading=11, textColor=MUTED,
    )
    section_style = ParagraphStyle(
        "Section", parent=styles["Heading2"], fontName="Helvetica-Bold",
        fontSize=11, leading=14, textColor=BLUE, spaceBefore=8, spaceAfter=6,
    )
    cell_style = ParagraphStyle(
        "Cell", parent=styles["Normal"], fontName="Helvetica",
        fontSize=8.2, leading=10.5, textColor=TEXT,
    )
    label_style = ParagraphStyle(
        "CellLabel", parent=cell_style, fontName="Helvetica-Bold", textColor=MUTED,
    )
    path_style = ParagraphStyle(
        "Path", parent=cell_style, fontName="Helvetica", fontSize=6.6,
        leading=8, textColor=MUTED,
    )
    item_title_style = ParagraphStyle(
        "ItemTitle", parent=cell_style, fontName="Helvetica-Bold",
        textColor=WHITE, fontSize=9,
    )

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=16 * mm,
        leftMargin=16 * mm,
        topMargin=16 * mm,
        bottomMargin=18 * mm,
        title=f"Pedido {payload.get('order_number') or ''}",
        author="Automação Ariba - Bosch Rexroth",
    )
    story = []

    logo = Path(logo_path) if logo_path else None
    if logo and logo.exists():
        try:
            left = Image(str(logo), width=42 * mm, height=14 * mm, kind="proportional")
        except Exception:
            left = _p("Bosch Rexroth", title_style)
    else:
        left = _p("Bosch Rexroth", title_style)

    right = Paragraph(
        "<b>Automação Ariba</b><br/><font size='8' color='#71767C'>Pedido coletado via SAP Business Network API</font>",
        ParagraphStyle("HeaderRight", parent=cell_style, alignment=TA_RIGHT, fontSize=11, leading=14),
    )
    header = Table([[left, right]], colWidths=[85 * mm, 90 * mm])
    header.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, -1), 2, BLUE),
    ]))
    story.extend([header, Spacer(1, 8 * mm)])

    order_number = payload.get("order_number") or "Pedido"
    story.append(_p(f"Pedido {order_number}", title_style))
    meta = []
    if account or payload.get("account"):
        meta.append(f"Conta: {account or payload.get('account')}")
    customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
    if customer.get("name"):
        meta.append(f"Cliente: {customer.get('name')}")
    meta.append(f"PDF gerado em: {datetime.now():%d/%m/%Y %H:%M}")
    story.append(_p("  |  ".join(meta), subtitle_style))
    story.append(Spacer(1, 6 * mm))

    def add_pairs(title, pairs, *, show_path=False):
        if not pairs:
            return
        story.append(_p(title, section_style))
        rows = []
        for path, value in pairs:
            label = _label_for(path)
            if show_path and path:
                label_flow = [
                    _p(label, label_style),
                    _p(path, path_style),
                ]
            else:
                label_flow = _p(label, label_style)
            rows.append([
                label_flow,
                _p(_value_text(value), cell_style),
            ])
        table = Table(rows, colWidths=[62 * mm, 113 * mm], hAlign="LEFT", splitByRow=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), BG),
            ("BOX", (0, 0), (-1, -1), .5, BORDER),
            ("INNERGRID", (0, 0), (-1, -1), .35, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 7),
            ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.extend([table, Spacer(1, 3 * mm)])

    # Todos os campos escalares do nível raiz entram na identificação.
    root_pairs = []
    for key, value in payload.items():
        if not isinstance(value, (dict, list)):
            root_pairs.append((str(key), value))
    add_pairs("Identificação", root_pairs, show_path=True)

    # Demais estruturas são renderizadas dinamicamente, sem whitelist.
    for key, value in payload.items():
        if not isinstance(value, (dict, list)):
            continue

        title = SECTION_LABELS.get(str(key), str(key).replace("_", " ").capitalize())

        if key == "items" and isinstance(value, list):
            story.append(_p(title, section_style))
            if not value:
                add_pairs("Itens", [("items", [])], show_path=True)
                continue
            for index, item in enumerate(value, start=1):
                item_header = Table([[_p(f"Item {index}", item_title_style)]], colWidths=[175 * mm])
                item_header.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), BLUE),
                    ("BOX", (0, 0), (-1, -1), .5, BLUE),
                    ("LEFTPADDING", (0, 0), (-1, -1), 7),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ]))
                story.append(item_header)
                pairs = _flatten_all(item, "items")
                rows = []
                for path, item_value in pairs:
                    rows.append([
                        [_p(_label_for(path), label_style), _p(path, path_style)],
                        _p(_value_text(item_value), cell_style),
                    ])
                table = Table(rows, colWidths=[62 * mm, 113 * mm], hAlign="LEFT", splitByRow=1)
                table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (0, -1), BG),
                    ("BOX", (0, 0), (-1, -1), .5, BORDER),
                    ("INNERGRID", (0, 0), (-1, -1), .35, BORDER),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 7),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ]))
                story.extend([table, Spacer(1, 4 * mm)])
            continue

        add_pairs(title, _flatten_all(value, str(key)), show_path=True)

    if not payload:
        story.append(_p("O JSON está vazio.", subtitle_style))

    def footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setStrokeColor(BLUE)
        canvas.setLineWidth(.7)
        canvas.line(16 * mm, 12 * mm, 194 * mm, 12 * mm)
        canvas.setFillColor(MUTED)
        canvas.setFont("Helvetica", 7.5)
        canvas.drawString(16 * mm, 7.5 * mm, "Automação Ariba - Bosch Rexroth")
        canvas.drawRightString(194 * mm, 7.5 * mm, f"Página {doc_obj.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buffer.getvalue()
