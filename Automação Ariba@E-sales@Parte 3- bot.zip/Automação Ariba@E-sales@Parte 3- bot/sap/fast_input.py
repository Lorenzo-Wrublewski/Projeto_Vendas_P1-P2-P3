from __future__ import annotations

import time
from datetime import date, datetime
from decimal import Decimal

from playwright.sync_api import Locator, Page

from sap.locator import resolver, resolver_candidatos


FAST_FILL_TIMEOUT_MS = 900


def _formatar(valor) -> str:
    if valor is None:
        return ""
    if isinstance(valor, datetime):
        return valor.strftime("%m/%d/%Y")
    if isinstance(valor, date):
        return valor.strftime("%m/%d/%Y")
    if isinstance(valor, Decimal):
        texto = format(valor, "f")
        return texto.rstrip("0").rstrip(".") or "0"
    return str(valor)


def _resolver(page: Page, spec: dict | list[dict]) -> Locator:
    if isinstance(spec, list):
        return resolver_candidatos(page, spec)
    return resolver(page, spec)


def _editor(locator: Locator) -> Locator:
    """
    Resolve o editor sem focus(), sem wait_for() e sem timeout longo.
    Os IDs fixos da VA01 normalmente já apontam para o próprio input.
    """
    try:
        tag = locator.evaluate(
            "el => (el.tagName || '').toLowerCase()"
        )
        if tag in {"input", "textarea"}:
            return locator
    except Exception:
        pass

    filho = locator.locator(
        "input:not([type='hidden']), textarea, [contenteditable='true']"
    )

    if filho.count() > 0:
        return filho.first

    # Não fica 2,5 s tentando focar wrapper.
    raise RuntimeError(
        "Campo fixo foi localizado, mas não possui editor direto."
    )


def _snapshot_reacao(page: Page) -> dict:
    """
    UMA chamada JS barata para verificar se apareceu algo que exija reação.
    Não varre estado completo da tela.
    """
    try:
        return page.evaluate(
            """
            () => {
                const visible = el => {
                    if (!el) return false;
                    const s = getComputedStyle(el);
                    const r = el.getBoundingClientRect();
                    return (
                        s.display !== 'none' &&
                        s.visibility !== 'hidden' &&
                        Number(s.opacity || 1) !== 0 &&
                        r.width > 0 &&
                        r.height > 0
                    );
                };

                const loading =
                    visible(document.getElementById('ur-loading-box')) ||
                    visible(document.getElementById('ur-loading-itm2'));

                const popup = [
                    ...document.querySelectorAll('[id$="-close"]')
                ].some(visible);

                const status = (
                    document.getElementById('wnd[0]/sbar_msg-txt')
                        ?.textContent || ''
                ).trim();

                // ATP só é investigado se já existir botão Copy.
                let atp = false;
                if (document.querySelector('[title="Copy"]')) {
                    const txt = document.body?.textContent || '';
                    atp = (
                        txt.includes('Complete delivery') &&
                        txt.includes('Open Quantity') &&
                        txt.includes('Req.deliv.date')
                    );
                }

                return {loading, popup, status, atp};
            }
            """
        ) or {}
    except Exception:
        return {}


def _reagir_so_se_precisar(
    page: Page,
    runtime,
    *,
    contexto: str,
) -> None:
    """
    Se não apareceu NADA, retorna imediatamente.
    Só chama o observador completo quando há evidência real.
    """
    snap = _snapshot_reacao(page)

    status = str(snap.get("status") or "").strip()
    status_novo = bool(
        status and status != getattr(runtime, "_last_status_text", "")
    )

    if not (
        snap.get("loading")
        or snap.get("popup")
        or snap.get("atp")
        or status_novo
    ):
        return

    runtime.reagir_rapido(
        contexto=contexto,
        auto_reenter=True,
    )


def preencher_fixo_imediato(
    page: Page,
    runtime,
    spec: dict | list[dict],
    valor,
    *,
    nome_campo: str,
    contexto: str,
) -> Locator:
    """
    Caminho rápido para campos fixos já visíveis da VA01.

    Fluxo:
      localiza campo
      -> fill
      -> verifica valor no DOM
      -> PRÓXIMO INPUT IMEDIATAMENTE

    Não verifica loading/popup/status entre simples inputs.
    Essas verificações acontecem somente após ações de confirmação
    (Enter, botão, Create, Save, Tab que confirma edição etc.).
    Sem sleep.
    Sem timeout de 2,5 s por campo.
    """
    ini = time.monotonic()

    runtime.heartbeat.assert_owned()

    # REGRA DE PERFORMANCE:
    # input de campo fixo NÃO dispara verificação do SAP.
    # Apenas localiza, preenche, confirma o valor no DOM e segue.
    locator = _resolver(page, spec)

    if locator.count() <= 0:
        raise RuntimeError(
            f"Campo fixo {nome_campo!r} não encontrado."
        )

    editor = _editor(locator)
    esperado = _formatar(valor).strip()

    limite = editor.evaluate(
        """
        el => {
            const raw = el.getAttribute?.('maxlength');
            if (raw === null || raw === undefined || raw === '') {
                return null;
            }
            const n = Number(raw);
            return Number.isFinite(n) ? n : null;
        }
        """
    )

    esperado_dom = esperado
    if (
        limite is not None
        and int(limite) >= 0
        and len(esperado_dom) > int(limite)
    ):
        esperado_dom = esperado_dom[:int(limite)]

    editor.fill(
        esperado,
        timeout=FAST_FILL_TIMEOUT_MS,
    )

    atual = str(
        editor.evaluate(
            "el => String(('value' in el ? el.value : el.textContent) ?? '')"
        )
        or ""
    ).strip()

    if atual != esperado_dom:
        # Uma única repetição imediata; sem espera artificial.
        editor.fill(
            esperado,
            timeout=FAST_FILL_TIMEOUT_MS,
        )

        atual = str(
            editor.evaluate(
                "el => String(('value' in el ? el.value : el.textContent) ?? '')"
            )
            or ""
        ).strip()

    if atual != esperado_dom:
        raise RuntimeError(
            "Campo fixo não confirmou valor. "
            f"Campo={nome_campo!r}; "
            f"esperado={esperado_dom!r}; atual={atual!r}"
        )

    # NÃO verifica loading/popup/status após simples input.
    # O próximo input começa imediatamente.
    runtime.logger(
        f"[FAST] {nome_campo} = {atual!r} "
        f"({time.monotonic() - ini:.3f}s)"
    )

    return locator


def preencher_fixos_em_sequencia(
    page: Page,
    runtime,
    campos: list[tuple[str, dict | list[dict], object]],
    *,
    contexto: str,
) -> dict[str, Locator]:
    """
    Preenche vários campos fixos sem qualquer espera entre eles
    quando o SAP não apresenta reação.
    """
    resultado: dict[str, Locator] = {}

    for nome, spec, valor in campos:
        resultado[nome] = preencher_fixo_imediato(
            page,
            runtime,
            spec,
            valor,
            nome_campo=nome,
            contexto=contexto,
        )

    return resultado
