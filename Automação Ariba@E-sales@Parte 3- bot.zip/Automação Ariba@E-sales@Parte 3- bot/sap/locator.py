from __future__ import annotations

from playwright.sync_api import Locator, Page


FAST_LOOKUP_TIMEOUT_MS = 2500


def _xpath_literal(texto: str) -> str:
    if "'" not in texto:
        return f"'{texto}'"

    if '"' not in texto:
        return f'"{texto}"'

    partes = texto.split("'")
    return "concat(" + ", \"'\", ".join(
        f"'{parte}'" for parte in partes
    ) + ")"


def _root(page: Page, spec: dict):
    scope_css = spec.get("scope_css")

    if scope_css:
        return page.locator(scope_css)

    return page


def _aplicar_indice(locator: Locator, spec: dict) -> Locator:
    if "index" in spec:
        return locator.nth(int(spec["index"]))

    if spec.get("last"):
        return locator.last

    return locator.first



def _css_attr(texto: str) -> str:
    return (
        str(texto)
        .replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\A ")
        .replace("\r", "")
    )


def _role_fast(root, spec: dict) -> Locator | None:
    """
    Tenta resolver textboxes diretamente pelo DOM antes de usar
    a árvore de acessibilidade do Playwright.

    SAP WebGUI possui DOM muito grande; get_by_role pode ser caro.
    """
    role = str(spec.get("role") or "")
    name = spec.get("name")

    if role != "textbox" or not name:
        return None

    nome = _css_attr(str(name))
    exact = bool(spec.get("exact", False))
    op = "=" if exact else "*="

    selector = ", ".join(
        (
            f'input[aria-label{op}"{nome}"]',
            f'textarea[aria-label{op}"{nome}"]',
            f'[role="textbox"][aria-label{op}"{nome}"]',
            f'input[title{op}"{nome}"]',
            f'textarea[title{op}"{nome}"]',
            f'[role="textbox"][title{op}"{nome}"]',
        )
    )

    try:
        fast = root.locator(selector)

        if fast.count() > 0:
            return _aplicar_indice(
                fast,
                spec,
            )
    except Exception:
        pass

    return None


def _title_fast(root, spec: dict) -> Locator | None:
    title = spec.get("title")

    if not title:
        return None

    value = _css_attr(str(title))
    op = "=" if spec.get("exact", False) else "*="

    try:
        fast = root.locator(
            f'[title{op}"{value}"]'
        )

        if fast.count() > 0:
            return _aplicar_indice(
                fast,
                spec,
            )
    except Exception:
        pass

    return None

def resolver(page: Page, spec: dict) -> Locator:
    tipo = spec["type"]
    root = _root(page, spec)

    if tipo == "role":
        fast = _role_fast(
            root,
            spec,
        )

        if fast is not None:
            return fast

        # Fallback 100% compatível com o comportamento anterior.
        return _aplicar_indice(
            root.get_by_role(
                spec["role"],
                name=spec.get("name"),
                exact=spec.get("exact", False),
            ),
            spec,
        )

    if tipo == "title":
        fast = _title_fast(
            root,
            spec,
        )

        if fast is not None:
            return fast

        return _aplicar_indice(
            root.get_by_title(
                spec["title"],
                exact=spec.get("exact", False),
            ),
            spec,
        )

    if tipo == "text":
        return _aplicar_indice(
            root.get_by_text(
                spec["text"],
                exact=spec.get("exact", False),
            ),
            spec,
        )

    if tipo == "css":
        return _aplicar_indice(
            root.locator(spec["selector"]),
            spec,
        )

    if tipo == "xpath":
        return _aplicar_indice(
            root.locator(
                f'xpath={spec["selector"]}'
            ),
            spec,
        )

    if tipo == "id":
        value = spec["id"].replace('"', '\\"')
        return _aplicar_indice(
            root.locator(
                f'[id="{value}"]'
            ),
            spec,
        )

    if tipo == "label_input":
        label = _xpath_literal(
            spec["label"]
        )
        label_index = int(
            spec.get("label_index", 1)
        )
        input_index = int(
            spec.get("input_index", 1)
        )

        xpath = (
            f"(//*[normalize-space(text())={label}])"
            f"[{label_index}]"
            f"/following::input"
            f"[not(@type='hidden')]"
            f"[{input_index}]"
        )

        return _aplicar_indice(
            root.locator(
                f"xpath={xpath}"
            ),
            spec,
        )

    raise ValueError(
        f"Tipo de locator não suportado: {tipo}"
    )


def resolver_candidatos(
    page: Page,
    specs: list[dict],
) -> Locator:
    ultimo = None

    for spec in specs:
        locator = resolver(page, spec)
        ultimo = locator

        try:
            # count() não espera timeout grande.
            if locator.count() > 0:
                return locator
        except Exception:
            continue

    if ultimo is None:
        raise RuntimeError(
            "Lista de seletores vazia."
        )

    return ultimo


def visivel(page: Page, spec: dict) -> bool:
    try:
        locator = resolver(page, spec)

        if locator.count() == 0:
            return False

        return locator.is_visible(
            timeout=300
        )
    except Exception:
        return False


def esperar_visivel(
    page: Page,
    spec: dict,
    timeout_ms: int = FAST_LOOKUP_TIMEOUT_MS,
) -> Locator:
    locator = resolver(page, spec)
    locator.wait_for(
        state="visible",
        timeout=timeout_ms,
    )
    return locator
