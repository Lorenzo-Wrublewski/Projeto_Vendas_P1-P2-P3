from __future__ import annotations

import time
from dataclasses import dataclass

from playwright.sync_api import Page

from sap.loading import _loader_visivel, aguardar_sap_pronto


@dataclass
class PopupSap:
    texto: str
    titulo: str


def _snapshot_popup(page: Page) -> dict | None:
    """
    Detecta qualquer popup SAP REAL pelo X visível.

    Não depende do programa SAP que gerou o popup:
      SAPMSSY...
      SAPLSPO...
      SAPMSDYP...
      etc.

    Regra:
      qualquer elemento visível cujo id termine em "-close".
    """
    try:
        return page.evaluate(
            """
            () => {
                const visible = el => {
                    if (!el) return false;

                    const s = getComputedStyle(el);
                    const r = el.getBoundingClientRect();

                    return (
                        s.display !== 'none' &&
                        s.visibility !== 'hidden' &&
                        Number(s.opacity || 1) !== 0 &&
                        r.width > 0 &&
                        r.height > 0
                    );
                };

                const closes = [
                    ...document.querySelectorAll(
                        'button[id$="-close"], [id$="-close"]'
                    )
                ]
                .filter(visible)
                .map(el => {
                    const m = el.id.match(/_(\\d+)-close$/);

                    return {
                        el,
                        id: el.id,
                        index: m ? Number(m[1]) : 1
                    };
                })
                .filter(x => x.index > 0)
                .sort((a, b) => b.index - a.index);

                if (!closes.length) {
                    return null;
                }

                const atual = closes[0];

                const root =
                    atual.el.closest('[ct="PW"]') ||
                    atual.el.closest('.lsPopupWindow') ||
                    atual.el.closest('.urPWOuterBorder') ||
                    atual.el.parentElement?.parentElement?.parentElement ||
                    null;

                let title = '';
                let text = '';

                if (root) {
                    text = (
                        root.innerText ||
                        root.textContent ||
                        ''
                    ).trim();

                    const titleEl =
                        root.querySelector('[id$="-ttltxt"]') ||
                        root.querySelector('.urPWTitle') ||
                        root.querySelector('[role="heading"]');

                    if (titleEl) {
                        title = (
                            titleEl.innerText ||
                            titleEl.textContent ||
                            ''
                        ).trim();
                    }

                    if (!title && text) {
                        title = text
                            .split(/\\r?\\n/)
                            .map(x => x.trim())
                            .find(Boolean) || '';
                    }
                }

                return {
                    close_id: atual.id,
                    window_index: atual.index,
                    title,
                    text
                };
            }
            """
        )
    except Exception:
        return None


def popup_visivel(page: Page) -> bool:
    return _snapshot_popup(page) is not None


def _fingerprint(snap: dict | None) -> str:
    if snap is None:
        return ""

    return "|".join(
        (
            str(snap.get("close_id") or ""),
            str(snap.get("title") or ""),
            str(snap.get("text") or "")[:1000],
        )
    )


def _aguardar_mudar_ou_sumir(
    page: Page,
    *,
    fingerprint_anterior: str,
    heartbeat=None,
    timeout_ms: int,
) -> dict | None:
    """
    Confirma continuamente que o popup:
      - sumiu; ou
      - foi substituído por outro.

    Retorna imediatamente quando isso acontecer.
    """
    limite = time.monotonic() + timeout_ms / 1000

    while time.monotonic() < limite:
        if heartbeat is not None:
            heartbeat.assert_owned()

        atual = _snapshot_popup(page)

        if atual is None:
            return None

        if _fingerprint(atual) != fingerprint_anterior:
            return atual

        time.sleep(0.025)

    return _snapshot_popup(page)


def _is_cancel_order_processing(snap: dict | None) -> bool:
    if snap is None:
        return False

    titulo = str(snap.get("title") or "").strip().casefold()
    texto = str(snap.get("text") or "").strip().casefold()

    return (
        "cancel order processing" in titulo
        or (
            "do you want to cancel" in texto
            and "all entries will be lost" in texto
        )
    )


def _clicar_no_cancelamento(
    page: Page,
    snap: dict,
    *,
    heartbeat=None,
) -> dict | None:
    """
    Recuperação segura caso o SAP abra:
        Cancel Order Processing
        Do you want to cancel?

    A automação normal nunca deve confirmar cancelamento da VA01.
    Portanto a ação segura é clicar explicitamente em "No".

    IMPORTANTE:
      - não usa Escape;
      - não usa atalho de teclado;
      - não clica em "Yes";
      - só atua quando o popup foi identificado semanticamente.
    """
    fp = _fingerprint(snap)

    candidatos = [
        page.get_by_role("button", name="No", exact=True),
        page.get_by_text("No", exact=True),
    ]

    for locator in candidatos:
        try:
            count = locator.count()
        except Exception:
            count = 0

        for i in range(count):
            item = locator.nth(i)

            try:
                if not item.is_visible(timeout=100):
                    continue

                # Confirma que ainda é o MESMO popup antes do clique.
                atual = _snapshot_popup(page)

                if (
                    atual is None
                    or _fingerprint(atual) != fp
                    or not _is_cancel_order_processing(atual)
                ):
                    return atual

                item.click(
                    timeout=1200,
                    force=True,
                )

                return _aguardar_mudar_ou_sumir(
                    page,
                    fingerprint_anterior=fp,
                    heartbeat=heartbeat,
                    timeout_ms=2500,
                )
            except Exception:
                continue

    raise RuntimeError(
        "Popup 'Cancel Order Processing' detectado, "
        "mas o botão 'No' não pôde ser acionado com segurança."
    )


def _aguardar_reacao_do_x(
    page: Page,
    *,
    fingerprint_anterior: str,
    heartbeat=None,
    timeout_ms: int = 2500,
) -> dict | None:
    """
    Aguarda a reação do clique no X sem enviar nenhuma tecla.

    Se o clique disparar loading, espera o loading terminar antes de
    decidir se o popup realmente continuou aberto.
    """
    limite = time.monotonic() + timeout_ms / 1000

    while time.monotonic() < limite:
        if heartbeat is not None:
            heartbeat.assert_owned()

        atual = _snapshot_popup(page)

        if atual is None:
            return None

        if _fingerprint(atual) != fingerprint_anterior:
            return atual

        # O X pode disparar um roundtrip lento. Nesse caso NÃO fazemos
        # retry e, principalmente, NÃO enviamos Escape.
        if _loader_visivel(page):
            aguardar_sap_pronto(
                page,
                heartbeat=heartbeat,
                appearance_grace_ms=0,
                stable_ms=60,
            )

            atual = _snapshot_popup(page)

            if (
                atual is None
                or _fingerprint(atual) != fingerprint_anterior
            ):
                return atual

        time.sleep(0.025)

    return _snapshot_popup(page)


def _clicar_x_real(
    page: Page,
    snap: dict,
    *,
    heartbeat=None,
) -> dict | None:
    """
    Fecha SOMENTE o popup detectado, pelo X exato dele.

    Regra de segurança crítica:
      NUNCA usa Escape como fallback.

    No SAP WebGUI/VA01, Escape pode chegar à tela principal depois
    que um popup fecha e disparar "Cancel Order Processing".
    """
    close_id = str(
        snap.get("close_id") or ""
    )

    if not close_id:
        raise RuntimeError(
            "Popup SAP detectado sem ID do botão X."
        )

    fp = _fingerprint(snap)

    # Até 3 tentativas, sempre verificando antes que o MESMO popup
    # continue realmente aberto. Nenhum clique é feito "às cegas".
    for tentativa in range(1, 4):
        if heartbeat is not None:
            heartbeat.assert_owned()

        atual = _snapshot_popup(page)

        if atual is None:
            return None

        if _fingerprint(atual) != fp:
            return atual

        if _is_cancel_order_processing(atual):
            return _clicar_no_cancelamento(
                page,
                atual,
                heartbeat=heartbeat,
            )

        # Se o SAP já entrou em loading por causa de uma tentativa
        # anterior, espera terminar antes de qualquer novo clique.
        if _loader_visivel(page):
            aguardar_sap_pronto(
                page,
                heartbeat=heartbeat,
                appearance_grace_ms=0,
                stable_ms=60,
            )

            atual = _snapshot_popup(page)

            if (
                atual is None
                or _fingerprint(atual) != fp
            ):
                return atual

        try:
            x = page.locator(
                f'[id="{close_id}"]'
            )

            if (
                x.count() > 0
                and x.first.is_visible(timeout=100)
            ):
                x.first.click(
                    timeout=1200,
                    force=True,
                )
        except Exception:
            pass

        atual = _aguardar_reacao_do_x(
            page,
            fingerprint_anterior=fp,
            heartbeat=heartbeat,
            timeout_ms=2500,
        )

        if (
            atual is None
            or _fingerprint(atual) != fp
        ):
            return atual

        # Última tentativa: mouse físico, mas SOMENTE se o mesmo
        # popup e o mesmo X ainda estiverem presentes.
        if tentativa == 3:
            try:
                atual = _snapshot_popup(page)

                if (
                    atual is None
                    or _fingerprint(atual) != fp
                ):
                    return atual

                x = page.locator(
                    f'[id="{close_id}"]'
                )

                if (
                    x.count() > 0
                    and x.first.is_visible(timeout=100)
                ):
                    box = x.first.bounding_box()

                    if box:
                        page.mouse.click(
                            box["x"] + box["width"] / 2,
                            box["y"] + box["height"] / 2,
                        )

                        atual = _aguardar_reacao_do_x(
                            page,
                            fingerprint_anterior=fp,
                            heartbeat=heartbeat,
                            timeout_ms=2500,
                        )

                        if (
                            atual is None
                            or _fingerprint(atual) != fp
                        ):
                            return atual
            except Exception:
                pass

    raise RuntimeError(
        "Popup SAP continuou aberto após tentativas seguras "
        "no X exato. Nenhum Escape foi enviado. "
        f"Título={snap.get('title')!r}; "
        f"X={close_id!r}"
    )

def fechar_todos_popups(
    page: Page,
    *,
    heartbeat=None,
    contexto: str = "",
    max_popups: int = 20,
) -> list[PopupSap]:
    """
    Drena qualquer cadeia de popups SAP.

    Sem espera fixa de silêncio:
      popup apareceu -> fecha -> confirma;
      outro apareceu -> fecha;
      nenhum popup -> retorna imediatamente.
    """
    registros: list[PopupSap] = []

    snap = _snapshot_popup(page)

    for _ in range(max_popups):
        if heartbeat is not None:
            heartbeat.assert_owned()

        if snap is None:
            return registros

        # Proteção de recuperação: se por qualquer motivo a VA01
        # abrir a confirmação de cancelamento, nunca confirma perda
        # dos dados. Clica "No" e retoma o fluxo.
        if _is_cancel_order_processing(snap):
            snap = _clicar_no_cancelamento(
                page,
                snap,
                heartbeat=heartbeat,
            )
            continue

        registros.append(
            PopupSap(
                texto=str(
                    snap.get("text") or ""
                ),
                titulo=str(
                    snap.get("title") or ""
                ),
            )
        )

        snap = _clicar_x_real(
            page,
            snap,
            heartbeat=heartbeat,
        )

    raise RuntimeError(
        "Mais de 20 popups SAP apareceram em sequência."
    )
