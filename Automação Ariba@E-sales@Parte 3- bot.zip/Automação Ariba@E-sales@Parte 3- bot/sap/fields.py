from __future__ import annotations

import time
from datetime import date, datetime
from decimal import Decimal

from playwright.sync_api import Locator, Page

from sap.loading import aguardar_sap_pronto
from sap.locator import resolver, resolver_candidatos


FAST_ACTION_TIMEOUT_MS = 2500
FIELD_INACTIVITY_TIMEOUT_S = 30.0


def formatar_valor(valor) -> str:
    if valor is None:
        return ""
    if isinstance(valor, datetime):
        return valor.strftime("%m/%d/%Y")
    if isinstance(valor, date):
        return valor.strftime("%m/%d/%Y")
    if isinstance(valor, Decimal):
        texto = format(valor, "f")
        return texto.rstrip("0").rstrip(".") or "0"
    return str(valor)


def _normalizar(texto: str) -> str:
    return " ".join(str(texto or "").replace("\xa0", " ").split()).strip()


def _tag(locator: Locator) -> str:
    try:
        return locator.evaluate("(el) => el.tagName.toLowerCase()")
    except Exception:
        return ""


def _alvo_clicavel(locator: Locator) -> Locator:
    try:
        tag = _tag(locator)
        if tag in {"button", "a", "input"}:
            return locator

        ct = locator.get_attribute("ct")
        role = locator.get_attribute("role")
        if ct == "B" or role == "button":
            return locator

        ancestor = locator.locator(
            "xpath=ancestor::*[self::button or self::a or "
            "@role='button' or @ct='B'][1]"
        )
        if ancestor.count():
            return ancestor.first
    except Exception:
        pass
    return locator


def _editor_real(page: Page, locator: Locator) -> Locator | None:
    tag = _tag(locator)
    if tag in {"input", "textarea"}:
        return locator

    filhos = locator.locator(
        "input:not([type='hidden']), textarea, [contenteditable='true']"
    )
    if filhos.count():
        return filhos.first

    try:
        locator.focus(timeout=FAST_ACTION_TIMEOUT_MS)
    except Exception:
        pass

    focado = page.locator(
        "input:focus, textarea:focus, [contenteditable='true']:focus"
    )
    if focado.count():
        return focado.first
    return None


def _valor_dom(locator: Locator) -> str:
    try:
        valor = locator.evaluate(
            """
            el => {
                if ('value' in el) return String(el.value ?? '');
                return String(el.textContent ?? '');
            }
            """
        )
        return _normalizar(valor)
    except Exception:
        return ""


def _max_length_dom(locator: Locator) -> int | None:
    try:
        value = locator.evaluate(
            """
            el => {
                const attr = el.getAttribute?.('maxlength');
                if (attr !== null && attr !== undefined && attr !== '') {
                    const n = Number(attr);
                    if (Number.isFinite(n) && n >= 0) return n;
                }
                if ('maxLength' in el) {
                    const n = Number(el.maxLength);
                    if (Number.isFinite(n) && n >= 0 && n < 2147483647) {
                        return n;
                    }
                }
                return null;
            }
            """
        )
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def _resolver(page: Page, spec: dict | list[dict]) -> Locator:
    return (
        resolver_candidatos(page, spec)
        if isinstance(spec, list)
        else resolver(page, spec)
    )


def _aguardar_locator_anexado(
    page: Page,
    spec: dict | list[dict],
    *,
    heartbeat=None,
    runtime=None,
    contexto: str = "campo",
    timeout_inatividade_s: float = FIELD_INACTIVITY_TIMEOUT_S,
) -> Locator:
    ultimo_progresso = time.monotonic()
    ultimo_estado = None

    while True:
        if heartbeat is not None:
            heartbeat.assert_owned()

        # PRIMEIRO tenta o campo IMEDIATAMENTE.
        # Em fluxo normal não chama runtime, loading, popup, status
        # nem identificação de estado entre inputs.
        locator = _resolver(page, spec)

        try:
            if locator.count() > 0:
                attached = locator.evaluate(
                    "el => Boolean(el && el.isConnected)"
                )
                if attached:
                    return locator
        except Exception:
            pass

        # Só se o campo esperado NÃO EXISTIR é que isso deixa de ser
        # "input normal" e vira uma situação excepcional. Aí sim o
        # observador central entra para descobrir/tratar o que bloqueou.
        if runtime is not None:
            resultado = runtime.estabilizar(
                contexto=contexto,
                appearance_grace_ms=0,
                auto_reenter=True,
            )

            if resultado.houve_progresso:
                ultimo_progresso = time.monotonic()

            estado = resultado.estado

            if estado != ultimo_estado:
                ultimo_estado = estado
                ultimo_progresso = time.monotonic()
        else:
            aguardar_sap_pronto(
                page,
                heartbeat=heartbeat,
                stable_ms=0,
            )

        if time.monotonic() - ultimo_progresso >= timeout_inatividade_s:
            raise RuntimeError(
                "Campo/ação não apareceu após período sem progresso do SAP. "
                f"Contexto={contexto!r}; estado={ultimo_estado!r}."
            )

        time.sleep(0.05)


def preencher(
    page: Page,
    spec: dict | list[dict],
    valor,
    *,
    heartbeat=None,
    runtime=None,
    contexto: str = "campo",
    nome_campo: str | None = None,
    tentativas: int = 2,
) -> Locator:
    esperado_original = formatar_valor(valor).strip()

    for tentativa in range(1, tentativas + 1):
        locator = _aguardar_locator_anexado(
            page,
            spec,
            heartbeat=heartbeat,
            runtime=runtime,
            contexto=contexto,
        )

        if heartbeat is not None:
            heartbeat.assert_owned()

        # _aguardar_locator_anexado() já chamou o runtime imediatamente
        # antes de devolver o locator e só retorna depois de resolver
        # loading/popup/status/estado bloqueante. Fazer uma SEGUNDA
        # estabilização aqui repetia toda a inspeção do SAP sem existir
        # nenhuma ação entre as duas verificações.
        #
        # O Locator do Playwright é "live": não precisamos recriá-lo
        # apenas porque o DOM pode ter sido atualizado.
        editor = _editor_real(page, locator)

        if editor is None:
            if tentativa < tentativas:
                time.sleep(0.05)
                continue
            raise RuntimeError(
                "Campo existe no DOM, mas nenhum editor real foi encontrado."
            )

        limite = _max_length_dom(editor)
        esperado_dom = esperado_original

        if limite is not None and limite >= 0 and len(esperado_dom) > limite:
            esperado_dom = esperado_dom[:limite]
            if runtime is not None:
                runtime.logger(
                    "[CAMPO] SAP limita "
                    f"{nome_campo or 'campo'} a {limite} caracteres: "
                    f"{esperado_original!r} -> {esperado_dom!r}"
                )

        try:
            editor.fill(
                esperado_original,
                timeout=FAST_ACTION_TIMEOUT_MS,
            )
        except Exception:
            editor.focus(timeout=FAST_ACTION_TIMEOUT_MS)
            page.keyboard.press("Control+A")
            page.keyboard.insert_text(esperado_original)

        atual = _valor_dom(editor)

        # Aceita o valor efetivamente permitido pelo próprio maxlength do SAP.
        if atual == _normalizar(esperado_dom):
            # REGRA: simples input terminou -> próximo input imediatamente.
            # Nenhuma checagem de loading/popup/status aqui.
            return locator

        if tentativa < tentativas:
            time.sleep(0.08)

    raise RuntimeError(
        "Campo não confirmou valor. "
        f"Campo={nome_campo!r}; esperado={esperado_original!r}; "
        f"esperado_no_SAP={esperado_dom!r}; atual={atual!r}"
    )


def clicar(
    page: Page,
    spec: dict | list[dict],
    *,
    heartbeat=None,
    runtime=None,
    contexto: str = "acao",
) -> Locator:
    if heartbeat is not None:
        heartbeat.assert_owned()

    # Se a ação já existe, clica IMEDIATAMENTE.
    # O observador só entra ANTES se o botão realmente ainda não existir.
    locator = _resolver(page, spec)

    try:
        existe = locator.count() > 0
    except Exception:
        existe = False

    if not existe:
        locator = _aguardar_locator_anexado(
            page,
            spec,
            heartbeat=heartbeat,
            runtime=runtime,
            contexto=contexto,
        )

    alvo = _alvo_clicavel(locator)

    if runtime is not None:
        runtime.nova_acao_confirmacao(
            f"click:{contexto}"
        )

    alvo.click(timeout=FAST_ACTION_TIMEOUT_MS)
    return locator


def valor(page: Page, spec: dict | list[dict]) -> str:
    locator = _resolver(page, spec)
    editor = _editor_real(page, locator)
    if editor is not None:
        return _valor_dom(editor)
    return _valor_dom(locator)


def selecionar_opcao_texto(
    page: Page,
    campo_spec: dict | list[dict],
    texto: str,
    *,
    heartbeat=None,
    runtime=None,
    contexto: str = "campo",
) -> None:
    clicar(
        page,
        campo_spec,
        heartbeat=heartbeat,
        runtime=runtime,
        contexto=contexto,
    )

    if runtime is not None:
        runtime.estabilizar(
            contexto=contexto,
            appearance_grace_ms=80,
        )

    opcao = page.get_by_text(str(texto), exact=True)

    for i in range(opcao.count()):
        item = opcao.nth(i)
        try:
            if item.is_visible(timeout=200):
                item.click(timeout=FAST_ACTION_TIMEOUT_MS)
                return
        except Exception:
            continue

    raise RuntimeError(f"Opção {texto!r} não encontrada no dropdown.")
