from __future__ import annotations

import time

from playwright.sync_api import Page

from app_config import SAP_LOADING_TIMEOUT_MS
from sap.errors import SapLoadingTimeout


def _loader_visivel(page: Page) -> bool:
    """
    Fonte única para o estado BUSY do SAP WebGUI.

    DOM já confirmado no ambiente real:
      #ur-loading-box   -> container global
      #ur-loading-itm2  -> imagem/indicador interno (fallback)
    """
    try:
        return bool(
            page.evaluate(
                """
                () => {
                    const visible = el => {
                        if (!el) return false;
                        const s = getComputedStyle(el);
                        const r = el.getBoundingClientRect();
                        return (
                            s.display !== 'none' &&
                            s.visibility !== 'hidden' &&
                            Number(s.opacity || 1) !== 0 &&
                            r.width > 0 &&
                            r.height > 0 &&
                            el.getClientRects().length > 0
                        );
                    };

                    return (
                        visible(document.getElementById('ur-loading-box')) ||
                        visible(document.getElementById('ur-loading-itm2'))
                    );
                }
                """
            )
        )
    except Exception:
        return False


def aguardar_sap_pronto(
    page: Page,
    *,
    heartbeat=None,
    timeout_ms: int = SAP_LOADING_TIMEOUT_MS,
    appearance_grace_ms: int = 0,
    stable_ms: int = 40,
) -> None:
    """
    Aguarda SOMENTE quando o SAP está realmente em loading.

    O timeout é do loading contínuo, não da duração total da OV.
    """
    inicio = time.monotonic()

    if not _loader_visivel(page):
        if appearance_grace_ms <= 0:
            return

        limite_grace = inicio + appearance_grace_ms / 1000

        while time.monotonic() < limite_grace:
            if heartbeat is not None:
                heartbeat.assert_owned()

            if _loader_visivel(page):
                break

            time.sleep(0.02)
        else:
            return

    livre_desde = None

    while True:
        if heartbeat is not None:
            heartbeat.assert_owned()

        agora = time.monotonic()

        if (agora - inicio) * 1000 > timeout_ms:
            raise SapLoadingTimeout(
                "SAP permaneceu em loading por mais de "
                f"{timeout_ms / 1000:.0f}s."
            )

        if _loader_visivel(page):
            livre_desde = None
        else:
            if livre_desde is None:
                livre_desde = agora

            if (agora - livre_desde) * 1000 >= stable_ms:
                return

        time.sleep(0.03)


def tratar_loading(
    page: Page,
    *,
    heartbeat=None,
    stable_ms: int = 40,
) -> bool:
    """Handler global: se existe loading, aguarda e retorna True."""
    if not _loader_visivel(page):
        return False

    aguardar_sap_pronto(
        page,
        heartbeat=heartbeat,
        appearance_grace_ms=0,
        stable_ms=stable_ms,
    )
    return True
