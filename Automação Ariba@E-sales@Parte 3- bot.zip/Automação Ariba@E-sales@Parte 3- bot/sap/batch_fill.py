from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from playwright.sync_api import Page


def _formatar(valor) -> str:
    if valor is None:
        return ""

    if isinstance(valor, datetime):
        return valor.strftime("%m/%d/%Y")

    if isinstance(valor, date):
        return valor.strftime("%m/%d/%Y")

    if isinstance(valor, Decimal):
        texto = format(valor, "f")
        return texto.rstrip("0").rstrip(".") or "0"

    return str(valor)


_JS = r"""
(payload) => {
    const norm = value =>
        String(value ?? '')
            .replace(/\u00a0/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

    const rootFor = spec => {
        if (!spec.scope_css) return document;
        return document.querySelector(spec.scope_css);
    };

    const pick = (arr, spec) => {
        if (!arr || !arr.length) return null;

        if (
            spec.index !== undefined &&
            spec.index !== null
        ) {
            return arr[Number(spec.index)] || null;
        }

        if (spec.last) {
            return arr[arr.length - 1] || null;
        }

        return arr[0] || null;
    };

    const candidateNames = el => {
        const values = [];

        const push = value => {
            const v = norm(value);
            if (v && !values.includes(v)) {
                values.push(v);
            }
        };

        push(el.getAttribute?.('aria-label'));
        push(el.getAttribute?.('title'));
        push(el.getAttribute?.('placeholder'));
        push(el.getAttribute?.('name'));

        const labelledby = el.getAttribute?.('aria-labelledby');
        if (labelledby) {
            push(
                labelledby
                    .split(/\s+/)
                    .map(id => document.getElementById(id)?.textContent || '')
                    .join(' ')
            );
        }

        if (el.id) {
            try {
                const label = document.querySelector(
                    `label[for="${CSS.escape(el.id)}"]`
                );
                push(label?.textContent);
            } catch (_) {}
        }

        try {
            if (el.labels) {
                for (const label of el.labels) {
                    push(label.textContent);
                }
            }
        } catch (_) {}

        return values;
    };

    const editorOf = el => {
        if (!el) return null;

        const tag = (el.tagName || '').toLowerCase();

        if (
            tag === 'input' ||
            tag === 'textarea' ||
            el.isContentEditable
        ) {
            return el;
        }

        return el.querySelector?.(
            'input:not([type="hidden"]), textarea, [contenteditable="true"]'
        ) || null;
    };

    const resolveOne = spec => {
        const root = rootFor(spec);
        if (!root) return null;

        if (spec.type === 'id') {
            const el = document.getElementById(spec.id);

            if (!el) return null;

            if (
                spec.scope_css &&
                root !== document &&
                !root.contains(el)
            ) {
                return null;
            }

            return el;
        }

        if (spec.type === 'css') {
            return pick(
                [...root.querySelectorAll(spec.selector)],
                spec
            );
        }

        if (spec.type === 'title') {
            const wanted = norm(spec.title);
            const exact = Boolean(spec.exact);

            return pick(
                [...root.querySelectorAll('[title]')]
                    .filter(el => {
                        const actual = norm(
                            el.getAttribute('title')
                        );

                        return exact
                            ? actual === wanted
                            : actual.includes(wanted);
                    }),
                spec
            );
        }

        if (
            spec.type === 'role' &&
            spec.role === 'textbox'
        ) {
            const wanted = norm(spec.name);
            const exact = Boolean(spec.exact);

            const arr = [
                ...root.querySelectorAll(
                    'input:not([type="hidden"]), textarea, [role="textbox"]'
                )
            ].filter(el => {
                const nomes = candidateNames(el);

                return nomes.some(actual =>
                    exact
                        ? actual === wanted
                        : actual.includes(wanted)
                );
            });

            return pick(arr, spec);
        }

        if (spec.type === 'label_input') {
            const wanted = norm(spec.label);
            const labelIndex = Math.max(
                1,
                Number(spec.label_index || 1)
            );
            const inputIndex = Math.max(
                1,
                Number(spec.input_index || 1)
            );

            const labels = [...root.querySelectorAll('*')]
                .filter(el =>
                    norm(el.textContent) === wanted
                );

            const label = labels[labelIndex - 1];
            if (!label) return null;

            if (label.htmlFor) {
                const linked = document.getElementById(
                    label.htmlFor
                );
                if (linked) return linked;
            }

            const container =
                label.closest('tr, td, [role="row"], [role="group"], div')
                || root;

            const localInputs = [
                ...container.querySelectorAll(
                    'input:not([type="hidden"]), textarea, [role="textbox"]'
                )
            ];

            if (localInputs[inputIndex - 1]) {
                return localInputs[inputIndex - 1];
            }

            const allInputs = [
                ...root.querySelectorAll(
                    'input:not([type="hidden"]), textarea, [role="textbox"]'
                )
            ];

            const after = allInputs.filter(input =>
                Boolean(
                    label.compareDocumentPosition(input) &
                    Node.DOCUMENT_POSITION_FOLLOWING
                )
            );

            return after[inputIndex - 1] || null;
        }

        return null;
    };

    const resolve = specOrList => {
        const specs = Array.isArray(specOrList)
            ? specOrList
            : [specOrList];

        for (const spec of specs) {
            const target = resolveOne(spec);
            const editor = editorOf(target);

            if (editor) return editor;
        }

        return null;
    };

    const setNativeValue = (el, value) => {
        if (el.isContentEditable) {
            el.textContent = value;
            return;
        }

        const tag = (el.tagName || '').toLowerCase();
        const proto = (
            tag === 'textarea'
                ? HTMLTextAreaElement.prototype
                : HTMLInputElement.prototype
        );

        const desc = Object.getOwnPropertyDescriptor(
            proto,
            'value'
        );

        if (desc?.set) {
            desc.set.call(el, value);
        } else {
            el.value = value;
        }
    };

    const results = [];

    for (const field of payload) {
        const editor = resolve(field.locator);

        if (!editor) {
            results.push({
                key: field.key,
                ok: false,
                error: 'locator_not_found'
            });
            continue;
        }

        const original = norm(field.value);
        let expected = original;

        const rawMax = editor.getAttribute?.('maxlength');
        let maxLength = null;

        if (rawMax !== null && rawMax !== '') {
            const n = Number(rawMax);

            if (Number.isFinite(n) && n >= 0) {
                maxLength = n;
                expected = expected.slice(0, n);
            }
        }

        try {
            editor.focus();

            setNativeValue(
                editor,
                original
            );

            editor.dispatchEvent(
                new Event('input', {
                    bubbles: true,
                    composed: true
                })
            );

            editor.dispatchEvent(
                new Event('change', {
                    bubbles: true,
                    composed: true
                })
            );

            const actual = norm(
                ('value' in editor)
                    ? editor.value
                    : editor.textContent
            );

            results.push({
                key: field.key,
                ok: actual === expected,
                actual,
                expected,
                maxLength
            });
        } catch (error) {
            results.push({
                key: field.key,
                ok: false,
                error: String(error)
            });
        }
    }

    return results;
}
"""


def preencher_lote(
    page: Page,
    runtime,
    campos: list[dict],
    *,
    contexto: str,
) -> dict[str, str]:
    """
    Preenche vários campos simples em UMA chamada ao browser.

    IMPORTANTE:
      - não verifica loading entre inputs;
      - não lê popup entre inputs;
      - não lê rodapé entre inputs;
      - não identifica estado entre inputs.

    Essas reações são tratadas depois da ação que faz o SAP processar
    (Enter, botão, Tab de confirmação, Create, Save etc.).
    """
    runtime.heartbeat.assert_owned()

    payload = [
        {
            "key": str(campo["key"]),
            "locator": campo["locator"],
            "value": _formatar(campo.get("value")),
        }
        for campo in campos
    ]

    resultados = page.evaluate(
        _JS,
        payload,
    )

    saida: dict[str, str] = {}

    for resultado in resultados:
        chave = str(
            resultado.get("key") or ""
        )

        if not resultado.get("ok"):
            raise RuntimeError(
                "Batch input não confirmou campo. "
                f"Campo={chave!r}; "
                f"esperado={resultado.get('expected')!r}; "
                f"atual={resultado.get('actual')!r}; "
                f"erro={resultado.get('error')!r}."
            )

        atual = str(
            resultado.get("actual") or ""
        )

        saida[chave] = atual

        limite = resultado.get(
            "maxLength"
        )

        if limite is not None:
            original = next(
                (
                    _formatar(c.get("value")).strip()
                    for c in campos
                    if str(c["key"]) == chave
                ),
                "",
            )

            if len(original) > int(limite):
                runtime.logger(
                    "[CAMPO] SAP truncou "
                    f"{chave} para {limite} caracteres: "
                    f"{atual!r}"
                )

    return saida
