from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from playwright.sync_api import Page

from database.repository import registrar_mensagem
from sap.errors import (
    AbortarSolicitacao,
    PularItem,
    SapMessageError,
    SapStateError,
)
from sap.loading import tratar_loading
from sap.messages import DecisaoMensagem, classificar
from sap.popups import fechar_todos_popups, popup_visivel
from sap.state import identificar_estado
from sap.status_bar import StatusSap, ler_status


@dataclass
class ResultadoEstabilizacao:
    estado: str
    status: StatusSap | None
    decisoes: list[DecisaoMensagem]
    confirmado: bool = False
    eventos: list[str] = field(default_factory=list)

    @property
    def precisa_reenter(self) -> bool:
        return any(d.acao == "reenter" for d in self.decisoes)

    @property
    def ov(self) -> str | None:
        for decisao in self.decisoes:
            if decisao.ov:
                return decisao.ov
        return None

    @property
    def houve_progresso(self) -> bool:
        return bool(self.eventos or self.decisoes or self.confirmado)


class SapRuntime:
    """
    Observador/dispatcher central do SAP.

    Ordem de prioridade global em QUALQUER ponto em que o runtime é chamado:
      1. loading
      2. popup
      3. mensagem de rodapé
      4. tela/estado bloqueante registrado (ex.: ATP)
      5. confirmação da ação de negócio

    Assim uma confirmação de negócio nunca "fura" uma tela bloqueante.
    """

    def __init__(
        self,
        page: Page,
        heartbeat,
        *,
        solicitacao_id: int,
        executor_id: int,
        lock_token: str,
        logger: Callable[[str], None] = print,
    ) -> None:
        self.page = page
        self.heartbeat = heartbeat
        self.solicitacao_id = solicitacao_id
        self.executor_id = executor_id
        self.lock_token = lock_token
        self.logger = logger
        self._last_status_text = ""
        self._acao_confirmacao_seq = 0
        self._etapa_atual = None
        self._etapa_inicio = time.monotonic()
        self._state_handlers: dict[str, Callable[[], None]] = {}
        self._state_handler_em_execucao: str | None = None
        self._state_handler_latched: str | None = None

    def registrar_handler_estado(
        self,
        estado: str,
        handler: Callable[[], None],
    ) -> None:
        self._state_handlers[str(estado)] = handler

    def nova_acao_confirmacao(
        self,
        nome: str,
    ) -> None:
        """
        Abre um NOVO ciclo de reação do SAP.

        O mesmo texto de rodapé pode aparecer em duas ações diferentes
        (ex.: Tab -> warning X, depois Create -> warning X novamente).
        Deduplicar o rodapé globalmente fazia a segunda ocorrência ser
        ignorada e o robô ficar esperando até timeout.

        A deduplicação continua existindo DENTRO da ação atual, mas é
        zerada toda vez que há uma ação que pode fazer o SAP processar:
        Enter, botão, Create, Save, check verde, F3 etc.
        """
        self._acao_confirmacao_seq += 1
        self._last_status_text = ""

        self.logger(
            f"[AÇÃO {self._acao_confirmacao_seq}] {nome}"
        )

    def etapa(self, nome: str) -> None:
        agora = time.monotonic()

        if self._etapa_atual is not None:
            self.logger(
                f"[PERF] {self._etapa_atual}: "
                f"{agora - self._etapa_inicio:.2f}s"
            )

        self._etapa_atual = nome
        self._etapa_inicio = agora
        self.heartbeat.set_etapa(nome)
        self.logger(f"[ETAPA] {nome}")

    def _registrar(
        self,
        texto: str,
        *,
        persistir_sql: bool = False,
    ) -> None:
        if not texto:
            return

        self.logger(f"[SAP] {texto}")

        if persistir_sql:
            registrar_mensagem(
                self.solicitacao_id,
                self.executor_id,
                self.lock_token,
                texto,
            )

    def _status_exige_enter_direto(
        self,
        texto: str,
        contexto: str,
    ) -> bool:
        """
        Warnings já confirmados em teste real que bloqueiam o fluxo
        até um novo Enter.
        """
        t = str(texto or "").strip().casefold()

        return (
            contexto == "item"
            and "please check the receiving hours for the unloading point"
            in t
        )

    def _aplicar_decisao(self, decisao: DecisaoMensagem) -> None:
        acao = decisao.acao

        if acao in {
            "ignorar",
            "confirmar_continuar",
            "reenter",
            "capturar_ov",
        }:
            return

        if acao == "pular_item":
            raise PularItem(decisao.texto)

        if acao in {
            "pular_ov",
            "abortar",
            "erro_solicitacao",
            "investigar",
        }:
            raise AbortarSolicitacao(
                f"{decisao.id}: {decisao.texto}"
            )

        raise SapMessageError(
            f"Ação de mensagem desconhecida: {acao}"
        )

    def _resultado(
        self,
        *,
        status: StatusSap | None,
        decisoes: list[DecisaoMensagem],
        confirmado: bool = False,
        eventos: list[str] | None = None,
    ) -> ResultadoEstabilizacao:
        return ResultadoEstabilizacao(
            estado=identificar_estado(self.page),
            status=status,
            decisoes=decisoes,
            confirmado=confirmado,
            eventos=list(eventos or []),
        )

    def _tratar_estado_registrado(self) -> str | None:
        estado = identificar_estado(self.page)

        # Assim que o SAP sair do estado tratado, libera o handler para
        # uma futura ocorrência do mesmo estado (ex.: ATP do item seguinte).
        if self._state_handler_latched and estado != self._state_handler_latched:
            self._state_handler_latched = None

        handler = self._state_handlers.get(estado)

        if handler is None:
            return None

        # Não dispara duas vezes na mesma ocorrência antes de o SAP reagir.
        if self._state_handler_latched == estado:
            return None

        # Proteção contra recursão caso um handler use alguma função
        # que volte a consultar o runtime.
        if self._state_handler_em_execucao == estado:
            return None

        self.logger(f"[SAP] Estado bloqueante detectado: {estado}")
        self._state_handler_em_execucao = estado

        try:
            handler()
            self._state_handler_latched = estado
        finally:
            self._state_handler_em_execucao = None

        return estado

    def _indicio_estado_bloqueante_rapido(self) -> bool:
        """
        Probe barato para a tela bloqueante conhecida de ATP.

        Em telas normais evita document.body.innerText, que é caro no
        SAP WebGUI. Só lê o texto da página se existir botão Copy,
        reduzindo muito o custo entre inputs.
        """
        if not self._state_handlers:
            return False

        try:
            return bool(
                self.page.evaluate(
                    """
                    () => {
                        if (!document.querySelector('[title="Copy"]')) {
                            return false;
                        }

                        const t = document.body?.textContent || '';

                        return (
                            t.includes('Complete delivery') &&
                            t.includes('Open Quantity') &&
                            t.includes('Req.deliv.date')
                        );
                    }
                    """
                )
            )
        except Exception:
            return False

    def reagir_rapido(
        self,
        *,
        contexto: str,
        auto_reenter: bool = True,
        max_reenter: int = 2,
    ) -> bool:
        """
        Fast-path usado ENTRE INPUTS.

        Faz exatamente o necessário antes de seguir para o próximo campo:
          1. loading real -> aguarda;
          2. popup real -> trata;
          3. mensagem nova no rodapé -> classifica/reage;
          4. se houver indício de ATP -> chama o handler de estado.

        NÃO executa identificação completa de tela em situação normal.
        Portanto não faz as varreduras caras de document.body.innerText
        que estavam acontecendo várias vezes entre cada input.

        Retorna True se alguma reação real foi tratada.
        """
        houve_progresso = False
        reenters = 0

        while True:
            self.heartbeat.assert_owned()

            # 1) Loading: só espera se ele estiver REALMENTE visível.
            if tratar_loading(
                self.page,
                heartbeat=self.heartbeat,
                stable_ms=40,
            ):
                houve_progresso = True
                continue

            # 2) Popup: só entra no handler se existir popup REAL.
            if popup_visivel(self.page):
                popups = fechar_todos_popups(
                    self.page,
                    heartbeat=self.heartbeat,
                    contexto=contexto,
                )
                houve_progresso = True

                for popup in popups:
                    texto = popup.texto.strip()

                    if not texto:
                        continue

                    self._registrar(texto)

                    decisao = classificar(
                        texto,
                        contexto=contexto,
                        tipo_status=(
                            "info"
                            if "information" in popup.titulo.casefold()
                            else "unknown"
                        ),
                    )

                    self._aplicar_decisao(decisao)

                # Fechar popup pode causar loading/outro popup.
                continue

            # 3) Rodapé: lê uma vez e reage somente se for mensagem NOVA.
            status = ler_status(self.page)

            if (
                status is not None
                and status.texto
                and status.texto != self._last_status_text
            ):
                self._last_status_text = status.texto
                self._registrar(status.texto)
                houve_progresso = True

                if (
                    auto_reenter
                    and self._status_exige_enter_direto(
                        status.texto,
                        contexto,
                    )
                ):
                    self.logger(
                        "[SAP] Warning bloqueante conhecido: Enter"
                    )
                    self.nova_acao_confirmacao(
                        "item:warning rodapé -> Enter"
                    )
                    self.page.keyboard.press("Enter")
                    continue

                decisao = classificar(
                    status.texto,
                    contexto=contexto,
                    tipo_status=status.tipo,
                )

                self._aplicar_decisao(decisao)

                if (
                    auto_reenter
                    and decisao.acao == "reenter"
                ):
                    reenters += 1

                    if reenters > max_reenter:
                        raise RuntimeError(
                            "SAP pediu confirmação repetidamente "
                            "sem avançar."
                        )

                    self.logger(
                        "[SAP] Mensagem exige confirmação: Enter"
                    )
                    self._last_status_text = ""
                    self.page.keyboard.press("Enter")

                    # Enter pode gerar loading/popup/status.
                    continue

            # 4) ATP continua podendo aparecer fora de ordem.
            # Só fazemos a identificação completa se o probe barato
            # indicar que uma tela bloqueante provavelmente existe.
            if self._indicio_estado_bloqueante_rapido():
                estado = self._tratar_estado_registrado()

                if estado is not None:
                    houve_progresso = True
                    continue

            return houve_progresso

    def estabilizar(
        self,
        *,
        contexto: str,
        appearance_grace_ms: int = 100,
        auto_reenter: bool = False,
        max_reenter: int = 4,
        confirmar: Callable[[], bool] | None = None,
    ) -> ResultadoEstabilizacao:
        """
        Observa e reage a eventos globais do SAP sem assumir uma sequência fixa.
        """
        grace_s = max(0, appearance_grace_ms) / 1000
        decisoes: list[DecisaoMensagem] = []
        eventos: list[str] = []
        ultimo_status = ler_status(self.page)
        deadline = time.monotonic() + grace_s
        reenters = 0

        while True:
            self.heartbeat.assert_owned()

            # 1) LOADING - bloqueante e prioritário.
            if tratar_loading(
                self.page,
                heartbeat=self.heartbeat,
                stable_ms=40,
            ):
                eventos.append("loading")
                deadline = time.monotonic() + grace_s
                continue

            # 2) POPUP - pode surgir antes/depois de qualquer roundtrip.
            if popup_visivel(self.page):
                popups = fechar_todos_popups(
                    self.page,
                    heartbeat=self.heartbeat,
                    contexto=contexto,
                )
                eventos.append("popup")

                for popup in popups:
                    texto = popup.texto.strip()
                    if not texto:
                        continue

                    self._registrar(texto)
                    decisao = classificar(
                        texto,
                        contexto=contexto,
                        tipo_status=(
                            "info"
                            if "information" in popup.titulo.casefold()
                            else "unknown"
                        ),
                    )
                    decisoes.append(decisao)
                    self._aplicar_decisao(decisao)

                deadline = time.monotonic() + grace_s
                continue

            # 3) RODAPÉ - sempre antes de confirmar ação de negócio.
            status = ler_status(self.page)
            ultimo_status = status
            nova_decisao = None

            if (
                status is not None
                and status.texto
                and status.texto != self._last_status_text
            ):
                self._last_status_text = status.texto
                self._registrar(status.texto)
                eventos.append("status")

                if (
                    auto_reenter
                    and self._status_exige_enter_direto(
                        status.texto,
                        contexto,
                    )
                ):
                    self.logger(
                        "[SAP] Warning bloqueante conhecido: Enter"
                    )
                    self.nova_acao_confirmacao(
                        "item:warning rodapé -> Enter"
                    )
                    self.page.keyboard.press("Enter")
                    eventos.append("reenter")
                    deadline = time.monotonic() + grace_s
                    continue

                nova_decisao = classificar(
                    status.texto,
                    contexto=contexto,
                    tipo_status=status.tipo,
                )
                decisoes.append(nova_decisao)
                self._aplicar_decisao(nova_decisao)
                deadline = time.monotonic() + grace_s

            if (
                auto_reenter
                and nova_decisao is not None
                and nova_decisao.acao == "reenter"
            ):
                reenters += 1

                if reenters > max_reenter:
                    raise RuntimeError(
                        "SAP pediu confirmação repetidamente sem avançar."
                    )

                self.logger("[SAP] Mensagem exige confirmação: Enter")
                self._last_status_text = ""
                self.page.keyboard.press("Enter")
                eventos.append("reenter")
                deadline = time.monotonic() + grace_s
                continue

            # 4) ESTADO BLOQUEANTE/DINÂMICO - ex.: ATP.
            estado_tratado = self._tratar_estado_registrado()

            if estado_tratado is not None:
                eventos.append(f"estado:{estado_tratado}")
                deadline = time.monotonic() + grace_s
                continue

            # 5) Só agora confirma a ação de negócio.
            if confirmar is not None:
                try:
                    if confirmar():
                        eventos.append("confirmacao")
                        return self._resultado(
                            status=ultimo_status,
                            decisoes=decisoes,
                            confirmado=True,
                            eventos=eventos,
                        )
                except Exception:
                    pass

            if grace_s <= 0:
                return self._resultado(
                    status=ultimo_status,
                    decisoes=decisoes,
                    eventos=eventos,
                )

            if time.monotonic() >= deadline:
                return self._resultado(
                    status=ultimo_status,
                    decisoes=decisoes,
                    eventos=eventos,
                )

            time.sleep(0.03)

    def aguardar_condicao(
        self,
        confirmar: Callable[[], bool],
        *,
        contexto: str,
        timeout_inatividade_s: float = 30.0,
        auto_reenter: bool = False,
        max_reenter: int = 4,
    ) -> ResultadoEstabilizacao:
        """
        Espera uma condição de negócio enquanto continua reagindo ao SAP.

        Loading longo não consome o timeout: o relógio só é verificado depois
        que o handler de loading devolve o controle. Popup/status/estado tratado
        reiniciam a janela de inatividade.
        """
        ultimo_progresso = time.monotonic()
        ultimo_estado = identificar_estado(self.page)
        ultimo_status_texto = ""

        while True:
            resultado = self.estabilizar(
                contexto=contexto,
                appearance_grace_ms=150,
                auto_reenter=auto_reenter,
                max_reenter=max_reenter,
                confirmar=confirmar,
            )

            if resultado.confirmado:
                return resultado

            agora = time.monotonic()
            estado = identificar_estado(self.page)
            status = ler_status(self.page)
            status_texto = (
                status.texto.strip()
                if status is not None and status.texto
                else ""
            )

            if resultado.houve_progresso:
                ultimo_progresso = agora

            if estado != ultimo_estado:
                ultimo_estado = estado
                ultimo_progresso = agora

            if status_texto and status_texto != ultimo_status_texto:
                ultimo_status_texto = status_texto
                ultimo_progresso = agora

            try:
                if confirmar():
                    return self._resultado(
                        status=status,
                        decisoes=resultado.decisoes,
                        confirmado=True,
                        eventos=resultado.eventos + ["confirmacao"],
                    )
            except Exception:
                pass

            if agora - ultimo_progresso >= timeout_inatividade_s:
                raise RuntimeError(
                    "SAP ficou sem progresso por "
                    f"{timeout_inatividade_s:.0f}s enquanto aguardava "
                    f"condição em {contexto!r}. "
                    f"Estado={ultimo_estado!r}; "
                    f"status={ultimo_status_texto!r}."
                )

            time.sleep(0.05)

    def aguardar_estado(
        self,
        estados: set[str] | list[str] | tuple[str, ...],
        *,
        contexto: str,
        timeout_inatividade_s: float = 30.0,
        auto_reenter: bool = False,
    ) -> str:
        esperados = set(estados)

        resultado = self.aguardar_condicao(
            lambda: identificar_estado(self.page) in esperados,
            contexto=contexto,
            timeout_inatividade_s=timeout_inatividade_s,
            auto_reenter=auto_reenter,
        )

        estado = identificar_estado(self.page)

        if estado not in esperados:
            raise SapStateError(
                "Estado SAP inesperado. "
                f"Esperado={sorted(esperados)}; atual={estado}."
            )

        return estado
