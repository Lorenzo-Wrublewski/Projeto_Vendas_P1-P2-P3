from __future__ import annotations

import re
import time

from playwright.sync_api import Page

from app_config import SAP_STATE_TIMEOUT_MS, carregar_json
from sap.fields import clicar
from sap.loading import _loader_visivel
from sap.messages import classificar
from sap.popups import popup_visivel
from sap.state import identificar_estado
from sap.status_bar import ler_status


_SELECTORS = carregar_json("selectors.json")


_SUCCESS_PATTERNS = (
    re.compile(
        r"Component\s+Sales\s+Ord\.\s*(\d+)\s+has\s+been\s+saved",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bOrder\s+(\d+)\s+has\s+been\s+saved\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bDocumento\s+(\d+)\s+foi\s+gravado\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bOrdem\s+standard\s+(\d+)\s+foi\s+gravada\b",
        re.IGNORECASE,
    ),
)


def _extrair_ov_sucesso(texto: str) -> str | None:
    """
    Fallback de captura do número da OV.

    A classificação oficial continua sendo sap.messages.classificar().
    Estes regex existem para não perder uma OV válida caso a mensagem
    de sucesso seja exibida por uma variação textual conhecida do SAP.
    """
    texto = str(texto or "").strip()

    if not texto:
        return None

    for pattern in _SUCCESS_PATTERNS:
        match = pattern.search(texto)

        if match:
            return match.group(1)

    return None


def _processar_status(
    status,
    runtime,
) -> tuple[str, str] | None:
    if status is None:
        return None

    texto = str(
        status.texto or ""
    ).strip()

    if not texto:
        return None

    # Primeiro tenta o classificador oficial.
    decisao = classificar(
        texto,
        contexto="salvamento",
        tipo_status=status.tipo,
    )

    runtime._aplicar_decisao(
        decisao
    )

    ov = decisao.ov

    # Fallback conhecido para a mensagem real observada no SAP:
    # "Component Sales Ord. 3584500 has been saved"
    if not ov:
        ov = _extrair_ov_sucesso(
            texto
        )

    if ov:
        runtime._registrar(
            texto
        )
        return str(ov), texto

    return None


def salvar_ov(
    page: Page,
    runtime,
) -> tuple[str, str]:
    """
    Salva UMA única vez e observa o resultado até conseguir determinar
    sucesso ou falha.

    Regras importantes:
      - o botão Save nunca é clicado novamente como retry;
      - loading pode surgir imediatamente ou alguns instantes depois;
      - enquanto houver loading, nenhuma ação é executada;
      - o rodapé é observado INCLUSIVE durante loading, para não perder
        mensagem transitória de sucesso;
      - popup/status/estado são tratados como progresso;
      - timeout é por INATIVIDADE depois do último progresso, e não por
        duração total do Save.
    """
    runtime.etapa(
        "SALVANDO"
    )

    anterior_obj = ler_status(
        page
    )
    ultimo_texto = (
        anterior_obj.texto.strip()
        if (
            anterior_obj is not None
            and anterior_obj.texto
        )
        else ""
    )

    ultimo_estado = identificar_estado(
        page
    )

    # SAVE É NÃO-IDEMPOTENTE:
    # clicar exatamente uma vez.
    clicar(
        page,
        _SELECTORS[
            "toolbar"
        ]["save"],
        heartbeat=runtime.heartbeat,
    )

    runtime.logger(
        "[SAVE] Save acionado uma única vez. "
        "Aguardando confirmação real do SAP."
    )

    timeout_inatividade_s = max(
        30.0,
        SAP_STATE_TIMEOUT_MS / 1000,
    )

    ultimo_progresso = (
        time.monotonic()
    )

    loading_anunciado = False

    while True:
        runtime.heartbeat.assert_owned()

        # ------------------------------------------------------------
        # 1) RODAPÉ: sempre observado, inclusive DURANTE loading.
        # Isso evita perder mensagem curta de sucesso.
        # ------------------------------------------------------------
        status = ler_status(
            page
        )

        if (
            status is not None
            and status.texto
        ):
            texto = status.texto.strip()

            # Se for uma mensagem de sucesso conhecida, processa mesmo
            # que por algum motivo o texto coincida com cache anterior.
            ov_direta = _extrair_ov_sucesso(
                texto
            )

            if (
                texto != ultimo_texto
                or ov_direta
            ):
                ultimo_texto = texto
                ultimo_progresso = (
                    time.monotonic()
                )

                resultado = _processar_status(
                    status,
                    runtime,
                )

                if resultado is not None:
                    ov, mensagem = resultado

                    runtime.logger(
                        f"[SAVE] OV confirmada pelo SAP: {ov}"
                    )

                    return ov, mensagem

        # ------------------------------------------------------------
        # 2) LOADING: bloqueante.
        # Não executa popup/click/tecla enquanto ele estiver visível.
        # Mas continua lendo o rodapé.
        # ------------------------------------------------------------
        if _loader_visivel(
            page
        ):
            if not loading_anunciado:
                runtime.logger(
                    "[SAVE] Loading detectado. "
                    "Aguardando o SAP terminar o salvamento."
                )
                loading_anunciado = True

            while _loader_visivel(
                page
            ):
                runtime.heartbeat.assert_owned()

                status = ler_status(
                    page
                )

                if (
                    status is not None
                    and status.texto
                ):
                    texto = status.texto.strip()
                    ov_direta = _extrair_ov_sucesso(
                        texto
                    )

                    if (
                        texto != ultimo_texto
                        or ov_direta
                    ):
                        ultimo_texto = texto

                        resultado = _processar_status(
                            status,
                            runtime,
                        )

                        if resultado is not None:
                            ov, mensagem = resultado

                            runtime.logger(
                                f"[SAVE] OV confirmada durante loading: {ov}"
                            )

                            return ov, mensagem

                time.sleep(
                    0.05
                )

            runtime.logger(
                "[SAVE] Loading encerrado. "
                "Verificando resultado final."
            )

            loading_anunciado = False
            ultimo_progresso = (
                time.monotonic()
            )

            # Volta ao topo para ler imediatamente o rodapé
            # produzido pelo fim do loading.
            continue

        # ------------------------------------------------------------
        # 3) POPUP eventual após Save.
        # Deixa o runtime tratar com a política já existente.
        # ------------------------------------------------------------
        if popup_visivel(
            page
        ):
            resultado = runtime.estabilizar(
                contexto="salvamento",
                appearance_grace_ms=0,
            )

            ultimo_progresso = (
                time.monotonic()
            )

            if resultado.ov:
                mensagem = (
                    resultado.status.texto
                    if resultado.status is not None
                    else ""
                )

                runtime.logger(
                    f"[SAVE] OV confirmada após popup: {resultado.ov}"
                )

                return (
                    str(resultado.ov),
                    mensagem,
                )

            if (
                resultado.status is not None
                and resultado.status.texto
            ):
                processado = _processar_status(
                    resultado.status,
                    runtime,
                )

                if processado is not None:
                    return processado

            continue

        # ------------------------------------------------------------
        # 4) Mudança real de estado = progresso.
        # ------------------------------------------------------------
        estado = identificar_estado(
            page
        )

        if (
            estado != ultimo_estado
            and estado != "UNKNOWN"
        ):
            runtime.logger(
                "[SAVE] Estado SAP mudou: "
                f"{ultimo_estado} -> {estado}"
            )

            ultimo_estado = estado
            ultimo_progresso = (
                time.monotonic()
            )

        # ------------------------------------------------------------
        # 5) Só falha por ausência REAL de progresso.
        # Não clica Save novamente.
        # ------------------------------------------------------------
        if (
            time.monotonic()
            - ultimo_progresso
        ) >= timeout_inatividade_s:
            raise RuntimeError(
                "Save foi acionado uma única vez, mas o SAP ficou "
                f"{timeout_inatividade_s:.0f}s sem loading, popup, "
                "mudança de estado ou mensagem conclusiva. "
                "NÃO repetir o Save automaticamente, pois a OV pode "
                "ter sido criada. "
                f"Último estado={ultimo_estado!r}; "
                f"último status={ultimo_texto!r}."
            )

        time.sleep(
            0.05
        )
