from __future__ import annotations

from playwright.sync_api import Page

from sap.state import identificar_estado


def tratar_availability_control(page: Page, runtime) -> None:
    """
    Handler específico da tela Availability Control.

    Faz UMA ação: clica o Copy/check verde do bloco Complete delivery.
    Não espera Overview e não chama runtime.estabilizar(), evitando recursão.
    O observador central reassume o controle imediatamente depois.
    """
    if identificar_estado(page) != "AVAILABILITY_CONTROL":
        return

    runtime.etapa("ATP_COMPLETE_DELIVERY")

    titulo = page.get_by_text("Complete delivery", exact=True)
    visivel = None

    for i in range(titulo.count()):
        candidato = titulo.nth(i)
        try:
            if candidato.is_visible(timeout=100):
                visivel = candidato
                break
        except Exception:
            continue

    if visivel is None:
        raise RuntimeError("Seção Complete delivery não encontrada.")

    container = visivel.locator(
        "xpath=ancestor::*[.//*[@title='Copy']][1]"
    )
    botao = None

    if container.count():
        copies = container.get_by_title("Copy", exact=True)
        for i in range(copies.count()):
            candidato = copies.nth(i)
            try:
                if candidato.is_visible(timeout=100):
                    botao = candidato
                    break
            except Exception:
                continue

    if botao is None:
        following = visivel.locator(
            "xpath=following::*[@title='Copy'][1]"
        )
        try:
            if following.count() and following.first.is_visible(timeout=100):
                botao = following.first
        except Exception:
            pass

    if botao is None:
        raise RuntimeError(
            "Check verde/Copy do bloco Complete delivery não encontrado."
        )

    # Reconfirma o estado imediatamente antes do click.
    if identificar_estado(page) != "AVAILABILITY_CONTROL":
        return

    runtime.nova_acao_confirmacao(
        "ATP:check verde Complete delivery"
    )
    botao.click(timeout=2500)
    runtime.logger("[ATP] Check verde de Complete delivery acionado.")
