from __future__ import annotations

import time

from playwright.sync_api import Page

from app_config import carregar_json
from sap.errors import MapeamentoPendente, PularItem
from sap.batch_fill import preencher_lote
from sap.fields import (
    clicar,
    preencher,
    selecionar_opcao_texto,
)
from sap.locator import resolver
from sap.state import identificar_estado
from va01.cancelamento import cancelar_ov_sem_salvar


_SELECTORS = carregar_json("selectors.json")
_ITEM_FIELDS = carregar_json("item_fields.json")


_FIXED_MAP = {
    "material": "material",
    "quantidade": "order_quantity",
    "data_desejada": "first_delivery_date",
    "tipo_uso_material": "usage",
    "material_cliente": "customer_material",
    "centro": "plant",
    "entrega_total_parcial": "partial_delivery_item",
}

_UNMAPPED_FIXED = {
    "pn00",
    "desconto_campanha_oeg",
    "moeda",
    "preco",
}


def _params_item(item: dict) -> dict:
    params = {}

    for coluna, chave in _FIXED_MAP.items():
        valor = item.get(coluna)

        if (
            valor is not None
            and str(valor).strip()
        ):
            params[chave] = valor

    pendentes = [
        coluna
        for coluna in _UNMAPPED_FIXED
        if (
            item.get(coluna) is not None
            and str(item.get(coluna)).strip()
        )
    ]

    if pendentes:
        raise MapeamentoPendente(
            "Campos SQL preenchidos ainda sem "
            "locator validado: "
            + ", ".join(sorted(pendentes))
        )

    extras = item.get(
        "parametros_json"
    ) or {}

    if isinstance(extras, dict):
        params.update(extras)

    return params


def _bool_template(valor) -> bool:
    if isinstance(valor, bool):
        return valor

    texto = str(valor or "").strip().casefold()

    if texto in {"1", "true", "yes", "sim", "y", "x", "on"}:
        return True

    if texto in {"0", "false", "no", "nao", "não", "n", "off", ""}:
        return False

    raise MapeamentoPendente(
        f"Valor de toggle inválido: {valor!r}. "
        "Use true/false, 1/0, sim/não."
    )


def _estado_toggle(locator) -> bool | None:
    try:
        return locator.evaluate(
            """
            el => {
                const input =
                    (el.matches?.('input[type="checkbox"]') ? el : null) ||
                    el.querySelector?.('input[type="checkbox"]');

                if (input) return Boolean(input.checked);

                const aria = el.getAttribute?.('aria-checked');
                if (aria === 'true') return true;
                if (aria === 'false') return false;

                const selected = el.getAttribute?.('aria-selected');
                if (selected === 'true') return true;
                if (selected === 'false') return false;

                return null;
            }
            """
        )
    except Exception:
        return None


def _aplicar_toggle(
    page: Page,
    runtime,
    spec,
    valor,
) -> None:
    desejado = _bool_template(valor)
    locator = resolver(page, spec)

    if locator.count() == 0:
        raise MapeamentoPendente(
            "Toggle mapeado não foi encontrado no SAP."
        )

    atual = _estado_toggle(locator)

    if atual is not None:
        if atual == desejado:
            return

        clicar(
            page,
            spec,
            heartbeat=runtime.heartbeat,
            runtime=runtime,
            contexto="item",
        )
        runtime.estabilizar(
            contexto="item",
            appearance_grace_ms=100,
        )
        return

    # SAP WebGUI antigo pode não expor checked/aria-checked.
    # Para não inverter um valor sem saber o estado, só clicamos
    # quando o template explicitamente pede ativação.
    if desejado:
        clicar(
            page,
            spec,
            heartbeat=runtime.heartbeat,
            runtime=runtime,
            contexto="item",
        )
        runtime.estabilizar(
            contexto="item",
            appearance_grace_ms=100,
        )


def preencher_parametro_item(
    page: Page,
    runtime,
    chave: str,
    valor,
) -> None:
    config = _ITEM_FIELDS[
        "fields"
    ].get(chave)

    if config is None:
        raise MapeamentoPendente(
            f"Campo {chave!r} sem mapeamento."
        )

    inicio = time.monotonic()

    runtime.logger(
        f"[ITEM] Preenchendo {chave} = {valor}"
    )

    tipo = config["kind"]
    spec = config["locator"]

    if tipo == "text":
        preencher(
            page,
            spec,
            valor,
            heartbeat=runtime.heartbeat,
            runtime=runtime,
            contexto="item",
            nome_campo=chave,
        )

    elif tipo == "dropdown":
        selecionar_opcao_texto(
            page,
            spec,
            str(valor),
            heartbeat=runtime.heartbeat,
            runtime=runtime,
            contexto="item",
        )

    elif tipo == "toggle":
        _aplicar_toggle(
            page,
            runtime,
            spec,
            valor,
        )

    else:
        raise MapeamentoPendente(
            f"Tipo não suportado: "
            f"{chave}/{tipo}"
        )

    runtime.logger(
        f"[PERF] campo {chave}: "
        f"{time.monotonic() - inicio:.2f}s"
    )



def preencher_parametros_texto_lote(
    page: Page,
    runtime,
    params: dict,
) -> set[str]:
    """
    Preenche todos os parâmetros kind=text do Item Detail em UMA ida.
    Toggle/dropdown continuam pelas funções específicas.
    """
    campos = []
    tratadas: set[str] = set()

    for chave, valor in params.items():
        config = _ITEM_FIELDS["fields"].get(chave)

        if config is None:
            raise MapeamentoPendente(
                f"Campo {chave!r} sem mapeamento."
            )

        if config.get("kind") != "text":
            continue

        campos.append(
            {
                "key": chave,
                "locator": config["locator"],
                "value": valor,
            }
        )
        tratadas.add(chave)

    if not campos:
        return tratadas

    inicio = time.monotonic()

    preenchidos = preencher_lote(
        page,
        runtime,
        campos,
        contexto="item",
    )

    runtime.logger(
        "[FAST-BATCH] Item: "
        f"{len(preenchidos)} campos em "
        f"{time.monotonic() - inicio:.2f}s"
    )

    for chave, atual in preenchidos.items():
        runtime.logger(
            f"[ITEM] OK {chave} = {atual}"
        )

    return tratadas


# Compatibilidade interna com versões anteriores.
_preencher_parametro = preencher_parametro_item

def _contar_material_na_grade(
    page: Page,
    material: str,
) -> int:
    """
    Conta quantas LINHAS da grade "All items" contêm o material.

    Isso é essencial quando a OV possui dois itens com o MESMO material.
    A antiga validação booleana ("material existe na grade?") dava falso
    positivo no item 2 porque o item 1 já estava lá.
    """
    try:
        return int(
            page.evaluate(
                """
                material => {
                    const visible = el => {
                        if (!el) return false;
                        const s = getComputedStyle(el);
                        const r = el.getBoundingClientRect();

                        return (
                            s.display !== 'none' &&
                            s.visibility !== 'hidden' &&
                            r.width > 0 &&
                            r.height > 0
                        );
                    };

                    const all = [...document.querySelectorAll('*')]
                        .find(
                            el =>
                                visible(el) &&
                                (el.textContent || '').trim() ===
                                    'All items'
                        );

                    if (!all) return 0;

                    const y = all.getBoundingClientRect().bottom;

                    // Procura por linhas reais da tabela abaixo de "All items".
                    // Conta no máximo uma ocorrência por <tr>.
                    const rows = [
                        ...document.querySelectorAll('tr')
                    ].filter(row => {
                        if (!visible(row)) return false;

                        const rr = row.getBoundingClientRect();

                        if (rr.top <= y) return false;

                        return [
                            ...row.querySelectorAll('td, input, span, div, a')
                        ].some(el => {
                            if (!visible(el)) return false;

                            const value = (
                                ('value' in el && el.value) ||
                                el.textContent ||
                                ''
                            ).trim();

                            return value === material;
                        });
                    });

                    if (rows.length) {
                        return rows.length;
                    }

                    // Fallback para layouts SAP sem <tr> convencional:
                    // conta elementos exatos, deduplicando pela posição vertical.
                    const ys = [];

                    for (const el of document.querySelectorAll(
                        'td, input, span, div, a'
                    )) {
                        if (!visible(el)) continue;

                        const r = el.getBoundingClientRect();
                        if (r.top <= y) continue;

                        const value = (
                            ('value' in el && el.value) ||
                            el.textContent ||
                            ''
                        ).trim();

                        if (value !== material) continue;

                        const rowY = Math.round(r.top);

                        if (!ys.some(existing => Math.abs(existing - rowY) <= 2)) {
                            ys.push(rowY);
                        }
                    }

                    return ys.length;
                }
                """,
                material,
            )
        )
    except Exception:
        return 0


def _item_na_grade(
    page: Page,
    material: str,
) -> bool:
    return _contar_material_na_grade(
        page,
        material,
    ) > 0


def abrir_item_detail(
    page: Page,
    runtime,
) -> None:
    runtime.etapa("ITEM_DETAIL")

    clicar(
        page,
        _SELECTORS[
            "overview"
        ]["item_detail_tab"],
        heartbeat=runtime.heartbeat,
        runtime=runtime,
        contexto="item",
    )

    runtime.estabilizar(
        contexto="item",
        appearance_grace_ms=150,
    )



def _confirmar_edicao_item(
    page: Page,
    runtime,
) -> None:
    """
    Confirma/encerra a edição do último campo antes do Create.

    Não espera segundos por campo e não adiciona sleep de negócio.
    Apenas tira o foco do último editor uma única vez e dá ao runtime
    uma janela curta para tratar qualquer reação real do SAP
    (loading/popup/status/ATP) antes do Create.
    """
    runtime.heartbeat.assert_owned()

    try:
        runtime.nova_acao_confirmacao(
            "item:Tab confirmar último campo"
        )
        page.keyboard.press("Tab")
    except Exception:
        pass

    runtime.estabilizar(
        contexto="item",
        appearance_grace_ms=250,
        auto_reenter=True,
        max_reenter=4,
    )


def _finalizar_criacao_item(
    page: Page,
    runtime,
    material: str,
    *,
    quantidade_antes: int,
    timeout_sem_progresso_s: float = 30.0,
) -> bool:
    """
    Pós-Create dirigido por eventos.

    Não presume ordem fixa. O runtime pode receber, em qualquer combinação:
      loading -> popup -> status -> ATP -> loading -> confirmação
    e sempre resolve bloqueadores ANTES de aceitar o item como criado.
    """
    try:
        resultado = runtime.aguardar_condicao(
            lambda: (
                _contar_material_na_grade(page, material)
                > quantidade_antes
            ),
            contexto="item",
            timeout_inatividade_s=timeout_sem_progresso_s,
            auto_reenter=True,
            max_reenter=4,
        )
        return resultado.confirmado

    except PularItem:
        runtime.logger(f"[ITEM] Pulado: {material}")
        return False

    except RuntimeError as exc:
        # Não transforma um item não confirmado em crash imediato da OV.
        # Primeiro faz uma reconciliação final SEM clicar Create outra vez.
        if not str(exc).startswith("SAP ficou sem progresso por "):
            raise

        runtime.logger(
            "[ITEM] Janela de confirmação expirou. "
            "Reconciliando estado antes de decidir o item."
        )

        runtime.estabilizar(
            contexto="item",
            appearance_grace_ms=400,
            auto_reenter=True,
            max_reenter=4,
        )

        quantidade_depois = _contar_material_na_grade(
            page,
            material,
        )

        if quantidade_depois > quantidade_antes:
            runtime.logger(
                "[ITEM] Item encontrado na reconciliação final: "
                f"{material} ({quantidade_antes} -> {quantidade_depois})"
            )
            return True

        estado = identificar_estado(page)

        runtime.logger(
            "[ITEM] SAP retornou sem confirmar o item. "
            f"Material={material}; "
            f"ocorrências={quantidade_antes}->{quantidade_depois}; "
            f"estado={estado}. "
            "Não repetirei o Create automaticamente."
        )

        # Mantém a regra do eSales antigo:
        # item não criado pode ser ignorado; os próximos continuam.
        return False

def criar_item(
    page: Page,
    runtime,
    item: dict,
) -> bool:
    params = _params_item(item)

    material = str(
        params.get("material", "")
    ).strip()

    if not material:
        raise RuntimeError(
            "Item sem material."
        )

    runtime.etapa(
        f"ITEM:{item.get('sequencia') or '?'}"
    )

    tratadas_lote = preencher_parametros_texto_lote(
        page,
        runtime,
        params,
    )

    # Apenas ações especiais ficam individuais.
    for chave, valor in params.items():
        if chave in tratadas_lote:
            continue

        preencher_parametro_item(
            page,
            runtime,
            chave,
            valor,
        )

    # Fecha a edição do último campo UMA vez antes do Create.
    # Isso evita clicar Create enquanto o SAP WebGUI ainda está
    # processando o focus/change do último parâmetro.
    _confirmar_edicao_item(
        page,
        runtime,
    )

    # Snapshot da grade ANTES do Create.
    # Se o mesmo material já existir em outro item, o novo item só é
    # considerado criado quando a quantidade de linhas desse material aumentar.
    quantidade_antes = _contar_material_na_grade(
        page,
        material,
    )

    runtime.logger(
        "[ITEM] Campos preenchidos. Clicando Create. "
        f"Ocorrências atuais na grade: {quantidade_antes}"
    )

    clicar(
        page,
        _SELECTORS[
            "overview"
        ]["create_item"],
        heartbeat=runtime.heartbeat,
        runtime=runtime,
        contexto="item",
    )

    if not _finalizar_criacao_item(
        page,
        runtime,
        material,
        quantidade_antes=quantidade_antes,
    ):
        # ALL OR NOTHING:
        # processar_itens() receberá False e cancelará a VA01 inteira,
        # sem permitir Save parcial.
        runtime.logger(
            f"[ITEM] Não confirmado: {material}"
        )
        return False

    runtime.logger(
        f"[ITEM] Criado: {material}"
    )

    return True


def processar_itens(
    page: Page,
    runtime,
    solicitacao: dict,
) -> int:
    """
    Regra ALL OR NOTHING:

    Se a solicitação possui N itens, a VA01 só pode chegar ao Save
    quando TODOS os N itens forem confirmados.

    Qualquer item:
      - não criado;
      - pulado;
      - não confirmado;
      - erro de parâmetro;
      - erro SAP;
    => cancela a VA01 inteira SEM SALVAR.
    """
    itens = solicitacao.get(
        "itens"
    ) or []

    if not itens:
        raise RuntimeError(
            "Solicitação sem itens."
        )

    esperados = len(itens)
    criados = 0
    cancelado = False

    def cancelar(motivo: str) -> None:
        nonlocal cancelado

        if cancelado:
            return

        cancelar_ov_sem_salvar(
            page,
            runtime,
            motivo=motivo,
        )
        cancelado = True

    try:
        abrir_item_detail(
            page,
            runtime,
        )

        for item in itens:
            sequencia = (
                item.get("sequencia")
                or "?"
            )
            material = str(
                item.get("material")
                or ""
            ).strip()

            criado = criar_item(
                page,
                runtime,
                item,
            )

            if not criado:
                motivo = (
                    "Item não foi confirmado pelo SAP. "
                    f"Sequência={sequencia}; "
                    f"material={material!r}; "
                    f"criados={criados}/{esperados}."
                )

                cancelar(motivo)

                raise RuntimeError(
                    "OV cancelada sem salvar porque "
                    "nem todos os itens foram criados. "
                    + motivo
                )

            criados += 1

        if criados != esperados:
            motivo = (
                "Quantidade de itens criados diverge da solicitação. "
                f"Esperados={esperados}; criados={criados}."
            )

            cancelar(motivo)

            raise RuntimeError(
                "OV cancelada sem salvar. "
                + motivo
            )

        runtime.logger(
            "[ITENS] Validação final ALL OR NOTHING: "
            f"{criados}/{esperados} itens confirmados."
        )

        return criados

    except Exception as exc:
        if not cancelado:
            try:
                cancelar(
                    "Erro durante processamento dos itens: "
                    f"{type(exc).__name__}: {exc}"
                )
            except Exception as cancel_exc:
                runtime.logger(
                    "[CANCEL] Falha ao confirmar visualmente o descarte, "
                    "mas Save NÃO será executado. "
                    f"Erro do cancelamento: {cancel_exc}"
                )

        raise
