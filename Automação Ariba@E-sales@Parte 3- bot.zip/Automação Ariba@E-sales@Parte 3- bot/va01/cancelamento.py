from __future__ import annotations

import time

from playwright.sync_api import Page

from sap.loading import _loader_visivel, aguardar_sap_pronto
from sap.popups import (
    _clicar_x_real,
    _fingerprint,
    _is_cancel_order_processing,
    _snapshot_popup,
)
from sap.state import identificar_estado


def _clicar_yes_cancelamento(
    page: Page,
    runtime,
    snap: dict,
) -> None:
    """
    Confirma o descarte SOMENTE quando o popup foi identificado
    semanticamente como "Cancel Order Processing".

    Nunca clica Yes fora desse popup.
    """
    fp = _fingerprint(snap)

    candidatos = [
        page.get_by_role(
            "button",
            name="Yes",
            exact=True,
        ),
        page.get_by_text(
            "Yes",
            exact=True,
        ),
    ]

    for locator in candidatos:
        try:
            total = locator.count()
        except Exception:
            total = 0

        for i in range(total):
            item = locator.nth(i)

            try:
                if not item.is_visible(timeout=100):
                    continue

                atual = _snapshot_popup(page)

                if (
                    atual is None
                    or _fingerprint(atual) != fp
                    or not _is_cancel_order_processing(atual)
                ):
                    continue

                runtime.logger(
                    "[CANCEL] Confirmando descarte da VA01: Yes"
                )

                item.click(
                    timeout=1200,
                    force=True,
                )

                aguardar_sap_pronto(
                    page,
                    heartbeat=runtime.heartbeat,
                    appearance_grace_ms=1200,
                    stable_ms=60,
                )

                limite = time.monotonic() + 3.0

                while time.monotonic() < limite:
                    runtime.heartbeat.assert_owned()

                    atual = _snapshot_popup(page)

                    if (
                        atual is None
                        or _fingerprint(atual) != fp
                    ):
                        return

                    time.sleep(0.03)

            except Exception:
                continue

    raise RuntimeError(
        "Popup 'Cancel Order Processing' detectado, "
        "mas não foi possível clicar em 'Yes' com segurança."
    )


def cancelar_ov_sem_salvar(
    page: Page,
    runtime,
    *,
    motivo: str,
) -> None:
    """
    Abandona a VA01 atual sem salvar.

    Pode estar em Item Detail, Overview ou outra tela da VA01.
    Envia F3 somente quando não existe popup/loading bloqueando.

    Se aparecer "Cancel Order Processing", confirma explicitamente Yes.
    """
    runtime.etapa(
        "CANCELANDO_SEM_SALVAR"
    )

    runtime.logger(
        "[CANCEL] Solicitação incompleta. "
        "A OV NÃO será salva. "
        f"Motivo: {motivo}"
    )

    for tentativa in range(1, 7):
        runtime.heartbeat.assert_owned()

        if _loader_visivel(page):
            aguardar_sap_pronto(
                page,
                heartbeat=runtime.heartbeat,
                appearance_grace_ms=0,
                stable_ms=60,
            )
            continue

        snap = _snapshot_popup(page)

        if snap is not None:
            if _is_cancel_order_processing(snap):
                _clicar_yes_cancelamento(
                    page,
                    runtime,
                    snap,
                )

                runtime.logger(
                    "[CANCEL] VA01 descartada sem salvar."
                )
                return

            # Popup comum pendente: fecha pelo X seguro.
            _clicar_x_real(
                page,
                snap,
                heartbeat=runtime.heartbeat,
            )
            continue

        estado = identificar_estado(page)

        if estado == "TELA_PRINCIPAL":
            runtime.logger(
                "[CANCEL] Já retornou à tela principal. "
                "Nada foi salvo."
            )
            return

        runtime.logger(
            "[CANCEL] Saindo da VA01 sem salvar "
            f"(F3 tentativa {tentativa}; estado={estado})."
        )

        page.keyboard.press("F3")

        # F3 é ação de processamento. Só depois dele observamos loading.
        aguardar_sap_pronto(
            page,
            heartbeat=runtime.heartbeat,
            appearance_grace_ms=800,
            stable_ms=60,
        )

        # Janela curta para o popup de cancelamento aparecer.
        limite = time.monotonic() + 1.2

        while time.monotonic() < limite:
            runtime.heartbeat.assert_owned()

            snap = _snapshot_popup(page)

            if snap is not None:
                break

            if identificar_estado(page) == "TELA_PRINCIPAL":
                runtime.logger(
                    "[CANCEL] VA01 encerrada sem salvar."
                )
                return

            time.sleep(0.03)

    raise RuntimeError(
        "Não foi possível confirmar visualmente o cancelamento "
        "da VA01 após 6 tentativas. Save não foi executado."
    )
