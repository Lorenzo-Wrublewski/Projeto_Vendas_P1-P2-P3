from __future__ import annotations

import time

from playwright.sync_api import Page

from app_config import carregar_json
from sap.errors import MapeamentoPendente, SapStateError
from sap.fields import clicar
from sap.loading import aguardar_sap_pronto
from sap.locator import resolver, resolver_candidatos
from sap.state import aguardar_estado, identificar_estado


_SELECTORS = carregar_json("selectors.json")
_PARTNER_MAP = carregar_json("partner_map.json")

FAST_TIMEOUT_MS = 1200


def _grade(page: Page) -> tuple[str, list[dict]]:
    """
    Lê TODA a grade Partners em uma única ida ao browser.
    Antes eram dezenas de chamadas Playwright por leitura.
    """
    dados = page.locator(
        '[id^="tbl"][id$=",1]_c"]'
    ).evaluate_all(
        """
        els => {
            const grupos = {};

            const valor = el => {
                if (!el) return '';
                if ('value' in el) {
                    return String(el.value ?? '').trim();
                }
                return String(el.textContent ?? '').trim();
            };

            const visivel = el => {
                if (!el) return false;
                const st = getComputedStyle(el);
                return (
                    st.display !== 'none' &&
                    st.visibility !== 'hidden' &&
                    el.getClientRects().length > 0
                );
            };

            for (const el of els) {
                if (!visivel(el)) continue;

                const m = el.id.match(
                    /^(.*)\\[(\\d+),1\\]_c$/
                );

                if (!m) continue;

                const prefix = m[1];
                const row = Number(m[2]);

                if (!grupos[prefix]) {
                    grupos[prefix] = [];
                }

                const partner = document.getElementById(
                    `${prefix}[${row},2]_c`
                );

                grupos[prefix].push({
                    row,
                    function: valor(el),
                    partner: valor(partner)
                });
            }

            return grupos;
        }
        """
    )

    if not dados:
        raise RuntimeError(
            "Grade Partners não encontrada."
        )

    prefix = max(
        dados,
        key=lambda p: len(dados[p]),
    )

    linhas = sorted(
        dados[prefix],
        key=lambda x: int(x["row"]),
    )

    return prefix, linhas


def _achar_funcao(
    page: Page,
    funcao: str,
) -> tuple[str, int, str] | None:
    prefix, linhas = _grade(page)

    alvo = funcao.strip().casefold()

    for linha in linhas:
        if (
            str(linha["function"]).strip().casefold()
            == alvo
        ):
            return (
                prefix,
                int(linha["row"]),
                str(linha["partner"] or ""),
            )

    return None


def _primeira_linha_vazia(
    page: Page,
) -> tuple[str, int]:
    prefix, linhas = _grade(page)

    for linha in linhas:
        if not str(
            linha["function"] or ""
        ).strip():
            return prefix, int(linha["row"])

    raise RuntimeError(
        "Nenhuma linha vazia em Partners."
    )


def _campo_funcao(
    page: Page,
    prefix: str,
    row: int,
):
    return page.locator(
        f'[id="{prefix}[{row},1]_c"]'
    )


def _funcao_na_linha(
    page: Page,
    prefix: str,
    row: int,
) -> str:
    campo = _campo_funcao(
        page,
        prefix,
        row,
    )

    try:
        return str(
            campo.evaluate(
                """
                el => String(
                    ('value' in el ? el.value : el.textContent) || ''
                ).trim()
                """
            )
            or ""
        ).strip()
    except Exception:
        return ""


def _selecionar_funcao(
    page: Page,
    funcao: str,
    *,
    runtime=None,
    max_ciclos: int = 40,
) -> tuple[str, int]:
    """
    Seleciona Partner Function pelo comportamento real do SAP:
    repete a MESMA inicial até o campo conter exatamente a função
    desejada; só então pressiona Tab.
    """
    funcao = str(funcao or "").strip()

    if not funcao:
        raise RuntimeError("Partner Function vazia.")

    prefix, row = _primeira_linha_vazia(page)
    campo = _campo_funcao(page, prefix, row)
    campo.focus(timeout=FAST_TIMEOUT_MS)

    inicial = funcao[0]
    alvo = funcao.casefold()

    for ciclo in range(1, max_ciclos + 1):
        if runtime is not None:
            runtime.heartbeat.assert_owned()

        # Digitação local na grade: não roda observador antes da tecla.
        page.keyboard.press(inicial)
        inicio_ciclo = time.monotonic()
        atual = ""

        # O requisito validado manualmente é: se o candidato estiver
        # errado, repetir a mesma inicial após até 1 segundo.
        while time.monotonic() - inicio_ciclo < 1.0:
            if runtime is not None:
                runtime.heartbeat.assert_owned()

            atual = _funcao_na_linha(page, prefix, row)

            if atual.casefold() == alvo:
                if runtime is not None:
                    runtime.logger(
                        f"[PARTNER] Função encontrada: {funcao} "
                        f"(ciclo {ciclo})"
                    )

                page.keyboard.press("Tab")
                confirmado = _funcao_na_linha(page, prefix, row)

                if confirmado.casefold() != alvo:
                    raise RuntimeError(
                        "Partner Function mudou após Tab. "
                        f"Esperado={funcao!r}; atual={confirmado!r}"
                    )

                return prefix, row

            page.wait_for_timeout(50)

        if runtime is not None:
            runtime.logger(
                f"[PARTNER] {funcao}: candidato atual={atual!r}; "
                f"repetindo inicial {inicial!r}"
            )

    raise RuntimeError(
        "Partner Function não encontrada após "
        f"{max_ciclos} ciclos da inicial {inicial!r}: {funcao!r}"
    )

def _preencher_partner(
    page: Page,
    prefix: str,
    row: int,
    codigo: str,
    *,
    foco_no_partner: bool,
    runtime=None,
) -> None:
    if not foco_no_partner:
        campo = _campo_funcao(
            page,
            prefix,
            row,
        )
        campo.focus(
            timeout=FAST_TIMEOUT_MS,
        )
        page.keyboard.press("Tab")

    page.wait_for_timeout(50)
    page.keyboard.press("Control+A")
    page.keyboard.insert_text(
        str(codigo)
    )
    page.wait_for_timeout(60)
    if runtime is not None:
        runtime.nova_acao_confirmacao(
            "parceiro:Enter código"
        )
    page.keyboard.press("Enter")



def _resolver_acao(page: Page, spec):
    if isinstance(spec, list):
        return resolver_candidatos(page, spec)
    return resolver(page, spec)


def _clicar_e_reagir(
    page: Page,
    runtime,
    spec,
    *,
    contexto: str,
) -> None:
    """
    Ação de botão/tab:
      clica IMEDIATAMENTE;
      depois trata loading/popup/status/transição.

    Não faz estabilização completa antes do clique.
    """
    runtime.heartbeat.assert_owned()

    locator = _resolver_acao(page, spec)

    if locator.count() <= 0:
        # Só se a ação esperada nem existir é que tentamos resolver
        # alguma reação pendente antes de declarar erro.
        runtime.estabilizar(
            contexto=contexto,
            appearance_grace_ms=0,
            auto_reenter=True,
        )
        locator = _resolver_acao(page, spec)

    if locator.count() <= 0:
        raise RuntimeError(
            f"Ação não encontrada no DOM: {spec!r}"
        )

    runtime.nova_acao_confirmacao(
        f"parceiro:click:{contexto}"
    )
    locator.first.click(timeout=1500)

    # Agora sim houve uma ação que pode processar no SAP.
    runtime.estabilizar(
        contexto=contexto,
        appearance_grace_ms=180,
        auto_reenter=True,
    )


def abrir_partners(
    page: Page,
    runtime,
) -> None:
    """
    Vai do Overview até Partners sem waits de 30s entre telas.

    Regra:
      estado atual -> ação imediata -> reação do SAP -> próximo passo.
    """
    runtime.etapa("PARCEIROS_ABRINDO")

    estado = identificar_estado(page)

    if estado == "HEADER_PARTNERS":
        return

    if estado == "OVERVIEW":
        runtime.logger(
            "[PARTNER] Overview pronto. Clicando Header Details imediatamente."
        )
        _clicar_e_reagir(
            page,
            runtime,
            _SELECTORS["header_details"]["button"],
            contexto="parceiro",
        )
        estado = identificar_estado(page)

    if estado == "HEADER_PARTNERS":
        return

    if estado == "HEADER_DATA":
        runtime.logger(
            "[PARTNER] Header Data pronto. Clicando Partners imediatamente."
        )
        _clicar_e_reagir(
            page,
            runtime,
            _SELECTORS["header_details"]["partners_tab"],
            contexto="parceiro",
        )
        estado = identificar_estado(page)

        if estado == "HEADER_PARTNERS":
            return

    # Se a transição visual ainda não terminou, não dorme 30s:
    # faz apenas uma reação real adicional e reavalia.
    runtime.estabilizar(
        contexto="parceiro",
        appearance_grace_ms=180,
        auto_reenter=True,
    )

    estado = identificar_estado(page)

    if estado == "HEADER_PARTNERS":
        return

    raise SapStateError(
        f"Não foi possível abrir Partners. Estado={estado}"
    )


def _parceiros_da_solicitacao(
    solicitacao: dict,
) -> list[tuple[str, str]]:
    saida: list[tuple[str, str]] = []

    parametros_json = (
        solicitacao.get("parametros_json")
        or {}
    )

    for parceiro in parametros_json.get(
        "partners",
        [],
    ):
        funcao = str(
            parceiro.get("function", "")
        ).strip()
        codigo = str(
            parceiro.get("partner", "")
        ).strip()

        if funcao and codigo:
            saida.append(
                (funcao, codigo)
            )

    for coluna, funcao in _PARTNER_MAP[
        "fixed_columns"
    ].items():
        codigo = solicitacao.get(coluna)

        if codigo is None:
            continue

        codigo = str(codigo).strip()

        if not codigo:
            continue

        if not funcao:
            raise MapeamentoPendente(
                f"Campo {coluna!r} possui valor, "
                "mas não tem Partner Function mapeada."
            )

        saida.append(
            (funcao, codigo)
        )

    consolidado = {}

    for funcao, codigo in saida:
        consolidado[
            funcao.casefold()
        ] = (
            funcao,
            codigo,
        )

    return list(
        consolidado.values()
    )


def manter_parceiro(
    page: Page,
    runtime,
    *,
    funcao: str,
    codigo: str,
) -> None:
    runtime.etapa(
        f"PARCEIRO:{funcao}"
    )

    existente = _achar_funcao(
        page,
        funcao,
    )

    if existente is not None:
        prefix, row, atual = existente

        if atual.strip() == str(codigo).strip():
            runtime.logger(
                f"[PARTNER] Já correto: "
                f"{funcao} -> {codigo}"
            )
            return

        _preencher_partner(
            page,
            prefix,
            row,
            codigo,
            foco_no_partner=False,
            runtime=runtime,
        )

    else:
        prefix, row = _selecionar_funcao(
            page,
            funcao,
            runtime=runtime,
        )

        # O TAB acima já levou ao Partner.
        _preencher_partner(
            page,
            prefix,
            row,
            codigo,
            foco_no_partner=True,
            runtime=runtime,
        )

    # Enter do parceiro = ação de processamento.
    runtime.estabilizar(
        contexto="parceiro",
        appearance_grace_ms=300,
        auto_reenter=True,
    )

    validado = _achar_funcao(
        page,
        funcao,
    )

    if validado is None:
        raise RuntimeError(
            f"Partner Function {funcao!r} "
            "sumiu após preenchimento."
        )

    _, _, final = validado

    if final.strip() != str(codigo).strip():
        raise RuntimeError(
            f"Partner não confirmado. "
            f"{funcao}: esperado={codigo!r}, "
            f"atual={final!r}"
        )

    runtime.logger(
        f"[PARTNER] OK: {funcao} -> {codigo}"
    )


def processar_parceiros(
    page: Page,
    runtime,
    solicitacao: dict,
) -> None:
    parceiros = _parceiros_da_solicitacao(
        solicitacao
    )

    if not parceiros:
        return

    abrir_partners(
        page,
        runtime,
    )

    for funcao, codigo in parceiros:
        manter_parceiro(
            page,
            runtime,
            funcao=funcao,
            codigo=codigo,
        )

    # SAP Back = F3: executa primeiro, trata depois.
    runtime.nova_acao_confirmacao(
        "parceiro:F3 voltar"
    )
    page.keyboard.press("F3")

    runtime.estabilizar(
        contexto="parceiro",
        appearance_grace_ms=350,
        auto_reenter=True,
    )
