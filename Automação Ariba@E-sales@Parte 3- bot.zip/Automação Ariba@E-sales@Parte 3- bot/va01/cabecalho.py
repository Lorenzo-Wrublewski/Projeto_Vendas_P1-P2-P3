from __future__ import annotations

from playwright.sync_api import Page

from app_config import carregar_json
from sap.fields import clicar
from sap.fast_input import preencher_fixos_em_sequencia
from sap.batch_fill import preencher_lote


_SELECTORS = carregar_json("selectors.json")

_SALES_TYPE_VARIANTS = {
    1: {"type": "title", "title": "Choose Text Alternative Order Type 1"},
    2: {"type": "title", "title": "Choose Text Alternative Order Type 2"},
    3: {"type": "title", "title": "Choose Text Alternative Order Type 3"},
}


def _sales_type_variant(solicitacao: dict) -> int | None:
    params = solicitacao.get("parametros_json") or {}

    if not isinstance(params, dict):
        raise RuntimeError(
            "parametros_json da solicitação precisa ser um objeto JSON."
        )

    valor = None
    for chave in (
        "sales_order_type_variant",
        "component_sales_order_type",
        "tipo_componente_venda",
    ):
        if chave in params:
            valor = params.get(chave)
            break

    if valor is None or str(valor).strip() == "":
        return None

    aliases = {
        "1": 1, "type 1": 1, "type1": 1,
        "2": 2, "type 2": 2, "type2": 2,
        "3": 3, "type 3": 3, "type3": 3,
    }
    variante = aliases.get(str(valor).strip().casefold())

    if variante is None:
        raise RuntimeError(
            "sales_order_type_variant inválido. Use 1, 2 ou 3."
        )
    return variante


def aplicar_sales_type_variant(
    page: Page,
    runtime,
    solicitacao: dict,
) -> None:
    variante = _sales_type_variant(solicitacao)
    if variante is None:
        return

    runtime.logger(
        f"[CABECALHO] Sales Order Type visual: Type {variante}"
    )
    clicar(
        page,
        _SALES_TYPE_VARIANTS[variante],
        heartbeat=runtime.heartbeat,
        runtime=runtime,
        contexto="cabecalho",
    )
    runtime.estabilizar(
        contexto="cabecalho",
        appearance_grace_ms=150,
    )


def preencher_cabecalho(
    page: Page,
    runtime,
    solicitacao: dict,
) -> None:
    runtime.etapa("CABECALHO")

    aplicar_sales_type_variant(
        page,
        runtime,
        solicitacao,
    )

    campos = _SELECTORS["overview_header"]

    preenchidos = preencher_lote(
        page,
        runtime,
        [
            {
                "key": "sold_to_party",
                "locator": campos["sold_to_party"],
                "value": solicitacao.get("cliente"),
            },
            {
                "key": "purchase_order",
                "locator": campos["purchase_order"],
                "value": solicitacao.get("pedido_cliente"),
            },
            {
                "key": "po_date",
                "locator": campos["po_date"],
                "value": solicitacao.get("data_pedido"),
            },
        ],
        contexto="cabecalho",
    )

    runtime.logger(
        "[FAST-BATCH] Cabeçalho: "
        f"{preenchidos}"
    )

    runtime.nova_acao_confirmacao(
        "cabecalho:Enter"
    )
    page.keyboard.press("Enter")

    # Só agora trata o SAP.
    runtime.estabilizar(
        contexto="cabecalho",
        appearance_grace_ms=650,
        auto_reenter=True,
        max_reenter=4,
    )

    # Sem espera adicional de Ship-To/OVERVIEW.
    # A abertura de Partners assume o próximo passo imediatamente.
