# -*- coding: utf-8 -*-
"""
portal_sink.py — ponte em TEMPO REAL entre o coletor API (etapa 1) e o Portal.

Versão realtime v1.9.1:
- NÃO usa fila para logs/ordens.
- Cada evento relevante é enviado imediatamente ao Flask.
- Suporta atualização do total da execução após a descoberta dos pedidos.
- Evita backlog visual: o Portal acompanha praticamente junto com o coletor.
- Se o Portal ficar indisponível, a coleta NÃO para: entra em um pequeno
  circuit breaker e tenta novamente depois.
"""

import json
import os
import threading
import time
import urllib.request

PORTAL_URL = os.environ.get("PORTAL_URL", "http://localhost:5000")


class PortalSink:
    def __init__(self, conta, base_url=None, timeout=2.0):
        self.conta = (conta or "ITA").upper()
        self.base = (base_url or PORTAL_URL).rstrip("/")
        self.timeout = float(timeout)
        self.execucao_id = None

        self._lock = threading.Lock()
        self._offline_until = 0.0
        self._offline_retry_seconds = 0.5

        # IMPORTANTE: o ambiente corporativo pode possuir HTTP_PROXY/HTTPS_PROXY.
        # Os callbacks do coletor para o Portal são locais e NÃO podem passar
        # pelo proxy corporativo (isso causava 407/sumiço de eventos no agendador).
        self._direct_opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({})
        )

    def _enviar(self, path, payload, precisa_resposta=False):
        """
        Envio direto/síncrono.

        Como o backend publica no SSE ANTES da gravação assíncrona no banco,
        a resposta costuma ser muito rápida. Assim não existe uma fila local
        crescendo e deixando o Portal vários pedidos atrás do coletor.
        """
        now = time.monotonic()
        if now < self._offline_until:
            return None

        body = {
            "conta": self.conta,
            **(payload or {}),
        }

        if self.execucao_id and "execucao_id" not in body:
            body["execucao_id"] = self.execucao_id

        data = json.dumps(
            body,
            ensure_ascii=False,
            default=str,
        ).encode("utf-8")

        req = urllib.request.Request(
            f"{self.base}{path}",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Cache-Control": "no-cache",
                "Connection": "close",
            },
            method="POST",
        )

        try:
            # Um lock garante ordem dos eventos caso futuramente mais de uma
            # thread do coletor tente escrever no portal.
            with self._lock:
                with self._direct_opener.open(req, timeout=self.timeout) as response:
                    raw = response.read() if precisa_resposta else b""

            self._offline_until = 0.0

            if precisa_resposta and raw:
                try:
                    return json.loads(raw.decode("utf-8"))
                except Exception:
                    return None

            return {}

        except Exception:
            # Portal fora do ar não pode travar a automação.
            # Após uma falha, evitamos repetir timeouts a cada linha.
            self._offline_until = time.monotonic() + self._offline_retry_seconds
            return None

    def abrir_execucao(self, total=0, iniciado_por=None):
        resposta = self._enviar(
            "/api/ingest/execucao/abrir",
            {
                "total": int(total or 0),
                "iniciado_por": iniciado_por,
            },
            precisa_resposta=True,
        )

        if isinstance(resposta, dict):
            self.execucao_id = resposta.get("execucao_id")

        return self.execucao_id

    def log(self, mensagem, nivel="info", etapa=1):
        self._enviar(
            "/api/ingest/log",
            {
                "mensagem": str(mensagem),
                "nivel": nivel,
                "etapa": etapa,
            },
        )

    def atualizar_execucao(self, total=0):
        self._enviar(
            "/api/ingest/execucao/atualizar",
            {
                "total": int(total or 0),
            },
        )

    def ordem(self, numero, **campos):
        self._enviar(
            "/api/ingest/ordem",
            {
                "numero": str(numero),
                **campos,
            },
        )

    def fechar_execucao(self, status="ok", sucesso=0, erros=0, total=0):
        self._enviar(
            "/api/ingest/execucao/fechar",
            {
                "status": status,
                "sucesso": int(sucesso or 0),
                "erros": int(erros or 0),
                "total": int(total or 0),
            },
        )

    # Mantidos por compatibilidade com o coletor atual.
    # Como não existe mais fila, não há nada para drenar.
    def flush(self, timeout=0):
        return None

    def close(self, timeout=0):
        return None



def deduzir_cliente(business_json):
    """Retorna somente o nome informado pela API, sem cadastro ou regra por cliente."""
    nome = (
        (business_json.get("customer") or {}).get("name")
        or (business_json.get("customer") or {}).get("site_name")
        or ""
    )
    return nome or None, None
