# -*- coding: utf-8 -*-
"""
ariba_automation_vAPI.py

Versão consolidada do coletor SAP Business Network 100% via API.

O que mudou em relação ao coletor antigo:
- NÃO usa Playwright.
- NÃO abre navegador.
- NÃO usa usuário/senha do portal.
- Obtém OAuth token pela API.
- Busca os pedidos dos últimos 365 dias em janelas de no máximo 31 dias.
- Consolida a versão mais atual de cada PO por comprador e identifica New Orders pela API.
- Busca e valida os itens de cada New Order pelo endpoint /items.
- Mantém a integração existente com portal_sink.py.
- Salva os JSONs finais em Pedidos Baixados/<conta>/DD-MM-AAAA/.
- Mantém arquivos técnicos em _sistema/<conta>/.
- Não baixa novamente um pedido que já possui JSON final tratado salvo.

Configuração
------------
A aplicação procura primeiro um arquivo `ariba_api_config.json` na mesma pasta.
Se uma chave não existir nele, tenta as variáveis de ambiente equivalentes.

Exemplo de ariba_api_config.json:
{
  "ITA": {
    "anid": "AN01049042430",
    "client_id": "SEU_CLIENT_ID",
    "client_secret": "SEU_OAUTH_SECRET",
    "api_key": "SUA_APPLICATION_KEY"
  },
  "POP": {
    "anid": "AN01055714919",
    "client_id": "SEU_CLIENT_ID",
    "client_secret": "SEU_OAUTH_SECRET",
    "api_key": "SUA_APPLICATION_KEY"
  }
}

Variáveis de ambiente aceitas:
ARIBA_ITA_ANID, ARIBA_ITA_CLIENT_ID, ARIBA_ITA_CLIENT_SECRET, ARIBA_ITA_API_KEY
ARIBA_POP_ANID, ARIBA_POP_CLIENT_ID, ARIBA_POP_CLIENT_SECRET, ARIBA_POP_API_KEY

IMPORTANTE: não coloque OAuth Secret em Git/Bitbucket/GitHub.
"""

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
from urllib.parse import urlencode
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import Tk, StringVar, Text, END, DISABLED, NORMAL
from tkinter import ttk, messagebox

import requests
from requests.auth import HTTPBasicAuth

# --- integração com o Portal Automação ---
try:
    from portal_sink import PortalSink, deduzir_cliente
except Exception:
    PortalSink = None

    def deduzir_cliente(business_json):
        return None, None


# ============================================================
# CONFIGURAÇÃO
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
PEDIDOS_DIR = BASE_DIR / "Pedidos Baixados"
SISTEMA_DIR = BASE_DIR / "_sistema"
# Compatibilidade temporária com a estrutura anterior. Nada novo é salvo aqui.
LEGACY_DATA_DIR = BASE_DIR / "data"
CONFIG_FILE = Path(
    os.environ.get("ARIBA_API_CONFIG", str(BASE_DIR / "ariba_api_config.json"))
)

TOKEN_URL = os.environ.get(
    "ARIBA_TOKEN_URL",
    "https://api.ariba.com/v2/oauth/token",
)

API_BASE_URL = os.environ.get(
    "ARIBA_API_BASE_URL",
    "https://openapi.ariba.com/api/purchase-orders-supplier/v1/prod",
).rstrip("/")

LOOKBACK_DAYS = int(os.environ.get("ARIBA_LOOKBACK_DAYS", "365"))
PAGE_SIZE = 100
REQUEST_TIMEOUT = int(os.environ.get("ARIBA_REQUEST_TIMEOUT", "45"))
MAX_RETRIES = int(os.environ.get("ARIBA_MAX_RETRIES", "4"))
COLLECTOR_VERSION = "1.9.0"

# ANIDs não são segredo. As demais chaves devem vir do config local ou ambiente.
PROFILE_DEFAULTS = {
    # Nada de credencial/ANID hardcoded: tudo vem do ariba_api_config.json
    # ou das variáveis de ambiente ARIBA_<CONTA>_*.
    "ITA": {"anid": "", "client_id": "", "client_secret": "", "api_key": ""},
    "POP": {"anid": "", "client_id": "", "client_secret": "", "api_key": ""},
}

PLACEHOLDER_MARKERS = (
    "SEU_",
    "SUA_",
    "COLOQUE_",
    "CLIENT_ID_AQUI",
    "SECRET_AQUI",
    "API_KEY_AQUI",
)


# ============================================================
# UTILIDADES
# ============================================================


def ensure_dirs():
    PEDIDOS_DIR.mkdir(parents=True, exist_ok=True)
    SISTEMA_DIR.mkdir(parents=True, exist_ok=True)

    for account in ("ITA", "POP"):
        (PEDIDOS_DIR / account).mkdir(parents=True, exist_ok=True)
        (SISTEMA_DIR / account / "respostas_api").mkdir(parents=True, exist_ok=True)
        (SISTEMA_DIR / account / "historico_consultas").mkdir(parents=True, exist_ok=True)
        (SISTEMA_DIR / account / "historico_execucoes").mkdir(parents=True, exist_ok=True)


def _truthy(value, default=True):
    if value is None:
        return default
    return str(value).strip().lower() not in {"0", "false", "no", "off", "nao", "não"}


def load_api_profiles():
    """Carrega config local e aplica variáveis de ambiente por cima."""
    profiles = json.loads(json.dumps(PROFILE_DEFAULTS))

    if CONFIG_FILE.exists():
        try:
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(
                f"Não consegui ler {CONFIG_FILE.name}: {exc}"
            ) from exc

        if not isinstance(raw, dict):
            raise RuntimeError(
                f"{CONFIG_FILE.name} precisa conter um objeto JSON com ITA/POP."
            )

        for account in profiles:
            block = raw.get(account) or {}
            if isinstance(block, dict):
                for key in ("anid", "client_id", "client_secret", "api_key"):
                    if block.get(key) is not None:
                        profiles[account][key] = str(block.get(key)).strip()

    for account in profiles:
        prefix = f"ARIBA_{account}_"
        env_map = {
            "anid": prefix + "ANID",
            "client_id": prefix + "CLIENT_ID",
            "client_secret": prefix + "CLIENT_SECRET",
            "api_key": prefix + "API_KEY",
        }

        for key, env_name in env_map.items():
            value = os.environ.get(env_name)
            if value is not None and value.strip():
                profiles[account][key] = value.strip()

    return profiles


def validate_profile(account, profile):
    required = ("anid", "client_id", "client_secret", "api_key")
    missing = []

    for key in required:
        value = str(profile.get(key) or "").strip()
        if not value or value.upper().startswith(PLACEHOLDER_MARKERS):
            missing.append(key)

    if missing:
        names = ", ".join(missing)
        raise RuntimeError(
            f"Configuração da API para {account} incompleta: {names}. "
            f"Preencha {CONFIG_FILE.name} ou as variáveis ARIBA_{account}_*."
        )


def clean_text(value):
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def parse_decimal(value):
    if value is None or value == "":
        return None

    if isinstance(value, bool):
        return None

    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()
    if not text:
        return None

    # formato brasileiro simples: 1.234,56
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
    elif "," in text:
        text = text.replace(",", ".")

    text = re.sub(r"[^0-9+\-.]", "", text)
    if not text or text in {"-", "+", "."}:
        return None

    try:
        return float(text)
    except ValueError:
        return None


_MONTHS = {
    "jan": 1,
    "feb": 2,
    "mar": 3,
    "apr": 4,
    "may": 5,
    "jun": 6,
    "jul": 7,
    "aug": 8,
    "sep": 9,
    "oct": 10,
    "nov": 11,
    "dec": 12,
}


def parse_ariba_datetime(value):
    """Converte datas como '27 Aug 2026 3:15:23 AM' sem depender do locale."""
    if not value:
        return None

    text = str(value).strip()

    # Primeiro tenta ISO.
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        pass

    match = re.match(
        r"^(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})\s+"
        r"(\d{1,2}):(\d{2}):(\d{2})\s+(AM|PM)$",
        text,
        re.I,
    )

    if not match:
        return None

    day, mon_txt, year, hour, minute, second, ampm = match.groups()
    month = _MONTHS.get(mon_txt.lower())
    if not month:
        return None

    hour = int(hour)
    if ampm.upper() == "PM" and hour != 12:
        hour += 12
    if ampm.upper() == "AM" and hour == 12:
        hour = 0

    try:
        return datetime(
            int(year), month, int(day), hour, int(minute), int(second)
        )
    except ValueError:
        return None


def iso_date_only(value):
    parsed = parse_ariba_datetime(value)
    if parsed:
        return parsed.strftime("%Y-%m-%d")

    if value:
        text = str(value).strip()
        match = re.match(r"^(\d{4}-\d{2}-\d{2})", text)
        if match:
            return match.group(1)

    return None


def format_api_datetime(value):
    return value.strftime("%Y-%m-%dT%H:%M:%S")


def date_windows_last_days(days=365):
    """
    Gera janelas não sobrepostas com no máximo 31 dias, limite da SAP.

    Para manter coerência com o card 'Últimos 365 dias', contamos o dia atual
    dentro do período. Assim, 365 dias começa em D-364 e termina hoje.
    """
    now = datetime.now()
    final_end = now.replace(hour=23, minute=59, second=59, microsecond=0)

    # O card "Últimos 365 dias" conta 365 datas de calendário,
    # incluindo o dia atual. Portanto, para 365 dias, o início é D-364.
    # Ex.: 01/09/2026 -> 02/09/2025, totalizando exatamente 365 datas.
    calendar_days = max(1, int(days))
    start = (now - timedelta(days=calendar_days - 1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )

    cursor = start
    while cursor <= final_end:
        window_end = min(
            cursor + timedelta(days=31) - timedelta(seconds=1),
            final_end,
        )
        yield cursor, window_end
        cursor = window_end + timedelta(seconds=1)


def query_windows_for_period(period):
    """Retorna janelas da API para 24h exatas ou 365 dias de calendário."""
    period = str(period or "365d").strip().lower()

    if period == "24h":
        end = datetime.now().replace(microsecond=0)
        start = end - timedelta(hours=24)
        return [(start, end)]

    if period == "365d":
        return list(date_windows_last_days(365))

    raise ValueError(f"Período inválido: {period}. Use 24h ou 365d.")


def period_label(period):
    return "últimas 24 horas" if str(period).lower() == "24h" else "últimos 365 dias"


def safe_filename(value):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "unknown"))


def save_json_file(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    return path


def _ci_get(mapping, names):
    if not isinstance(mapping, dict):
        return None

    lowered = {str(k).lower(): v for k, v in mapping.items()}
    for name in names:
        if name in mapping:
            return mapping[name]
        found = lowered.get(str(name).lower())
        if found is not None:
            return found
    return None


def deep_find(obj, names, max_depth=4):
    """Busca uma chave por aliases, primeiro no nível atual e depois em filhos."""
    if max_depth < 0:
        return None

    if isinstance(obj, dict):
        direct = _ci_get(obj, names)
        if direct is not None:
            return direct

        for value in obj.values():
            if isinstance(value, (dict, list)):
                found = deep_find(value, names, max_depth=max_depth - 1)
                if found is not None:
                    return found

    elif isinstance(obj, list):
        for value in obj:
            found = deep_find(value, names, max_depth=max_depth - 1)
            if found is not None:
                return found

    return None


def money_parts(value, fallback_currency=None):
    if isinstance(value, dict):
        amount = _ci_get(value, ["amount", "value", "price"])
        currency = _ci_get(
            value,
            ["currencyCode", "currency", "currency_code", "currencyUniqueName"],
        )
        return parse_decimal(amount), clean_text(currency) or fallback_currency

    return parse_decimal(value), fallback_currency


def normalize_bool(value):
    """Normaliza bool, Y/N, S/N, yes/no, true/false sem inventar valor."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)

    raw = str(value).strip().lower()
    if raw in {"y", "yes", "true", "1", "s", "sim"}:
        return True
    if raw in {"n", "no", "false", "0", "nao", "não"}:
        return False
    return None


def normalize_cnpj(value):
    if value is None:
        return None
    digits = re.sub(r"\D", "", str(value))
    if len(digits) != 14:
        return None
    return (
        f"{digits[:2]}.{digits[2:5]}.{digits[5:8]}/"
        f"{digits[8:12]}-{digits[12:]}"
    )


def extract_cnpjs(*values):
    found = []
    seen = set()

    for value in values:
        if value is None:
            continue
        text_value = str(value)
        # Com ou sem pontuação.
        for match in re.finditer(
            r"(?<!\d)(\d{2}[.\s]?\d{3}[.\s]?\d{3}[\/\s]?\d{4}[-\s]?\d{2})(?!\d)",
            text_value,
        ):
            normalized = normalize_cnpj(match.group(1))
            if normalized and normalized not in seen:
                seen.add(normalized)
                found.append(normalized)

    return found


def is_placeholder_part_number(value):
    value = clean_text(value)
    if not value:
        return False

    compact = re.sub(r"[^A-Za-z0-9]", "", value).upper()
    if not compact:
        return False

    return (
        set(compact) == {"0"}
        or compact in {"NA", "NAN", "NONE", "NULL", "NOTAPPLICABLE"}
    )


def first_direct(mapping, names):
    """Busca aliases apenas no objeto atual, evitando capturar campos aninhados errados."""
    return _ci_get(mapping, names) if isinstance(mapping, dict) else None


def unique_dict_items(items):
    """Remove somente duplicatas JSON idênticas; nunca mescla linhas diferentes."""
    result = []
    seen = set()
    for item in items or []:
        try:
            signature = json.dumps(
                item, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
            )
        except Exception:
            signature = repr(item)
        if signature in seen:
            continue
        seen.add(signature)
        result.append(item)
    return result


def numeric_sort_key(value):
    text_value = clean_text(value)
    if text_value is None:
        return (1, "")
    try:
        return (0, int(float(text_value)))
    except Exception:
        return (1, text_value)


def order_identity_key(order):
    """
    documentNumber sozinho não é universalmente único entre compradores.
    A identidade segura para o fornecedor é buyer/customer ANID + documentNumber.
    """
    return (
        clean_text(order.get("customerANID")) or "",
        clean_text(order.get("documentNumber")) or "",
    )


def order_identity_text(order):
    buyer_anid, number = order_identity_key(order)
    return f"{buyer_anid}:{number}" if buyer_anid else number


def parse_payment_terms(order_header):
    raw_terms = order_header.get("paymentTerms") or []
    if not isinstance(raw_terms, list):
        raw_terms = [raw_terms]

    terms = [clean_text(x) for x in raw_terms if clean_text(x)]
    explanation = clean_text(order_header.get("paymentTermsExplanation"))

    code = None
    description = explanation

    # Exemplos reais: Z030-30 dias..., Y017-Vence...
    if explanation:
        match = re.match(r"^\s*([A-Z][A-Z0-9]{2,})\s*[-–]\s*(.+?)\s*$", explanation)
        if match:
            code = clean_text(match.group(1))
            description = clean_text(match.group(2))

    # Se a explicação não traz código, o paymentTerms da API é a melhor fonte.
    if not code and terms:
        code = terms[0]

    detail = explanation or (" | ".join(terms) if terms else None)

    return {
        "terms": terms,
        "code": code,
        "description": description,
        "detail": detail,
    }


def normalize_accounting_distribution(raw_item):
    dist = first_direct(raw_item, ["accountingDistribution", "accounting_distribution"])
    if not isinstance(dist, dict):
        return {
            "accounting_name": None,
            "general_ledger": None,
            "cost_center": None,
            "percentage": None,
            "segments": [],
            "distribution_charge": {
                "amount": None,
                "currency": None,
                "approx": None,
                "conversion_date": None,
            },
        }

    raw_segments = dist.get("accountingSegments") or []
    if not isinstance(raw_segments, list):
        raw_segments = [raw_segments]

    segments = []
    by_name = {}
    for segment in raw_segments:
        if not isinstance(segment, dict):
            continue
        name = clean_text(segment.get("name"))
        code = clean_text(segment.get("code"))
        normalized = {
            "name": name,
            "code": code,
            "description": clean_text(segment.get("description")),
        }
        segments.append(normalized)
        if name and name.lower() not in by_name:
            by_name[name.lower()] = code

    charge = dist.get("charge")
    charge_amount, charge_currency = money_parts(charge)
    charge_approx = parse_decimal(charge.get("approx")) if isinstance(charge, dict) else None
    charge_conversion = (
        clean_text(charge.get("conversionDate")) if isinstance(charge, dict) else None
    )

    return {
        "accounting_name": clean_text(dist.get("accountingName")),
        "general_ledger": by_name.get("generalledger"),
        "cost_center": by_name.get("costcenter"),
        "percentage": parse_decimal(by_name.get("percentage")),
        "segments": segments,
        "distribution_charge": {
            "amount": charge_amount,
            "currency": charge_currency,
            "approx": charge_approx,
            "conversion_date": charge_conversion,
        },
    }


def build_collection_analysis(order_header, items, raw_items):
    issues = []
    warnings = []
    missing = []

    order_number = clean_text(order_header.get("documentNumber"))
    customer_name = clean_text(order_header.get("customerName"))
    supplier_name = clean_text(order_header.get("supplierName"))
    order_status = clean_text(order_header.get("status"))
    dashboard_status = clean_text(order_header.get("dashboardStatus"))
    order_date = iso_date_only(order_header.get("orderDate"))

    essential = {
        "order_number": order_number,
        "customer.name": customer_name,
        "supplier.name": supplier_name,
        "order.status": order_status,
        "order.dashboard_status": dashboard_status,
        "order.date": order_date,
    }
    for field, value in essential.items():
        if value in (None, "", []):
            missing.append(field)

    if not items:
        missing.append("items")
        issues.append({
            "field": "items",
            "reason": "items_endpoint_returned_zero_rows",
        })

    # Confere se /items pertence realmente ao cabeçalho.
    mismatched_documents = sorted({
        clean_text(x.get("documentNumber"))
        for x in (raw_items or [])
        if isinstance(x, dict)
        and clean_text(x.get("documentNumber"))
        and clean_text(x.get("documentNumber")) != order_number
    })
    if mismatched_documents:
        issues.append({
            "field": "items.documentNumber",
            "reason": "item_document_number_mismatch",
            "values": mismatched_documents,
        })

    line_numbers = [
        clean_text(item.get("line_number"))
        for item in items
        if clean_text(item.get("line_number"))
    ]
    duplicates = sorted({
        line for line in line_numbers if line_numbers.count(line) > 1
    }, key=numeric_sort_key)
    if duplicates:
        issues.append({
            "field": "items.line_number",
            "reason": "duplicate_line_numbers",
            "values": duplicates,
        })

    for index, item in enumerate(items, start=1):
        line = item.get("line_number") or str(index)
        for field in ("line_number", "description", "quantity", "uom"):
            if item.get(field) in (None, "", []):
                missing.append(f"items[{line}].{field}")

        if item.get("supplier_part_is_placeholder"):
            warnings.append({
                "field": "supplier_part_number",
                "line_number": line,
                "reason": "supplier_part_is_placeholder",
                "value": item.get("supplier_part_number"),
            })

        # Ausência de unit price é comum em alguns POs; preservamos sem tratar como erro.
        if item.get("unit_price") is None:
            warnings.append({
                "field": "unit_price",
                "line_number": line,
                "reason": "not_returned_by_api",
            })

    # Remove repetição de missing mantendo ordem.
    missing = list(dict.fromkeys(missing))

    fatal = (not order_number) or (not items) or bool(mismatched_documents)
    if fatal:
        quality = "ERROR"
    elif issues or missing:
        quality = "REVIEW"
    else:
        quality = "OK"

    return {
        "status": "PENDING",
        "collection_quality": quality,
        "collection_issues": issues,
        "warnings": warnings,
        "missing_fields": missing,
        "issues": [],
        "decision": None,
        "collector": "SAP Business Network Purchase Orders Supplier API",
        "collector_version": COLLECTOR_VERSION,
        "raw_preserved": True,
        "item_count": len(items),
    }



# ============================================================
# CLIENTE SAP ARIBA API
# ============================================================


class AribaAPIError(RuntimeError):
    pass


class AribaAPIClient:
    def __init__(self, account, profile, log):
        self.account = account
        self.profile = profile
        self.log = log
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "User-Agent": f"Bosch-Rexroth-Ariba-Automation/{COLLECTOR_VERSION}",
        })

        # Rede corporativa / proxy:
        # requests herda HTTP(S)_PROXY, mas não negocia automaticamente a
        # autenticação integrada (407) do proxy corporativo. Em Windows, o
        # curl.exe distribuído com SSPI consegue usar as credenciais da sessão
        # já logada via Negotiate/NTLM sem guardar usuário/senha no script.
        #
        # auto (padrão): requests primeiro; ao receber 407, muda para curl+SSPI.
        # curl: usa curl+SSPI desde a primeira chamada.
        # direct: ignora o proxy e tenta conexão direta.
        # environment: mantém somente o requests + ambiente, sem fallback.
        self.proxy_mode = (os.environ.get("ARIBA_PROXY_MODE", "auto") or "auto").strip().lower()
        if self.proxy_mode not in {"auto", "curl", "direct", "environment"}:
            self.proxy_mode = "auto"
        if self.proxy_mode == "direct":
            self.session.trust_env = False

        self._use_curl_proxy = self.proxy_mode == "curl"
        self._curl_path = shutil.which("curl.exe") or shutil.which("curl")
        self._proxy_fallback_announced = False

        self.access_token = None
        self.token_obtained_at = 0.0
        self.token_expires_in = 0
        self.verify_ssl = _truthy(os.environ.get("ARIBA_VERIFY_SSL"), default=True)

    @property
    def anid(self):
        return self.profile["anid"]

    @staticmethod
    def _is_proxy_407(exc):
        message = str(exc)
        return (
            isinstance(exc, requests.exceptions.ProxyError)
            and (
                "407" in message
                or "Proxy Authentication Required" in message
                or "Tunnel connection failed" in message
            )
        )

    @staticmethod
    def _parse_curl_headers(raw_headers):
        """Extrai apenas o último bloco HTTP gravado por curl --dump-header."""
        from requests.structures import CaseInsensitiveDict

        text = (raw_headers or "").replace("\r\n", "\n")
        blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
        chosen = ""
        for block in reversed(blocks):
            if block.lstrip().upper().startswith("HTTP/"):
                chosen = block
                break

        headers = CaseInsensitiveDict()
        if not chosen:
            return headers

        lines = chosen.split("\n")
        for line in lines[1:]:
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            headers[key.strip()] = value.strip()
        return headers

    def _curl_request(self, method, url, **kwargs):
        """
        Faz a mesma chamada por curl.exe usando autenticação integrada do
        usuário Windows no PROXY (--proxy-anyauth -U :). O OAuth/Bearer nunca
        é colocado na linha de comando: os headers ficam em arquivo temporário.
        """
        if not self._curl_path:
            raise requests.ConnectionError(
                "O proxy exige autenticação (407), mas curl.exe não foi encontrado "
                "no Windows/PATH para usar autenticação integrada SSPI."
            )

        params = kwargs.get("params")
        prepared = requests.Request(method=str(method).upper(), url=url, params=params).prepare()
        final_url = prepared.url

        headers = dict(self.session.headers)
        headers.update(kwargs.get("headers") or {})

        auth = kwargs.get("auth")
        if isinstance(auth, HTTPBasicAuth):
            raw = f"{auth.username}:{auth.password}".encode("utf-8")
            headers["Authorization"] = "Basic " + base64.b64encode(raw).decode("ascii")

        body = None
        if kwargs.get("json") is not None:
            body = json.dumps(kwargs["json"], ensure_ascii=False).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        elif kwargs.get("data") is not None:
            data = kwargs.get("data")
            if isinstance(data, dict):
                body = urlencode(data, doseq=True).encode("utf-8")
                headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
            elif isinstance(data, bytes):
                body = data
            else:
                body = str(data).encode("utf-8")

        timeout = kwargs.get("timeout", REQUEST_TIMEOUT)
        try:
            timeout = max(1, int(float(timeout)))
        except Exception:
            timeout = REQUEST_TIMEOUT

        tmp_dir = Path(tempfile.mkdtemp(prefix="ariba_curl_"))
        header_in = tmp_dir / "request_headers.txt"
        header_out = tmp_dir / "response_headers.txt"
        body_out = tmp_dir / "response_body.bin"
        body_in = tmp_dir / "request_body.bin"

        try:
            header_lines = []
            for key, value in headers.items():
                if value is None:
                    continue
                # Proteção contra quebra de header acidental/injetada.
                safe_value = str(value).replace("\r", "").replace("\n", "")
                header_lines.append(f"{key}: {safe_value}")
            header_in.write_text("\n".join(header_lines) + "\n", encoding="utf-8")

            cmd = [
                self._curl_path,
                "--silent",
                "--show-error",
                "--ssl-no-revoke",
                "--request", str(method).upper(),
                "--url", final_url,
                "--proxy-anyauth",
                "--proxy-user", ":",
                "--max-time", str(timeout),
                "--connect-timeout", str(min(timeout, 20)),
                "--header", f"@{header_in}",
                "--dump-header", str(header_out),
                "--output", str(body_out),
                "--write-out", "%{http_code}",
            ]

            if not kwargs.get("verify", self.verify_ssl):
                cmd.append("--insecure")

            if body is not None:
                body_in.write_bytes(body)
                cmd.extend(["--data-binary", f"@{body_in}"])

            completed = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout + 10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )

            if completed.returncode != 0:
                detail = (completed.stderr or completed.stdout or "erro desconhecido").strip()
                raise requests.ConnectionError(
                    f"curl.exe não conseguiu atravessar o proxy corporativo: {detail}"
                )

            status_text = (completed.stdout or "").strip()
            match = re.search(r"(\d{3})\s*$", status_text)
            if not match:
                raise requests.ConnectionError(
                    f"curl.exe terminou sem informar HTTP status (saída: {status_text!r})."
                )

            response = requests.Response()
            response.status_code = int(match.group(1))
            response.url = final_url
            response._content = body_out.read_bytes() if body_out.exists() else b""
            raw_headers = header_out.read_text(encoding="iso-8859-1", errors="replace") if header_out.exists() else ""
            response.headers = self._parse_curl_headers(raw_headers)
            response.encoding = requests.utils.get_encoding_from_headers(response.headers) or "utf-8"
            return response
        finally:
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
            except Exception:
                pass

    def _request(self, method, url, **kwargs):
        """
        Transporte corporativo:
        1) tenta requests normalmente;
        2) se o proxy responder 407, NÃO tenta mais acesso direto (a rede exige
           o proxy); troca para curl.exe + Windows SSPI e reaproveita o login
           corporativo atual para autenticação no proxy.
        """
        if self._use_curl_proxy:
            return self._curl_request(method, url, **kwargs)

        try:
            return self.session.request(method, url, **kwargs)
        except requests.RequestException as exc:
            if self.proxy_mode == "auto" and self._is_proxy_407(exc):
                if not self._proxy_fallback_announced:
                    self.log(
                        f"[{self.account}] Proxy corporativo exige autenticação (407). "
                        "Mudando para curl.exe + credenciais Windows (SSPI)..."
                    )
                    self._proxy_fallback_announced = True

                self._use_curl_proxy = True
                response = self._curl_request(method, url, **kwargs)
                self.log(
                    f"[{self.account}] Proxy corporativo autenticado com a sessão Windows."
                )
                return response
            raise

    @staticmethod
    def _safe_response_message(response):
        try:
            payload = response.json()
            if isinstance(payload, dict):
                msg = (
                    payload.get("message")
                    or payload.get("error_description")
                    or payload.get("error")
                )
                if msg:
                    return str(msg)[:600]
                return json.dumps(payload, ensure_ascii=False)[:600]
        except Exception:
            pass
        return (response.text or "sem mensagem").strip()[:600]

    @staticmethod
    def _retry_delay(response, attempt):
        if response is not None:
            raw = response.headers.get("Retry-After")
            if raw:
                try:
                    return min(max(float(raw), 0.5), 30.0)
                except Exception:
                    pass
        return min(1.5 * attempt, 8.0)

    def obtain_token(self, force=False):
        # Renova um pouco antes do limite, quando expires_in estiver disponível.
        if not force and self.access_token:
            age = time.time() - self.token_obtained_at
            if self.token_expires_in <= 0:
                return self.access_token

            margin = min(60.0, max(5.0, self.token_expires_in * 0.10))
            safe_ttl = max(1.0, self.token_expires_in - margin)
            if age < safe_ttl:
                return self.access_token

        last_error = None

        for attempt in range(1, MAX_RETRIES + 1):
            self.log(
                f"[{self.account}] Solicitando OAuth token..."
                if attempt == 1
                else f"[{self.account}] Repetindo OAuth token ({attempt}/{MAX_RETRIES})..."
            )

            response = None
            try:
                response = self._request(
                    "POST",
                    TOKEN_URL,
                    auth=HTTPBasicAuth(
                        self.profile["client_id"],
                        self.profile["client_secret"],
                    ),
                    data={"grant_type": "client_credentials"},
                    headers={"Accept": "application/json"},
                    timeout=REQUEST_TIMEOUT,
                    verify=self.verify_ssl,
                )
            except requests.RequestException as exc:
                last_error = f"falha de rede ao gerar token: {exc}"
                if attempt < MAX_RETRIES:
                    time.sleep(self._retry_delay(None, attempt))
                    continue
                raise AribaAPIError(last_error) from exc

            if response.status_code == 200:
                try:
                    payload = response.json()
                except ValueError as exc:
                    raise AribaAPIError(
                        "OAuth retornou HTTP 200, mas a resposta não é JSON."
                    ) from exc

                token = payload.get("access_token")
                if not token:
                    raise AribaAPIError("OAuth respondeu sem access_token.")

                self.access_token = token
                self.token_obtained_at = time.time()
                try:
                    self.token_expires_in = int(payload.get("expires_in") or 0)
                except Exception:
                    self.token_expires_in = 0

                self.log(f"[{self.account}] OAuth token obtido com sucesso.")
                return token

            last_error = (
                f"OAuth HTTP {response.status_code}: "
                f"{self._safe_response_message(response)}"
            )

            if response.status_code in {429, 500, 502, 503, 504} and attempt < MAX_RETRIES:
                self.log(
                    f"[{self.account}] OAuth temporariamente indisponível "
                    f"({last_error})."
                )
                time.sleep(self._retry_delay(response, attempt))
                continue

            raise AribaAPIError(last_error)

        raise AribaAPIError(last_error or "Falha desconhecida ao gerar OAuth token.")

    def _headers(self):
        token = self.obtain_token()
        return {
            "Authorization": f"Bearer {token}",
            "apiKey": self.profile["api_key"],
            "X-ARIBA-NETWORK-ID": self.profile["anid"],
            "Accept": "application/json",
        }

    def get(self, endpoint, params=None):
        url = f"{API_BASE_URL}/{endpoint.lstrip('/')}"
        last_error = None
        token_refreshed = False

        for attempt in range(1, MAX_RETRIES + 1):
            response = None
            try:
                response = self._request(
                    "GET",
                    url,
                    headers=self._headers(),
                    params=params,
                    timeout=REQUEST_TIMEOUT,
                    verify=self.verify_ssl,
                )
            except requests.RequestException as exc:
                last_error = f"falha de rede: {exc}"
                if attempt < MAX_RETRIES:
                    time.sleep(self._retry_delay(None, attempt))
                    continue
                raise AribaAPIError(last_error) from exc

            if response.status_code == 401 and not token_refreshed:
                self.log(
                    f"[{self.account}] HTTP 401; renovando token e repetindo a chamada."
                )
                self.obtain_token(force=True)
                token_refreshed = True
                if attempt < MAX_RETRIES:
                    continue

            if response.status_code in {429, 500, 502, 503, 504} and attempt < MAX_RETRIES:
                last_error = (
                    f"HTTP {response.status_code}: "
                    f"{self._safe_response_message(response)}"
                )
                self.log(
                    f"[{self.account}] API temporariamente indisponível "
                    f"({last_error}). Retry {attempt}/{MAX_RETRIES}."
                )
                time.sleep(self._retry_delay(response, attempt))
                continue

            if response.status_code != 200:
                raise AribaAPIError(
                    f"GET {endpoint} retornou HTTP {response.status_code}: "
                    f"{self._safe_response_message(response)}"
                )

            try:
                payload = response.json()
            except ValueError as exc:
                raise AribaAPIError(
                    f"GET {endpoint} retornou HTTP 200, mas a resposta não é JSON."
                ) from exc

            if not isinstance(payload, dict):
                raise AribaAPIError(
                    f"GET {endpoint} retornou JSON inesperado "
                    f"({type(payload).__name__}); esperado objeto."
                )

            return payload

        raise AribaAPIError(last_error or f"Falha desconhecida em GET {endpoint}.")

    def get_all_pages(self, endpoint, filter_text=None):
        items = []
        skip = 0
        expected_count = None
        page_number = 0
        seen_page_signatures = set()

        while True:
            page_number += 1
            params = {
                "$top": PAGE_SIZE,
                "$skip": skip,
                "$count": "true",
            }
            if filter_text:
                params["$filter"] = filter_text

            payload = self.get(endpoint, params=params)
            content = payload.get("content") or []

            if not isinstance(content, list):
                raise AribaAPIError(
                    f"/{endpoint}: campo content veio como "
                    f"{type(content).__name__}, não lista."
                )

            if expected_count is None:
                try:
                    expected_count = int(payload.get("count"))
                except Exception:
                    expected_count = None

            # Proteção contra API repetir exatamente a mesma página para skips
            # diferentes. Usamos o JSON do primeiro/último registro porque /items
            # não possui payloadId em todas as linhas.
            if content:
                try:
                    first_sig = json.dumps(
                        content[0], ensure_ascii=False, sort_keys=True, default=str
                    )
                    last_sig = json.dumps(
                        content[-1], ensure_ascii=False, sort_keys=True, default=str
                    )
                except Exception:
                    first_sig = repr(content[0])
                    last_sig = repr(content[-1])

                signature = (len(content), first_sig, last_sig)
                if signature in seen_page_signatures:
                    raise AribaAPIError(
                        f"/{endpoint}: a API repetiu uma página durante a paginação "
                        f"(skip={skip}); interrompido para não gerar dados duplicados."
                    )
                seen_page_signatures.add(signature)

            items.extend(content)

            last_page = payload.get("lastPage")
            if last_page is True:
                break

            if not content:
                break

            if len(content) < PAGE_SIZE:
                break

            skip += PAGE_SIZE

            if expected_count is not None and skip >= expected_count:
                break

            if page_number > 10000:
                raise AribaAPIError(
                    f"Proteção de paginação acionada em /{endpoint}."
                )

        # Se a API declarou count, não aceitamos coleta truncada silenciosamente.
        if expected_count is not None and len(items) < expected_count:
            raise AribaAPIError(
                f"/{endpoint}: paginação incompleta; API informou {expected_count} "
                f"registro(s), mas foram coletados {len(items)}."
            )

        return items

    def fetch_orders_window(self, start, end):
        filter_text = (
            f"startDate eq {format_api_datetime(start)} and "
            f"endDate eq {format_api_datetime(end)}"
        )
        return self.get_all_pages("orders", filter_text=filter_text)

    def fetch_items_for_order(self, order_header):
        order_number = clean_text(order_header.get("documentNumber"))
        buyer_anid = clean_text(order_header.get("customerANID"))

        if not order_number:
            raise AribaAPIError("Pedido sem documentNumber; não consigo consultar /items.")

        parts = [f"documentNumber eq {order_number}"]
        if buyer_anid:
            parts.append(f"buyerANID eq {buyer_anid}")

        # O filtro startDate/endDate é sobre quando o Business Network recebeu
        # o pedido. Restringimos ao dia do cabeçalho para não misturar revisões.
        created_dt = parse_ariba_datetime(order_header.get("created"))
        if created_dt:
            day_start = created_dt.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = created_dt.replace(hour=23, minute=59, second=59, microsecond=0)
            parts.append(f"startDate eq {format_api_datetime(day_start)}")
            parts.append(f"endDate eq {format_api_datetime(day_end)}")

        result = self.get_all_pages("items", filter_text=" and ".join(parts))

        # Fallback controlado: PO + buyer ANID, caso o tenant indexe a linha
        # em outra data. Mantemos o comprador no filtro para evitar colisão.
        if not result and created_dt:
            fallback_parts = [f"documentNumber eq {order_number}"]
            if buyer_anid:
                fallback_parts.append(f"buyerANID eq {buyer_anid}")
            self.log(
                f"Pedido {order_number}: /items vazio no dia do recebimento; "
                "tentando fallback por PO + buyer ANID."
            )
            result = self.get_all_pages(
                "items",
                filter_text=" and ".join(fallback_parts),
            )

        # Nunca aceitamos silenciosamente itens de outro documentNumber.
        mismatched = [
            row for row in result
            if isinstance(row, dict)
            and clean_text(row.get("documentNumber"))
            and clean_text(row.get("documentNumber")) != order_number
        ]
        if mismatched:
            values = sorted({
                clean_text(row.get("documentNumber"))
                for row in mismatched
                if clean_text(row.get("documentNumber"))
            })
            raise AribaAPIError(
                f"Pedido {order_number}: /items retornou linhas de outro pedido: "
                + ", ".join(values)
            )

        deduped = unique_dict_items(result)
        if len(deduped) != len(result):
            self.log(
                f"Pedido {order_number}: removidas "
                f"{len(result) - len(deduped)} duplicata(s) JSON idêntica(s) de /items."
            )

        deduped.sort(
            key=lambda row: numeric_sort_key(
                row.get("lineNumber") if isinstance(row, dict) else None
            )
        )
        return deduped


# ============================================================
# NEW ORDERS
# ============================================================


def _order_version_key(order):
    try:
        version = int(order.get("poVersion") or 0)
    except Exception:
        version = 0

    created = parse_ariba_datetime(order.get("created")) or datetime.min
    return version, created


def select_current_order_versions(records):
    """
    A API pode devolver várias revisões do mesmo documentNumber.

    Importante: documentNumber pode se repetir entre compradores diferentes.
    Por isso consolidamos por (customerANID, documentNumber), não apenas pela PO.
    """
    latest = {}

    for order in records:
        if not isinstance(order, dict):
            continue

        buyer_anid, number = order_identity_key(order)
        if not number:
            continue

        key = (buyer_anid, number)
        previous = latest.get(key)
        if previous is None or _order_version_key(order) > _order_version_key(previous):
            latest[key] = order

    return latest


def _document_number_collisions(current_by_identity):
    by_number = {}
    for (buyer_anid, number), order in current_by_identity.items():
        by_number.setdefault(number, set()).add(buyer_anid or "")

    return {
        number: sorted(x for x in buyers if x)
        for number, buyers in by_number.items()
        if len(buyers) > 1
    }


def collect_new_orders(client, log, period="365d"):
    all_records = []
    windows = query_windows_for_period(period)

    if period == "24h":
        log("Buscando pedidos das últimas 24 horas...")
        if windows:
            log(
                f"Período efetivo: {windows[0][0]:%d/%m/%Y %H:%M:%S} até "
                f"{windows[-1][1]:%d/%m/%Y %H:%M:%S}."
            )
    else:
        log(
            f"Buscando pedidos dos últimos 365 dias "
            f"em {len(windows)} janela(s) de até 31 dias..."
        )
        if windows:
            log(
                f"Período efetivo: {windows[0][0]:%d/%m/%Y} até "
                f"{windows[-1][1]:%d/%m/%Y} "
                "(365 dias de calendário, incluindo hoje)."
            )

    for index, (start, end) in enumerate(windows, start=1):
        log(
            f"Janela {index}/{len(windows)}: "
            f"{start:%d/%m/%Y} até {end:%d/%m/%Y}"
        )

        records = client.fetch_orders_window(start, end)
        all_records.extend(records)

        log(f"Janela {index}: {len(records)} registro(s) retornado(s).")

    current_by_identity = select_current_order_versions(all_records)
    collisions = _document_number_collisions(current_by_identity)

    # Regra empiricamente validada contra o Workbench ITA em 01/09/2026:
    # 73 PO_NEW na API -> 7 sem poVersion + 1 Acknowledged -> 65 no tile.
    api_po_new = [
        order
        for order in current_by_identity.values()
        if str(order.get("dashboardStatus") or "").upper() == "PO_NEW"
    ]

    excluded_missing_version = [
        order for order in api_po_new if order.get("poVersion") is None
    ]
    excluded_not_sent = [
        order
        for order in api_po_new
        if str(order.get("status") or "").upper() != "SENT"
    ]

    new_orders = [
        order
        for order in api_po_new
        if (
            str(order.get("status") or "").upper() == "SENT"
            and order.get("poVersion") is not None
        )
    ]

    new_orders.sort(
        key=lambda order: parse_ariba_datetime(order.get("created")) or datetime.min,
        reverse=True,
    )

    log(
        f"API: {len(all_records)} registro(s) bruto(s), "
        f"{len(current_by_identity)} PO(s) única(s) por comprador, "
        f"{len(api_po_new)} marcado(s) como PO_NEW pela API."
    )

    if collisions:
        log(
            f"Diagnóstico: {len(collisions)} documentNumber(s) repetido(s) "
            "entre compradores diferentes; identidades foram mantidas separadas."
        )

    if excluded_missing_version:
        numbers = ", ".join(
            order_identity_text(order) for order in excluded_missing_version
        )
        log(
            f"Filtro Workbench: {len(excluded_missing_version)} PO_NEW "
            f"ignorado(s) por poVersion ausente: {numbers}"
        )

    if excluded_not_sent:
        numbers = ", ".join(
            f"{order_identity_text(order)}[{clean_text(order.get('status'))}]"
            for order in excluded_not_sent
        )
        log(
            f"Filtro Workbench: {len(excluded_not_sent)} PO_NEW "
            f"ignorado(s) porque status != Sent: {numbers}"
        )

    log(f"New Orders identificados pela API: {len(new_orders)} pedido(s).")

    return new_orders, {
        "period_mode": period,
        "lookback_days": 1 if period == "24h" else 365,
        "window_count": len(windows),
        "period_start": (
            format_api_datetime(windows[0][0]) if windows else None
        ),
        "period_end": (
            format_api_datetime(windows[-1][1]) if windows else None
        ),
        "raw_record_count": len(all_records),
        "unique_order_count": len(current_by_identity),
        "api_po_new_count": len(api_po_new),
        "excluded_missing_po_version": len(excluded_missing_version),
        "excluded_missing_po_version_orders": [
            order_identity_text(order) for order in excluded_missing_version
        ],
        "excluded_not_sent": len(excluded_not_sent),
        "excluded_not_sent_orders": [
            {
                "order_key": order_identity_text(order),
                "status": clean_text(order.get("status")),
            }
            for order in excluded_not_sent
        ],
        "document_number_collision_count": len(collisions),
        "document_number_collisions": collisions,
        "workbench_filter_rule": {
            "dashboardStatus": "PO_NEW",
            "status": "Sent",
            "poVersion": "not null",
            "basis": "API rule; visibility/hidden state is not available in Purchase Orders Supplier API",
        },
        "new_order_count": len(new_orders),
        "collector_version": COLLECTOR_VERSION,
    }


KNOWN_ORDER_FIELDS = {
    "hideAmount", "documentNumber", "supplierName", "supplierANID", "vendorId",
    "customerName", "customerANID", "systemId", "endPointId", "poAmount",
    "disputeId", "created", "status", "dashboardStatus", "numberOfInvoices",
    "invoicedAmount", "serviceId", "blanketPoId", "releaseRequired", "isRelease",
    "amountAvailable", "documentStatus", "payloadId", "poVersion", "orderDate",
    "transportTerms", "transportTermsDesc", "paymentTermsExplanation",
    "attachmentCount", "purchasingAgentName", "poShipToName", "revision",
    "poShipToStreet", "poShipToCity", "poShipToState", "poShipToPostalCode",
    "poShipToCountry", "isoCountryCode", "poShipToCode", "companyCode",
    "purchasingGroupCode", "purchasingOrgCode", "settlement", "paymentTerms",
    "balance", "blanket", "poClosed", "schedulingAgreement", "routingStatus",
}

KNOWN_ITEM_FIELDS = {
    "documentNumber", "lineNumber", "quantity", "unitOfMeasure", "unitPrice",
    "supplierPart", "supplierPartNumber", "supplierPartId", "supplierPartID",
    "supplierPartIdentifier", "buyerPartId", "customerPartNumber",
    "customerPartId", "buyerPartNumber", "manufacturerPartId",
    "manufacturerPartNumber", "manufacturerName", "needBy", "needByDate",
    "description", "itemDescription", "shortDescription", "itemShipToName",
    "itemShipToStreet", "itemShipToCity", "itemShipToState",
    "itemShipToPostalCode", "itemShipToCountry", "isoCountryCode",
    "itemShipToCode", "itemLocation", "priority", "productIdentifier",
    "lineOfBusiness", "productFamily", "productSubFamily", "productCode",
    "partCategory", "partType", "category", "accountingDistribution",
    "pbqQuantity", "pbqUOM", "pbqUom", "pbqConversionFactor", "buyerBatchId",
    "supplierBatchId", "plannerCode", "plannerDescription", "confirmedQuantity",
    "cumulativeShipQuantity", "itemReturnAuthorizationNumber", "releaseType",
    "cumulativeReceivedQuantity", "cumulativeReceivedUom",
    "materialGoAheadEndDate", "productionGoAheadEndDate", "agreementDate",
    "agreementId", "previousAsnId", "previousAsnDate",
    "previousReceivedQuantity", "previousReceivedQuantityUom",
    "requestedDeliveryDate", "deliveryDateRequested", "requestedShipmentDate",
    "shipmentDateRequested", "deliveryDate", "shipDate", "shipmentDate",
    "storageLocation", "serialNumberInfo", "dueShipQuantity", "eanid", "eanId",
    "unspsc", "UNSPSC", "taxAmount", "tax", "currencyCode", "currency",
    "extLineNumber", "externalLineNumber",
}


def unknown_api_fields(mapping, known_fields):
    if not isinstance(mapping, dict):
        return []
    return sorted(str(key) for key in mapping.keys() if key not in known_fields)


# ============================================================
# NORMALIZAÇÃO / JSON DE NEGÓCIO
# ============================================================


def normalize_api_item(raw_item, order_currency=None):
    if not isinstance(raw_item, dict):
        raw_item = {}

    line_number = first_direct(
        raw_item,
        ["lineNumber", "lineItemNumber", "itemNumber", "poLineNumber", "line"],
    )

    # Campo real observado na API: supplierPart.
    supplier_part = first_direct(
        raw_item,
        [
            "supplierPart",
            "supplierPartNumber",
            "supplierPartId",
            "supplierPartID",
            "supplierPartIdentifier",
        ],
    )

    customer_part = first_direct(
        raw_item,
        [
            "buyerPartId",
            "customerPartNumber",
            "customerPartId",
            "buyerPartNumber",
        ],
    )

    description = first_direct(
        raw_item,
        ["description", "itemDescription", "shortDescription"],
    )
    quantity = first_direct(
        raw_item,
        ["quantity", "orderedQuantity", "orderQuantity"],
    )
    uom = first_direct(
        raw_item,
        ["unitOfMeasure", "uom", "unitOfMeasurement"],
    )

    unit_price_raw = first_direct(raw_item, ["unitPrice", "price", "unit_price"])
    item_currency = first_direct(raw_item, ["currencyCode", "currency"])
    unit_price, currency = money_parts(
        unit_price_raw,
        fallback_currency=clean_text(item_currency) or clean_text(order_currency),
    )

    tax_raw = first_direct(raw_item, ["taxAmount", "tax"])
    tax_amount, tax_currency = money_parts(
        tax_raw,
        fallback_currency=clean_text(order_currency),
    )

    supplier_part_text = clean_text(supplier_part)
    supplier_placeholder = is_placeholder_part_number(supplier_part_text)
    rexroth_part = None if supplier_placeholder else supplier_part_text

    requested_delivery_raw = first_direct(
        raw_item,
        ["requestedDeliveryDate", "deliveryDateRequested"],
    )
    need_by_raw = first_direct(raw_item, ["needBy", "needByDate"])
    requested_shipment_raw = first_direct(
        raw_item,
        ["requestedShipmentDate", "shipmentDateRequested"],
    )

    accounting = normalize_accounting_distribution(raw_item)

    item_ship_to = {
        "name": clean_text(first_direct(raw_item, ["itemShipToName"])),
        "street": clean_text(first_direct(raw_item, ["itemShipToStreet"])),
        "city": clean_text(first_direct(raw_item, ["itemShipToCity"])),
        "state": clean_text(first_direct(raw_item, ["itemShipToState"])),
        "postal_code": clean_text(first_direct(raw_item, ["itemShipToPostalCode"])),
        "country": clean_text(first_direct(raw_item, ["itemShipToCountry"])),
        "iso_country_code": clean_text(first_direct(raw_item, ["isoCountryCode"])),
        "ship_to_code": clean_text(first_direct(raw_item, ["itemShipToCode"])),
        "location": clean_text(first_direct(raw_item, ["itemLocation"])),
    }
    item_ship_to["cnpjs_found"] = extract_cnpjs(
        item_ship_to["name"],
        item_ship_to["street"],
        item_ship_to["city"],
        item_ship_to["postal_code"],
    )
    item_ship_to["cnpj"] = (
        item_ship_to["cnpjs_found"][0] if item_ship_to["cnpjs_found"] else None
    )

    serial_info = first_direct(raw_item, ["serialNumberInfo"])
    if not isinstance(serial_info, dict):
        serial_info = {}

    return {
        # Compatibilidade com o JSON anterior + campos corrigidos.
        "line_number": clean_text(line_number),
        "document_number": clean_text(first_direct(raw_item, ["documentNumber"])),
        "supplier_part_number": supplier_part_text,
        "supplier_part_is_placeholder": supplier_placeholder,
        "customer_part_number": clean_text(customer_part),
        "rexroth_part_number": rexroth_part,
        "manufacturer_part_number": clean_text(
            first_direct(raw_item, ["manufacturerPartId", "manufacturerPartNumber"])
        ),
        "manufacturer_name": clean_text(
            first_direct(raw_item, ["manufacturerName"])
        ),
        "description": clean_text(description),
        "quantity": parse_decimal(quantity),
        "uom": clean_text(uom),
        "unit_price": unit_price,
        "currency": currency,
        "need_by_date": iso_date_only(need_by_raw),
        "requested_delivery_date": iso_date_only(
            requested_delivery_raw or need_by_raw
        ),
        "requested_shipment_date": iso_date_only(requested_shipment_raw),
        "delivery_date": iso_date_only(
            first_direct(raw_item, ["deliveryDate"])
        ),
        "ship_date": iso_date_only(
            first_direct(raw_item, ["shipDate", "shipmentDate"])
        ),
        "tax_amount": tax_amount,
        "tax_currency": tax_currency,
        "ext_line_number": clean_text(
            first_direct(raw_item, ["extLineNumber", "externalLineNumber"])
        ),
        "dom_supplier_part_number": None,

        "item_ship_to": item_ship_to,

        "product": {
            "product_identifier": clean_text(first_direct(raw_item, ["productIdentifier"])),
            "line_of_business": clean_text(first_direct(raw_item, ["lineOfBusiness"])),
            "family": clean_text(first_direct(raw_item, ["productFamily"])),
            "sub_family": clean_text(first_direct(raw_item, ["productSubFamily"])),
            "product_code": clean_text(first_direct(raw_item, ["productCode"])),
            "part_category": clean_text(first_direct(raw_item, ["partCategory"])),
            "part_type": clean_text(first_direct(raw_item, ["partType"])),
            "category": clean_text(first_direct(raw_item, ["category"])),
            "ean_id": clean_text(first_direct(raw_item, ["eanid", "eanId"])),
            "unspsc": clean_text(first_direct(raw_item, ["unspsc", "UNSPSC"])),
        },

        "accounting": accounting,

        "packaging": {
            "pbq_quantity": parse_decimal(first_direct(raw_item, ["pbqQuantity"])),
            "pbq_uom": clean_text(first_direct(raw_item, ["pbqUOM", "pbqUom"])),
            "pbq_conversion_factor": parse_decimal(
                first_direct(raw_item, ["pbqConversionFactor"])
            ),
        },

        "planning": {
            "priority": clean_text(first_direct(raw_item, ["priority"])),
            "planner_code": clean_text(first_direct(raw_item, ["plannerCode"])),
            "planner_description": clean_text(
                first_direct(raw_item, ["plannerDescription"])
            ),
            "buyer_batch_id": clean_text(first_direct(raw_item, ["buyerBatchId"])),
            "supplier_batch_id": clean_text(first_direct(raw_item, ["supplierBatchId"])),
            "storage_location": clean_text(first_direct(raw_item, ["storageLocation"])),
        },

        "fulfillment": {
            "confirmed_quantity": parse_decimal(
                first_direct(raw_item, ["confirmedQuantity"])
            ),
            "due_ship_quantity": parse_decimal(
                first_direct(raw_item, ["dueShipQuantity"])
            ),
            "cumulative_ship_quantity": parse_decimal(
                first_direct(raw_item, ["cumulativeShipQuantity"])
            ),
            "cumulative_received_quantity": parse_decimal(
                first_direct(raw_item, ["cumulativeReceivedQuantity"])
            ),
            "cumulative_received_uom": clean_text(
                first_direct(raw_item, ["cumulativeReceivedUom"])
            ),
            "previous_received_quantity": parse_decimal(
                first_direct(raw_item, ["previousReceivedQuantity"])
            ),
            "previous_received_quantity_uom": clean_text(
                first_direct(raw_item, ["previousReceivedQuantityUom"])
            ),
            "return_authorization_number": clean_text(
                first_direct(raw_item, ["itemReturnAuthorizationNumber"])
            ),
        },

        "agreement": {
            "release_type": clean_text(first_direct(raw_item, ["releaseType"])),
            "agreement_date": iso_date_only(first_direct(raw_item, ["agreementDate"])),
            "agreement_id": clean_text(first_direct(raw_item, ["agreementId"])),
            "material_go_ahead_end_date": iso_date_only(
                first_direct(raw_item, ["materialGoAheadEndDate"])
            ),
            "production_go_ahead_end_date": iso_date_only(
                first_direct(raw_item, ["productionGoAheadEndDate"])
            ),
            "previous_asn_id": clean_text(first_direct(raw_item, ["previousAsnId"])),
            "previous_asn_date": iso_date_only(
                first_direct(raw_item, ["previousAsnDate"])
            ),
        },

        "serial_number_info": {
            "maximum": serial_info.get("maximum"),
            "minimum": serial_info.get("minimum"),
            "profile_type": clean_text(serial_info.get("profileType")),
            "type": clean_text(serial_info.get("type")),
            "values": serial_info.get("values"),
            "required": normalize_bool(serial_info.get("required")),
        },

        # A resposta bruta continua embutida: nenhum campo da SAP é perdido.
        "raw_api": raw_item,
    }


def _po_amount(order_header):
    return money_parts(order_header.get("poAmount"))


def _ship_to_name(order_header):
    value = order_header.get("poShipToName")
    if isinstance(value, dict):
        return clean_text(value.get("value") or value.get("encryptedValue"))
    return clean_text(value)


def _storage_stem(account, order_header, raw_dir=None):
    """Nome seguro para a PO; evita sobrescrever colisões entre buyer ANIDs."""
    order_number = clean_text(order_header.get("documentNumber")) or "unknown"
    buyer_anid = clean_text(order_header.get("customerANID")) or "buyer_unknown"
    base = safe_filename(order_number)
    raw_dir = Path(raw_dir) if raw_dir else (SISTEMA_DIR / account / "respostas_api")
    raw_base = raw_dir / f"{base}_order.json"

    if raw_base.exists():
        try:
            previous = json.loads(raw_base.read_text(encoding="utf-8"))
            previous_buyer = clean_text(previous.get("customerANID"))
            if previous_buyer and previous_buyer != buyer_anid:
                return f"{base}__{safe_filename(buyer_anid)}"
        except Exception:
            return f"{base}__{safe_filename(buyer_anid)}"
    return base


def storage_date_name(now=None):
    """Nome da pasta diária no formato DD-MM-AAAA."""
    now = now or datetime.now()
    return now.strftime("%d-%m-%Y")


def get_daily_storage_dirs(account):
    """
    Estrutura amigável ao usuário:
      Pedidos Baixados/ITA/02-09-2026/<pedido>.json

    Estrutura técnica:
      _sistema/ITA/respostas_api/02-09-2026/
      _sistema/ITA/historico_consultas/02-09-2026/
      _sistema/ITA/historico_execucoes/02-09-2026/
    """
    date_name = storage_date_name()

    dirs = {
        "date": date_name,
        "orders": PEDIDOS_DIR / account / date_name,
        "raw": SISTEMA_DIR / account / "respostas_api" / date_name,
        "snapshots": SISTEMA_DIR / account / "historico_consultas" / date_name,
        "batches": SISTEMA_DIR / account / "historico_execucoes" / date_name,
    }

    for key in ("orders", "raw", "snapshots", "batches"):
        dirs[key].mkdir(parents=True, exist_ok=True)

    return dirs


def _business_json_order_key(payload):
    """Extrai a identidade buyerANID:documentNumber de um JSON final já salvo."""
    if not isinstance(payload, dict):
        return None

    key = clean_text(payload.get("order_key"))
    if key:
        return key

    number = clean_text(payload.get("order_number"))
    buyer = clean_text((payload.get("customer") or {}).get("anid"))

    if not number:
        raw_header = ((payload.get("raw_api") or {}).get("order_header") or {})
        number = clean_text(raw_header.get("documentNumber"))
        buyer = buyer or clean_text(raw_header.get("customerANID"))

    if not number:
        return None

    return f"{buyer}:{number}" if buyer else number


def _business_json_is_complete(payload):
    """
    Valida se o JSON final já salvo é um JSON completo da automação.

    JSONs personalizados/filtrados por versões antigas são ignorados no índice
    de existentes para poderem ser coletados novamente e substituídos pelo
    formato completo.
    """
    if not isinstance(payload, dict):
        return False
    required = (
        "schema_version",
        "order_key",
        "order",
        "customer",
        "items",
        "analysis",
        "source",
        "raw_api",
    )
    return all(key in payload for key in required)


def build_existing_order_index(account):
    """
    Indexa JSONs finais já existentes para impedir reprocessamento.

    Fonte principal:
      Pedidos Baixados/<conta>/<DD-MM-AAAA>/*.json

    Enquanto a pasta antiga existir, também a consulta para evitar baixar
    novamente pedidos criados por versões anteriores.
    """
    candidates = set()

    # Estrutura oficial nova.
    new_root = PEDIDOS_DIR / account
    if new_root.exists():
        candidates.update(p for p in new_root.rglob("*.json") if p.is_file())

    # Compatibilidade com estruturas antigas em data/<conta>/.
    legacy_account_dir = LEGACY_DATA_DIR / account
    if legacy_account_dir.exists():
        legacy_orders = legacy_account_dir / "orders"
        if legacy_orders.exists():
            candidates.update(
                p for p in legacy_orders.rglob("*.json") if p.is_file()
            )

        legacy_runs = legacy_account_dir / "runs"
        if legacy_runs.exists():
            for p in legacy_runs.rglob("*.json"):
                if p.is_file() and p.parent.name == "orders":
                    candidates.add(p)

        for p in legacy_account_dir.glob("*.json"):
            if p.name == "latest_run.json":
                continue
            candidates.add(p)

    index = {}

    for path in sorted(candidates):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue

        # Versões antigas podiam salvar JSON filtrado por cliente. Esses
        # arquivos não devem bloquear a coleta completa da v1.9.
        if not _business_json_is_complete(payload):
            continue

        key = _business_json_order_key(payload)
        if key:
            # A estrutura nova tem prioridade se o mesmo pedido existir nos dois lugares.
            if key not in index or PEDIDOS_DIR in path.parents:
                index[key] = path.resolve()

    return index


def existing_json_for_order(order_header, existing_index):
    key = order_identity_text(order_header)
    return existing_index.get(key)





def build_business_json_api(
    account,
    order_header,
    raw_items,
    raw_order_path,
    raw_items_path,
):
    order_number = clean_text(order_header.get("documentNumber"))
    amount, currency = _po_amount(order_header)

    amount_available, amount_available_currency = money_parts(
        order_header.get("amountAvailable"),
        fallback_currency=currency,
    )
    invoiced_amount, invoiced_currency = money_parts(
        order_header.get("invoicedAmount"),
        fallback_currency=currency,
    )
    balance_amount, balance_currency = money_parts(
        order_header.get("balance"),
        fallback_currency=currency,
    )

    items = [
        normalize_api_item(item, order_currency=currency)
        for item in (raw_items or [])
    ]
    items.sort(key=lambda x: numeric_sort_key(x.get("line_number")))

    payment = parse_payment_terms(order_header)

    header_cnpjs = extract_cnpjs(
        order_header.get("customerName"),
        _ship_to_name(order_header),
        order_header.get("poShipToStreet"),
        order_header.get("poShipToCity"),
        order_header.get("poShipToPostalCode"),
    )

    analysis = build_collection_analysis(order_header, items, raw_items)

    unknown_header_fields = unknown_api_fields(order_header, KNOWN_ORDER_FIELDS)
    unknown_item_fields = sorted({
        field
        for raw_item in (raw_items or [])
        for field in unknown_api_fields(raw_item, KNOWN_ITEM_FIELDS)
    })
    analysis["unmapped_raw_fields"] = {
        "order_header": unknown_header_fields,
        "items": unknown_item_fields,
    }
    if unknown_header_fields or unknown_item_fields:
        analysis["warnings"].append({
            "field": "raw_api",
            "reason": "api_returned_unmapped_fields_but_raw_was_preserved",
            "order_header_fields": unknown_header_fields,
            "item_fields": unknown_item_fields,
        })

    flags = {
        "hide_amount": normalize_bool(order_header.get("hideAmount")),
        "release_required": normalize_bool(order_header.get("releaseRequired")),
        "is_release": normalize_bool(order_header.get("isRelease")),
        "blanket": normalize_bool(order_header.get("blanket")),
        "po_closed": normalize_bool(order_header.get("poClosed")),
        "scheduling_agreement": normalize_bool(
            order_header.get("schedulingAgreement")
        ),
    }

    return {
        "schema_version": "3.1-api",
        "collector_version": COLLECTOR_VERSION,
        "account": account,
        "order_key": order_identity_text(order_header),
        "order_number": order_number,

        "order": {
            "status": clean_text(order_header.get("status")),
            "dashboard_status": clean_text(order_header.get("dashboardStatus")),
            "document_status": clean_text(order_header.get("documentStatus")),
            "routing_status": clean_text(order_header.get("routingStatus")),
            "revision": clean_text(order_header.get("revision")),
            "date": iso_date_only(order_header.get("orderDate")),
            "created": clean_text(order_header.get("created")),
            "amount": amount,
            "currency": currency,
            "amount_available": amount_available,
            "amount_available_currency": amount_available_currency,
            "balance": balance_amount,
            "balance_currency": balance_currency,
            "invoiced_amount": invoiced_amount,
            "invoiced_currency": invoiced_currency,
            "number_of_invoices": order_header.get("numberOfInvoices"),
            "payload_id": clean_text(order_header.get("payloadId")),
            "po_version": order_header.get("poVersion"),
            "dispute_id": clean_text(order_header.get("disputeId")),
            "service_id": clean_text(order_header.get("serviceId")),
            "blanket_po_id": clean_text(order_header.get("blanketPoId")),
            "flags": flags,
        },

        "network": {
            "system_id": clean_text(order_header.get("systemId")),
            "endpoint_id": clean_text(order_header.get("endPointId")),
            "supplier_anid": clean_text(order_header.get("supplierANID")),
            "buyer_anid": clean_text(order_header.get("customerANID")),
        },

        "customer": {
            "name": clean_text(order_header.get("customerName")),
            # Mantido por compatibilidade com deduzir_cliente; a origem é explícita.
            "site_name": _ship_to_name(order_header),
            "site_name_source": "poShipToName",
            "cnpj": None,
            "anid": clean_text(order_header.get("customerANID")),
            "vendor_id": clean_text(order_header.get("vendorId")),
            # Alias legado; não afirmamos semanticamente que vendorId seja código SAP.
            "sap_code": clean_text(order_header.get("vendorId")),
            "sap_code_source": "vendorId",
            "ariba_csv_customer": None,
        },

        "supplier": {
            "name": clean_text(order_header.get("supplierName")),
            "anid": clean_text(order_header.get("supplierANID")),
            "cnpj": None,
            "address_id": None,
        },

        "delivery": {
            "ship_to_name": _ship_to_name(order_header),
            "street": clean_text(order_header.get("poShipToStreet")),
            "city": clean_text(order_header.get("poShipToCity")),
            "state": clean_text(order_header.get("poShipToState")),
            "postal_code": clean_text(order_header.get("poShipToPostalCode")),
            "country": clean_text(order_header.get("poShipToCountry")),
            "iso_country_code": clean_text(order_header.get("isoCountryCode")),
            "ship_to_code": clean_text(order_header.get("poShipToCode")),
            "location_code": None,
            "storage_location_id": None,
            "cnpjs_found": header_cnpjs,
            "cnpj": header_cnpjs[0] if header_cnpjs else None,
            "bill_to_cnpj": None,
        },

        "commercial": {
            "payment_terms": payment["terms"],
            "payment_terms_code": payment["code"],
            "payment_terms_description": payment["description"],
            "payment_terms_detail": payment["detail"],
            "contract_number": None,
            "contract_line_number": None,
            "delivery_terms": clean_text(order_header.get("transportTermsDesc")),
            "transport_terms": clean_text(order_header.get("transportTerms")),
            "transport_location": None,
            "incoterms": clean_text(order_header.get("transportTerms")),
            "quotation_number": None,
            "redespacho": None,
        },

        "organization": {
            "purchase_group": clean_text(order_header.get("purchasingGroupCode")),
            "purchase_organization": clean_text(order_header.get("purchasingOrgCode")),
            "company_code": clean_text(order_header.get("companyCode")),
            "party_additional_id": None,
        },

        "additional": {
            "requisition_number": None,
            "fiscal_classification": None,
            "fispq_required": None,
            "material_usage": None,
            "tax_substitution": None,
            "item_price_text": None,
            "attachment_count": order_header.get("attachmentCount"),
            "purchasing_agent_name": clean_text(order_header.get("purchasingAgentName")),
            "settlement": clean_text(order_header.get("settlement")),
            "number_of_invoices": order_header.get("numberOfInvoices"),
            "cnpjs_found_in_api": header_cnpjs,
            # Mantidos para compatibilidade com consumidores antigos.
            "cnpjs_found_on_page": header_cnpjs,
            "emails_found_on_page": [],
        },

        "items": items,
        "analysis": analysis,

        "source": {
            "type": "api",
            "collector_version": COLLECTOR_VERSION,
            "orders_endpoint": f"{API_BASE_URL}/orders",
            "items_endpoint": f"{API_BASE_URL}/items",
            "raw_order": str(raw_order_path),
            "raw_items": str(raw_items_path),
            "fetched_at": datetime.now().isoformat(timespec="seconds"),
        },

        # O JSON final também é autossuficiente para auditoria.
        "raw_api": {
            "order_header": order_header,
        },
    }


def save_order_json(
    account,
    order_header,
    raw_items,
    log,
    storage_dirs,
):
    """
    Salva sempre o JSON final COMPLETO normalizado.

    Não existe mais configuração/filtragem por cliente. As respostas originais
    da SAP também continuam preservadas integralmente em _sistema/.../respostas_api.
    """
    order_number = clean_text(order_header.get("documentNumber")) or "unknown"
    raw_dir = Path(storage_dirs["raw"])
    orders_dir = Path(storage_dirs["orders"])
    stem = _storage_stem(account, order_header, raw_dir=raw_dir)

    raw_order_path = raw_dir / f"{stem}_order.json"
    raw_items_path = raw_dir / f"{stem}_items.json"

    save_json_file(raw_order_path, order_header)
    save_json_file(raw_items_path, raw_items)

    full_payload = build_business_json_api(
        account=account,
        order_header=order_header,
        raw_items=raw_items,
        raw_order_path=raw_order_path,
        raw_items_path=raw_items_path,
    )

    output = orders_dir / f"{stem}.json"
    save_json_file(output, full_payload)

    analysis = full_payload.get("analysis") or {}
    quality = analysis.get("collection_quality")
    warnings_count = len(analysis.get("warnings") or [])
    unmapped = analysis.get("unmapped_raw_fields") or {}
    unmapped_count = len(unmapped.get("order_header") or []) + len(
        unmapped.get("items") or []
    )

    log(
        f"Pedido {order_number}: JSON completo salvo com {len(raw_items)} item(ns), "
        f"qualidade={quality}, avisos={warnings_count}, "
        f"campos_raw_novos={unmapped_count}: {output}"
    )

    if unmapped_count:
        log(
            f"Pedido {order_number}: AVISO - a SAP retornou campo(s) ainda não "
            "normalizado(s); todos foram preservados nos arquivos técnicos raw.",
            "warn",
        )

    return output, full_payload


# ============================================================
# LOTE
# ============================================================


def save_new_orders_snapshot(account, orders, stats, log, storage_dirs):
    stamp = time.strftime("%H%M%S")
    output = Path(storage_dirs["snapshots"]) / f"new_orders_{stamp}.json"

    payload = {
        "account": account,
        "storage_date": storage_dirs["date"],
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "stats": stats,
        "orders": orders,
    }

    save_json_file(output, payload)
    log(f"Snapshot dos New Orders salvo em: {output}")
    return output


def save_batch_summary(
    account,
    results,
    started_at,
    log,
    storage_dirs,
    discovery_stats=None,
):
    stamp = time.strftime("%H%M%S", time.localtime(started_at))
    output = Path(storage_dirs["batches"]) / f"batch_{stamp}.json"

    ok_count = sum(1 for item in results if item.get("status") == "OK")
    error_count = sum(1 for item in results if item.get("status") == "ERROR")
    skipped_count = sum(
        1 for item in results if item.get("status") == "SKIPPED_EXISTING"
    )
    processed_count = ok_count + error_count

    finished_at = time.time()
    duration_seconds = round(finished_at - started_at, 2)

    payload = {
        "account": account,
        "collector": "api",
        "collector_version": COLLECTOR_VERSION,
        "storage_date": storage_dirs["date"],
        "orders_dir": str(storage_dirs["orders"]),
        "raw_dir": str(storage_dirs["raw"]),
        "started_at": time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(started_at),
        ),
        "finished_at": time.strftime(
            "%Y-%m-%d %H:%M:%S",
            time.localtime(finished_at),
        ),
        "started_at_epoch": started_at,
        "finished_at_epoch": finished_at,
        "duration_seconds": duration_seconds,
        "duration_minutes": round(duration_seconds / 60, 2),
        "total": len(results),
        "processed": processed_count,
        "success": ok_count,
        "errors": error_count,
        "skipped_existing": skipped_count,
        "discovery": discovery_stats or {},
        "orders": results,
    }

    save_json_file(output, payload)

    latest = SISTEMA_DIR / account / "ultimo_lote.json"
    save_json_file(
        latest,
        {
            "account": account,
            "storage_date": storage_dirs["date"],
            "orders_dir": str(storage_dirs["orders"]),
            "batch_summary": str(output),
            "finished_at": payload["finished_at"],
        },
    )

    log(f"Resumo do lote salvo em: {output}")
    return payload

def run_automation(account, log, iniciado_por=None, period="365d"):
    ensure_dirs()
    account = str(account or "").upper()
    started_at = time.time()
    storage_dirs = get_daily_storage_dirs(account)
    period = str(period or "365d").lower()
    if period not in {"24h", "365d"}:
        raise ValueError("Período inválido. Use 24h ou 365d.")

    results = []
    discovery_stats = {}
    new_orders = []
    pending_orders = []
    exec_opened = False
    exec_closed = False

    _log_orig = log
    _sink = PortalSink(conta=account) if PortalSink else None

    def _user_log_message(message, nivel="info"):
        text = str(message or "").strip()
        level = str(nivel or "info").strip().lower()

        if not text:
            return None

        if level in {"erro", "err"}:
            return text, "err"

        if level in {"aviso", "warning", "warn"}:
            return text, "warn"

        if "INICIANDO COLETA VIA API" in text:
            return f"Iniciando coleta via API — {account}.", "head"

        if "OAuth token obtido com sucesso" in text:
            return "Autenticação com SAP Business Network concluída.", "ok"

        if text.startswith("Buscando pedidos das últimas 24 horas"):
            return "Buscando New Orders das últimas 24 horas...", "run"

        if text.startswith("Buscando pedidos dos últimos"):
            return "Buscando New Orders dos últimos 365 dias...", "run"

        if text.startswith("New Orders identificados pela API:"):
            match = re.search(r":\s*(\d+)", text)
            total = match.group(1) if match else "0"
            return f"Consulta concluída: {total} New Order(s) identificado(s).", "ok"

        if text.startswith("Já baixados anteriormente:"):
            return text, "info"

        if text.startswith("Nenhum pedido novo para baixar"):
            return text, "ok"

        if text.startswith("INICIANDO LOTE:"):
            match = re.search(r":\s*(\d+)", text)
            total = match.group(1) if match else "0"
            return f"Iniciando processamento de {total} pedido(s) novo(s).", "run"

        if re.match(r"^\[\d+/\d+\]\s+Processando pedido\s+", text):
            return text, "run"

        if text.startswith("Pedido ") and "COLETA API CONCLUÍDA" in text:
            match = re.match(r"^Pedido\s+([^:]+):", text)
            numero = match.group(1) if match else ""
            return f"Pedido {numero} baixado com sucesso.", "ok"

        if "LOTE FINALIZADO — API" in text:
            return "Processamento finalizado.", "head"

        if text.startswith("Resumo:"):
            return text, "ok"

        if text.startswith("Duração total:"):
            return text, "info"

        if "Nenhuma confirmação/alteração de pedido foi enviada ao Ariba" in text:
            return text, "info"

        # Detalhes técnicos continuam executando, mas não poluem a UI:
        # janelas de 31 dias, proxy, paginação da API, /items, paths físicos etc.
        return None

    def log(message, nivel="info"):
        user_event = _user_log_message(message, nivel)
        if not user_event:
            return

        user_message, user_level = user_event
        _log_orig(user_message)

        if _sink:
            try:
                _sink.log(user_message, user_level)
            except Exception:
                pass

    try:
        profiles = load_api_profiles()
        if account not in profiles:
            raise RuntimeError(f"Conta desconhecida: {account}")

        profile = profiles[account]
        validate_profile(account, profile)

        # Abre a execução no Portal desde o começo, ainda sem saber quantos
        # pedidos realmente precisarão ser baixados.
        if _sink:
            try:
                _sink.abrir_execucao(total=0, iniciado_por=iniciado_por)
                exec_opened = bool(_sink.execucao_id)
            except Exception:
                pass

        log(f"INICIANDO COLETA VIA API — {account}", "head")

        client = AribaAPIClient(account, profile, log)
        client.obtain_token()

        new_orders, discovery_stats = collect_new_orders(
            client,
            log,
            period=period,
        )

        # Verifica JSONs finais já existentes ANTES de chamar /items.
        # Assim um pedido previamente baixado não é processado de novo.
        existing_index = build_existing_order_index(account)

        for order_header in new_orders:
            order_number = clean_text(order_header.get("documentNumber")) or "UNKNOWN"
            existing_path = existing_json_for_order(order_header, existing_index)

            if existing_path:
                results.append(
                    {
                        "order_key": order_identity_text(order_header),
                        "order_number": order_number,
                        "buyer_anid": clean_text(order_header.get("customerANID")),
                        "status": "SKIPPED_EXISTING",
                        "json": str(existing_path),
                        "error": None,
                        "items": None,
                        "duration_seconds": 0,
                        "duration_minutes": 0,
                    }
                )
            else:
                pending_orders.append(order_header)

        existing_count = len(new_orders) - len(pending_orders)

        discovery_stats["existing_json_count"] = existing_count
        discovery_stats["pending_download_count"] = len(pending_orders)
        discovery_stats["storage_date"] = storage_dirs["date"]
        discovery_stats["orders_dir"] = str(storage_dirs["orders"])
        discovery_stats["period_mode"] = period

        log(
            f"Já baixados anteriormente: {existing_count} | "
            f"Novos para baixar: {len(pending_orders)}."
        )

        if _sink:
            try:
                _sink.atualizar_execucao(total=len(pending_orders))
            except Exception:
                pass

        save_new_orders_snapshot(
            account,
            new_orders,
            discovery_stats,
            log,
            storage_dirs,
        )

        if not pending_orders:
            log(
                "Nenhum pedido novo para baixar. "
                "Os JSONs já existentes foram preservados e não serão reprocessados.",
                "ok",
            )
        else:
            log(f"INICIANDO LOTE: {len(pending_orders)} New Order(s)", "head")

        for index, order_header in enumerate(pending_orders, start=1):
            order_number = clean_text(order_header.get("documentNumber")) or "UNKNOWN"
            order_started_at = time.time()

            log(
                f"[{index}/{len(pending_orders)}] Processando pedido {order_number}",
                "run",
            )

            try:
                if _sink:
                    try:
                        _sink.ordem(order_number, etapa1="run")
                    except Exception:
                        pass

                raw_items = client.fetch_items_for_order(order_header)

                if not raw_items:
                    raise AribaAPIError(
                        f"Pedido {order_number}: /items não retornou nenhuma linha; "
                        "coleta considerada incompleta."
                    )

                json_path, business_json = save_order_json(
                    account,
                    order_header,
                    raw_items,
                    log,
                    storage_dirs,
                )

                collection_quality = (
                    (business_json.get("analysis") or {}).get("collection_quality")
                )

                if collection_quality == "ERROR":
                    raise AribaAPIError(
                        f"Pedido {order_number}: validação da coleta retornou ERROR. "
                        f"Veja {json_path} para diagnóstico."
                    )

                order_duration = round(time.time() - order_started_at, 2)

                result = {
                    "order_key": business_json.get("order_key"),
                    "order_number": order_number,
                    "buyer_anid": (business_json.get("customer") or {}).get("anid"),
                    "status": "OK",
                    "json": str(json_path),
                    "error": None,
                    "items": len(raw_items),
                    "duration_seconds": order_duration,
                    "duration_minutes": round(order_duration / 60, 2),
                }

                results.append(result)

                # Atualiza o índice durante a própria execução.
                if result.get("order_key"):
                    existing_index[result["order_key"]] = Path(json_path).resolve()

                if _sink:
                    try:
                        nome, slug = deduzir_cliente(business_json)

                        _sink.ordem(
                            order_number,
                            etapa1="ok",
                            cliente=nome,
                            cliente_id=slug,
                            buyer_anid=(business_json.get("customer") or {}).get("anid"),
                            itens=len(business_json.get("items", []) or []),
                            valor=(business_json.get("order") or {}).get("amount"),
                            moeda=(business_json.get("order") or {}).get("currency"),
                            qualidade=(business_json.get("analysis") or {}).get(
                                "collection_quality"
                            ),
                            campos_pendentes=(business_json.get("analysis") or {}).get(
                                "missing_fields"
                            ),
                            json_path=str(json_path),
                        )
                    except Exception:
                        pass

                log(
                    f"Pedido {order_number}: COLETA API CONCLUÍDA "
                    f"em {order_duration:.2f}s.",
                    "ok",
                )

            except Exception as exc:
                error_message = str(exc)
                order_duration = round(time.time() - order_started_at, 2)

                log(
                    f"Pedido {order_number}: ERRO — {error_message}",
                    "err",
                )

                results.append(
                    {
                        "order_key": order_identity_text(order_header),
                        "order_number": order_number,
                        "buyer_anid": clean_text(order_header.get("customerANID")),
                        "status": "ERROR",
                        "json": None,
                        "error": error_message,
                        "duration_seconds": order_duration,
                        "duration_minutes": round(order_duration / 60, 2),
                    }
                )

                if _sink:
                    try:
                        _sink.ordem(
                            order_number,
                            etapa1="err",
                            erro_msg=error_message,
                        )
                    except Exception:
                        pass

                continue

        summary = save_batch_summary(
            account,
            results,
            started_at,
            log,
            storage_dirs,
            discovery_stats=discovery_stats,
        )

        if _sink:
            try:
                _sink.fechar_execucao(
                    status=("err" if summary.get("errors") else "ok"),
                    sucesso=summary.get("success", 0),
                    erros=summary.get("errors", 0),
                    total=summary.get("processed", 0),
                )
                exec_closed = True
            except Exception:
                pass

        log("LOTE FINALIZADO — API", "head")
        log(
            "Resumo: "
            f"{discovery_stats.get('new_order_count', 0)} New Order(s) | "
            f"{summary.get('skipped_existing', 0)} já existente(s) | "
            f"{summary.get('success', 0)} baixado(s) agora | "
            f"{summary.get('errors', 0)} erro(s).",
            "ok",
        )
        log(
            f"Duração total: {summary['duration_seconds']:.2f}s "
            f"({summary['duration_minutes']:.2f} min)"
        )
        log("Nenhuma confirmação/alteração de pedido foi enviada ao Ariba.")

        return summary

    except Exception as exc:
        try:
            log(f"ERRO FATAL DA COLETA — {exc}", "err")
        except Exception:
            pass

        if _sink and exec_opened and not exec_closed:
            try:
                success = sum(1 for item in results if item.get("status") == "OK")
                errors = sum(1 for item in results if item.get("status") == "ERROR") + 1

                _sink.fechar_execucao(
                    status="err",
                    sucesso=success,
                    erros=errors,
                    total=len(pending_orders),
                )

                exec_closed = True
            except Exception:
                pass

        raise

    finally:
        if _sink:
            try:
                _sink.close(timeout=2.0)
            except Exception:
                pass

# ============================================================
# UI
# ============================================================


class App:
    def __init__(self):
        self.root = Tk()
        self.root.title(f"Ariba Automation — API v{COLLECTOR_VERSION}")
        self.root.geometry("800x560")

        # ITA já foi validado na API; deixamos como padrão nesta primeira versão.
        self.account = StringVar(value="ITA")

        container = ttk.Frame(self.root, padding=18)
        container.pack(fill="both", expand=True)

        ttk.Label(
            container,
            text=f"Ariba Automation — API v{COLLECTOR_VERSION}",
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w")

        ttk.Label(
            container,
            text="Coleta 100% pela Purchase Orders Supplier API (sem Playwright).",
        ).pack(anchor="w", pady=(2, 18))

        selector = ttk.LabelFrame(container, text="Conta / planta", padding=12)
        selector.pack(fill="x")

        ttk.Radiobutton(
            selector,
            text="ITA",
            variable=self.account,
            value="ITA",
        ).pack(side="left", padx=(0, 20))

        ttk.Radiobutton(
            selector,
            text="POP",
            variable=self.account,
            value="POP",
        ).pack(side="left")

        self.start_button = ttk.Button(
            container,
            text="Processar New orders via API",
            command=self.start,
        )
        self.start_button.pack(anchor="w", pady=16)

        ttk.Label(container, text="Log").pack(anchor="w")

        self.log_box = Text(
            container,
            height=20,
            wrap="word",
            font=("Consolas", 10),
        )
        self.log_box.pack(fill="both", expand=True)

    def log(self, message):
        timestamp = time.strftime("%H:%M:%S", time.localtime())
        self.root.after(0, self._append_log, f"[{timestamp}] {message}")

    def _append_log(self, message):
        self.log_box.insert(END, message + "\n")
        self.log_box.see(END)

    def start(self):
        account = self.account.get()
        self.start_button.config(state=DISABLED)
        self.log_box.delete("1.0", END)
        self.log(f"Iniciando perfil {account} via API...")

        threading.Thread(
            target=self.worker,
            args=(account,),
            daemon=True,
        ).start()

    def worker(self, account):
        try:
            summary = run_automation(account, self.log, iniciado_por=os.environ.get("USERNAME"), period="365d")

            success = summary.get("success", 0) if summary else 0
            errors = summary.get("errors", 0) if summary else 0
            processed = summary.get("processed", 0) if summary else 0
            skipped = summary.get("skipped_existing", 0) if summary else 0
            duration_minutes = summary.get("duration_minutes", 0) if summary else 0
            new_count = (summary.get("discovery") or {}).get("new_order_count", processed)

            self.root.after(
                0,
                lambda s=success, e=errors, p=processed, sk=skipped, d=duration_minutes, n=new_count:
                    messagebox.showinfo(
                        "Lote concluído",
                        f"New Orders encontrados: {n}\n"
                        f"Já baixados anteriormente: {sk}\n"
                        f"Processados agora: {p}\n"
                        f"Baixados agora: {s}\n"
                        f"Erros: {e}\n"
                        f"Duração: {d:.2f} min\n\n"
                        "Coleta realizada somente por API.\n"
                        "Pedidos já existentes não foram reprocessados.",
                    ),
            )

        except Exception as exc:
            message = str(exc)
            self.log(f"ERRO: {message}")

            self.root.after(
                0,
                lambda msg=message: messagebox.showerror("Erro", msg),
            )

        finally:
            self.root.after(
                0,
                lambda: self.start_button.config(state=NORMAL),
            )

    def run(self):
        self.root.mainloop()


def _console_log(message, nivel="info"):
    timestamp = time.strftime("%H:%M:%S", time.localtime())
    print(f"[{timestamp}] {message}", flush=True)


def main():
    parser = argparse.ArgumentParser(description="Coletor SAP Business Network via API")
    parser.add_argument("--account", choices=("ITA", "POP"), help="Executa uma conta sem abrir a UI Tkinter")
    parser.add_argument("--headless", action="store_true", help="Compatibilidade: em modo CLI não abre Tkinter")
    parser.add_argument(
        "--period",
        choices=("24h", "365d"),
        default=os.environ.get("ARIBA_RUN_PERIOD", "365d"),
        help="Período de busca dos pedidos: últimas 24 horas ou últimos 365 dias.",
    )
    args = parser.parse_args()

    if args.account:
        try:
            run_automation(
                args.account,
                _console_log,
                iniciado_por=os.environ.get("ARIBA_STARTED_BY") or os.environ.get("USERNAME"),
                period=args.period,
            )
        except Exception as exc:
            _console_log(f"ERRO: {exc}", "err")
            raise SystemExit(1)
        return

    App().run()


if __name__ == "__main__":
    main()
